(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/frontend_f1b38539._.js",
  "static/chunks/9e883_next_4c0a94eb._.js",
  "static/chunks/frontend_fc1b1e8e._.css"
],
    source: "dynamic"
});
