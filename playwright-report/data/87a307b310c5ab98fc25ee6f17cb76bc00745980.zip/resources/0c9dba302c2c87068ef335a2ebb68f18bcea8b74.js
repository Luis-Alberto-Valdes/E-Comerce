(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/frontend/lib/products.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "filterProducts",
    ()=>filterProducts
]);
function filterProducts(products, filters) {
    let filtered = [
        ...products
    ];
    if (filters.category) {
        filtered = filtered.filter((p)=>p.category.toLowerCase() === filters.category.toLowerCase());
    }
    if (filters.search) {
        const searchTerm = filters.search.toLowerCase();
        filtered = filtered.filter((p)=>p.title.toLowerCase().includes(searchTerm) || p.description.toLowerCase().includes(searchTerm) || p.category.toLowerCase().includes(searchTerm));
    }
    if (filters.maxPrice) {
        const maxPrice = parseFloat(filters.maxPrice);
        if (!isNaN(maxPrice)) {
            filtered = filtered.filter((p)=>p.price <= maxPrice);
        }
    }
    return filtered;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/hooks/useFilters.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useFilterValues",
    ()=>useFilters,
    "useFilters",
    ()=>useFilters
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$lib$2f$products$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/lib/products.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
const SCROLL_POSITION_KEY = 'products_scroll_position';
const DEBOUNCE_DELAY = 300;
function updateURL({ key, value, searchParams, pathname, router }) {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    const scrollPosition = window.scrollY;
    sessionStorage.setItem(SCROLL_POSITION_KEY, String(scrollPosition));
    const params = new URLSearchParams(searchParams.toString());
    if (value) {
        params.set(key, value);
    } else {
        params.delete(key);
    }
    const queryString = params.toString();
    router.push(queryString ? `${pathname}?${queryString}` : pathname, {
        scroll: false
    });
}
function useFilters(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(34);
    if ($[0] !== "d752b0b6441858be7dd4439940e4c053fcf7fc3f44bbcf4ec423d91798dce75b") {
        for(let $i = 0; $i < 34; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "d752b0b6441858be7dd4439940e4c053fcf7fc3f44bbcf4ec423d91798dce75b";
    }
    const { products } = t0;
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const debounceRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    let t1;
    if ($[1] !== searchParams) {
        t1 = ({
            "useFilters[useState()]": ()=>searchParams.get("search") || ""
        })["useFilters[useState()]"];
        $[1] = searchParams;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const [localSearch, setLocalSearch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t1);
    let t2;
    if ($[3] !== searchParams) {
        t2 = searchParams.get("search") || "";
        $[3] = searchParams;
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    const urlSearchValue = t2;
    let t3;
    if ($[5] !== searchParams) {
        t3 = searchParams.get("category") || "";
        $[5] = searchParams;
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    const categoryValue = t3;
    let t4;
    if ($[7] !== searchParams) {
        t4 = searchParams.get("maxPrice") || "";
        $[7] = searchParams;
        $[8] = t4;
    } else {
        t4 = $[8];
    }
    const maxPriceValue = t4;
    let t5;
    if ($[9] !== categoryValue || $[10] !== maxPriceValue || $[11] !== urlSearchValue) {
        t5 = {
            search: urlSearchValue,
            category: categoryValue,
            maxPrice: maxPriceValue
        };
        $[9] = categoryValue;
        $[10] = maxPriceValue;
        $[11] = urlSearchValue;
        $[12] = t5;
    } else {
        t5 = $[12];
    }
    const filters = t5;
    let t6;
    bb0: {
        if (!products) {
            let t7;
            if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
                t7 = [];
                $[13] = t7;
            } else {
                t7 = $[13];
            }
            t6 = t7;
            break bb0;
        }
        let t7;
        if ($[14] !== filters || $[15] !== products) {
            t7 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$lib$2f$products$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["filterProducts"])(products, filters);
            $[14] = filters;
            $[15] = products;
            $[16] = t7;
        } else {
            t7 = $[16];
        }
        t6 = t7;
    }
    const filteredProducts = t6;
    let t7;
    if ($[17] !== pathname || $[18] !== router || $[19] !== searchParams) {
        t7 = ({
            "useFilters[setFilter]": (key, value)=>{
                if (debounceRef.current) {
                    clearTimeout(debounceRef.current);
                }
                if (key === "search") {
                    setLocalSearch(value);
                    debounceRef.current = setTimeout({
                        "useFilters[setFilter > setTimeout()]": ()=>{
                            updateURL({
                                key,
                                value,
                                searchParams,
                                pathname,
                                router
                            });
                        }
                    }["useFilters[setFilter > setTimeout()]"], DEBOUNCE_DELAY);
                } else {
                    updateURL({
                        key,
                        value,
                        searchParams,
                        pathname,
                        router
                    });
                }
            }
        })["useFilters[setFilter]"];
        $[17] = pathname;
        $[18] = router;
        $[19] = searchParams;
        $[20] = t7;
    } else {
        t7 = $[20];
    }
    const setFilter = t7;
    let t8;
    if ($[21] !== pathname || $[22] !== router) {
        t8 = ({
            "useFilters[clearFilters]": ()=>{
                if (debounceRef.current) {
                    clearTimeout(debounceRef.current);
                }
                setLocalSearch("");
                if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
                ;
                const scrollPosition = window.scrollY;
                sessionStorage.setItem(SCROLL_POSITION_KEY, String(scrollPosition));
                router.push(pathname, {
                    scroll: false
                });
            }
        })["useFilters[clearFilters]"];
        $[21] = pathname;
        $[22] = router;
        $[23] = t8;
    } else {
        t8 = $[23];
    }
    const clearFilters = t8;
    const restoreScrollPosition = _useFiltersRestoreScrollPosition;
    const hasActiveFilters = urlSearchValue !== "" || categoryValue !== "" || maxPriceValue !== "";
    let t9;
    if ($[24] !== products) {
        const seen = new Set();
        t9 = products.filter({
            "useFilters[products.filter()]": (p)=>{
                if (seen.has(p.category)) {
                    return false;
                }
                seen.add(p.category);
                return true;
            }
        }["useFilters[products.filter()]"]).map(_useFiltersAnonymous);
        $[24] = products;
        $[25] = t9;
    } else {
        t9 = $[25];
    }
    const uniqueCategories = t9;
    let t10;
    if ($[26] !== clearFilters || $[27] !== filteredProducts || $[28] !== filters || $[29] !== hasActiveFilters || $[30] !== localSearch || $[31] !== setFilter || $[32] !== uniqueCategories) {
        t10 = {
            filters,
            filteredProducts,
            localSearch,
            setFilter,
            clearFilters,
            hasActiveFilters,
            restoreScrollPosition,
            uniqueCategories
        };
        $[26] = clearFilters;
        $[27] = filteredProducts;
        $[28] = filters;
        $[29] = hasActiveFilters;
        $[30] = localSearch;
        $[31] = setFilter;
        $[32] = uniqueCategories;
        $[33] = t10;
    } else {
        t10 = $[33];
    }
    return t10;
}
_s(useFilters, "yE6AyXYiWM+cpU72bnrjMVusZgk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"],
        __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
function _useFiltersAnonymous(p_0) {
    return p_0.category;
}
function _useFiltersRestoreScrollPosition() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    const savedPosition = sessionStorage.getItem(SCROLL_POSITION_KEY);
    if (savedPosition) {
        window.scrollTo({
            top: parseInt(savedPosition, 10),
            behavior: "instant"
        });
        sessionStorage.removeItem(SCROLL_POSITION_KEY);
    }
}
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/ui/products/FilterSidebar.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "clearBtn": "FilterSidebar-module__nh3lZq__clearBtn",
  "content": "FilterSidebar-module__nh3lZq__content",
  "currency": "FilterSidebar-module__nh3lZq__currency",
  "header": "FilterSidebar-module__nh3lZq__header",
  "labelText": "FilterSidebar-module__nh3lZq__labelText",
  "pending": "FilterSidebar-module__nh3lZq__pending",
  "priceInput": "FilterSidebar-module__nh3lZq__priceInput",
  "priceRange": "FilterSidebar-module__nh3lZq__priceRange",
  "priceWrapper": "FilterSidebar-module__nh3lZq__priceWrapper",
  "radio": "FilterSidebar-module__nh3lZq__radio",
  "radioGroup": "FilterSidebar-module__nh3lZq__radioGroup",
  "radioLabel": "FilterSidebar-module__nh3lZq__radioLabel",
  "radioMark": "FilterSidebar-module__nh3lZq__radioMark",
  "rangeLabels": "FilterSidebar-module__nh3lZq__rangeLabels",
  "rangeSlider": "FilterSidebar-module__nh3lZq__rangeSlider",
  "searchIcon": "FilterSidebar-module__nh3lZq__searchIcon",
  "searchInput": "FilterSidebar-module__nh3lZq__searchInput",
  "searchWrapper": "FilterSidebar-module__nh3lZq__searchWrapper",
  "section": "FilterSidebar-module__nh3lZq__section",
  "sectionTitle": "FilterSidebar-module__nh3lZq__sectionTitle",
  "sidebar": "FilterSidebar-module__nh3lZq__sidebar",
  "title": "FilterSidebar-module__nh3lZq__title",
});
}),
"[project]/frontend/ui/products/FilterSidebar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>FilterSidebar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$hooks$2f$useFilters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/hooks/useFilters.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterSidebar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/frontend/ui/products/FilterSidebar.module.css [app-client] (css module)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function FilterSidebar(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(52);
    if ($[0] !== "2dd63b78a1d9bd32b4615d622455ebce3ecfbac9f58880c76339ce0850f49b49") {
        for(let $i = 0; $i < 52; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "2dd63b78a1d9bd32b4615d622455ebce3ecfbac9f58880c76339ce0850f49b49";
    }
    const { products } = t0;
    let t1;
    if ($[1] !== products) {
        t1 = products || [];
        $[1] = products;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    let t2;
    if ($[3] !== t1) {
        t2 = {
            products: t1
        };
        $[3] = t1;
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    const { filters, localSearch, setFilter, clearFilters, hasActiveFilters, uniqueCategories } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$hooks$2f$useFilters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilterValues"])(t2);
    let t3;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterSidebar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].title,
            children: "Filtros"
        }, void 0, false, {
            fileName: "[project]/frontend/ui/products/FilterSidebar.tsx",
            lineNumber: 49,
            columnNumber: 10
        }, this);
        $[5] = t3;
    } else {
        t3 = $[5];
    }
    let t4;
    if ($[6] !== clearFilters || $[7] !== hasActiveFilters) {
        t4 = hasActiveFilters && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: "button",
            onClick: clearFilters,
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterSidebar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].clearBtn,
            children: "Limpiar"
        }, void 0, false, {
            fileName: "[project]/frontend/ui/products/FilterSidebar.tsx",
            lineNumber: 56,
            columnNumber: 30
        }, this);
        $[6] = clearFilters;
        $[7] = hasActiveFilters;
        $[8] = t4;
    } else {
        t4 = $[8];
    }
    let t5;
    if ($[9] !== t4) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterSidebar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].header,
            children: [
                t3,
                t4
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/ui/products/FilterSidebar.tsx",
            lineNumber: 65,
            columnNumber: 10
        }, this);
        $[9] = t4;
        $[10] = t5;
    } else {
        t5 = $[10];
    }
    let t6;
    if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterSidebar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sectionTitle,
            children: "Buscar"
        }, void 0, false, {
            fileName: "[project]/frontend/ui/products/FilterSidebar.tsx",
            lineNumber: 73,
            columnNumber: 10
        }, this);
        $[11] = t6;
    } else {
        t6 = $[11];
    }
    let t7;
    if ($[12] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterSidebar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].searchIcon,
            width: "18",
            height: "18",
            viewBox: "0 0 24 24",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "2",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                    cx: "11",
                    cy: "11",
                    r: "8"
                }, void 0, false, {
                    fileName: "[project]/frontend/ui/products/FilterSidebar.tsx",
                    lineNumber: 80,
                    columnNumber: 138
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                    x1: "21",
                    y1: "21",
                    x2: "16.65",
                    y2: "16.65"
                }, void 0, false, {
                    fileName: "[project]/frontend/ui/products/FilterSidebar.tsx",
                    lineNumber: 80,
                    columnNumber: 170
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/ui/products/FilterSidebar.tsx",
            lineNumber: 80,
            columnNumber: 10
        }, this);
        $[12] = t7;
    } else {
        t7 = $[12];
    }
    let t8;
    if ($[13] !== setFilter) {
        t8 = ({
            "FilterSidebar[<input>.onChange]": (e)=>setFilter("search", e.target.value)
        })["FilterSidebar[<input>.onChange]"];
        $[13] = setFilter;
        $[14] = t8;
    } else {
        t8 = $[14];
    }
    let t9;
    if ($[15] !== localSearch || $[16] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterSidebar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].section,
            children: [
                t6,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterSidebar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].searchWrapper,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        for: "search",
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterSidebar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].labelText,
                        children: [
                            t7,
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "search",
                                id: "search",
                                name: "search",
                                placeholder: "Buscar productos...",
                                value: localSearch,
                                onChange: t8,
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterSidebar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].searchInput
                            }, void 0, false, {
                                fileName: "[project]/frontend/ui/products/FilterSidebar.tsx",
                                lineNumber: 97,
                                columnNumber: 137
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/frontend/ui/products/FilterSidebar.tsx",
                        lineNumber: 97,
                        columnNumber: 84
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/frontend/ui/products/FilterSidebar.tsx",
                    lineNumber: 97,
                    columnNumber: 46
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/ui/products/FilterSidebar.tsx",
            lineNumber: 97,
            columnNumber: 10
        }, this);
        $[15] = localSearch;
        $[16] = t8;
        $[17] = t9;
    } else {
        t9 = $[17];
    }
    let t10;
    if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterSidebar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sectionTitle,
            children: "Categoría"
        }, void 0, false, {
            fileName: "[project]/frontend/ui/products/FilterSidebar.tsx",
            lineNumber: 106,
            columnNumber: 11
        }, this);
        $[18] = t10;
    } else {
        t10 = $[18];
    }
    const t11 = filters.category === "";
    let t12;
    if ($[19] !== setFilter) {
        t12 = ({
            "FilterSidebar[<input>.onChange]": ()=>setFilter("category", "")
        })["FilterSidebar[<input>.onChange]"];
        $[19] = setFilter;
        $[20] = t12;
    } else {
        t12 = $[20];
    }
    let t13;
    if ($[21] !== t11 || $[22] !== t12) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
            type: "radio",
            name: "category",
            value: "",
            checked: t11,
            onChange: t12,
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterSidebar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].radio
        }, void 0, false, {
            fileName: "[project]/frontend/ui/products/FilterSidebar.tsx",
            lineNumber: 124,
            columnNumber: 11
        }, this);
        $[21] = t11;
        $[22] = t12;
        $[23] = t13;
    } else {
        t13 = $[23];
    }
    let t14;
    let t15;
    if ($[24] === Symbol.for("react.memo_cache_sentinel")) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterSidebar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].radioMark
        }, void 0, false, {
            fileName: "[project]/frontend/ui/products/FilterSidebar.tsx",
            lineNumber: 134,
            columnNumber: 11
        }, this);
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterSidebar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].labelText,
            children: "Todas"
        }, void 0, false, {
            fileName: "[project]/frontend/ui/products/FilterSidebar.tsx",
            lineNumber: 135,
            columnNumber: 11
        }, this);
        $[24] = t14;
        $[25] = t15;
    } else {
        t14 = $[24];
        t15 = $[25];
    }
    let t16;
    if ($[26] !== t13) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterSidebar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].radioLabel,
            children: [
                t13,
                t14,
                t15
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/ui/products/FilterSidebar.tsx",
            lineNumber: 144,
            columnNumber: 11
        }, this);
        $[26] = t13;
        $[27] = t16;
    } else {
        t16 = $[27];
    }
    let t17;
    if ($[28] !== filters.category || $[29] !== setFilter || $[30] !== uniqueCategories) {
        let t18;
        if ($[32] !== filters.category || $[33] !== setFilter) {
            t18 = ({
                "FilterSidebar[uniqueCategories.map()]": (category)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterSidebar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].radioLabel,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "radio",
                                name: "category",
                                value: category,
                                checked: filters.category === category,
                                onChange: {
                                    "FilterSidebar[uniqueCategories.map() > <input>.onChange]": ()=>setFilter("category", category)
                                }["FilterSidebar[uniqueCategories.map() > <input>.onChange]"],
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterSidebar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].radio
                            }, void 0, false, {
                                fileName: "[project]/frontend/ui/products/FilterSidebar.tsx",
                                lineNumber: 155,
                                columnNumber: 114
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterSidebar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].radioMark
                            }, void 0, false, {
                                fileName: "[project]/frontend/ui/products/FilterSidebar.tsx",
                                lineNumber: 157,
                                columnNumber: 101
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterSidebar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].labelText,
                                children: category
                            }, void 0, false, {
                                fileName: "[project]/frontend/ui/products/FilterSidebar.tsx",
                                lineNumber: 157,
                                columnNumber: 138
                            }, this)
                        ]
                    }, category, true, {
                        fileName: "[project]/frontend/ui/products/FilterSidebar.tsx",
                        lineNumber: 155,
                        columnNumber: 62
                    }, this)
            })["FilterSidebar[uniqueCategories.map()]"];
            $[32] = filters.category;
            $[33] = setFilter;
            $[34] = t18;
        } else {
            t18 = $[34];
        }
        t17 = uniqueCategories.map(t18);
        $[28] = filters.category;
        $[29] = setFilter;
        $[30] = uniqueCategories;
        $[31] = t17;
    } else {
        t17 = $[31];
    }
    let t18;
    if ($[35] !== t16 || $[36] !== t17) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterSidebar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].section,
            children: [
                t10,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterSidebar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].radioGroup,
                    children: [
                        t16,
                        t17
                    ]
                }, void 0, true, {
                    fileName: "[project]/frontend/ui/products/FilterSidebar.tsx",
                    lineNumber: 175,
                    columnNumber: 48
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/ui/products/FilterSidebar.tsx",
            lineNumber: 175,
            columnNumber: 11
        }, this);
        $[35] = t16;
        $[36] = t17;
        $[37] = t18;
    } else {
        t18 = $[37];
    }
    let t19;
    if ($[38] === Symbol.for("react.memo_cache_sentinel")) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterSidebar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sectionTitle,
            children: "Precio máximo"
        }, void 0, false, {
            fileName: "[project]/frontend/ui/products/FilterSidebar.tsx",
            lineNumber: 184,
            columnNumber: 11
        }, this);
        $[38] = t19;
    } else {
        t19 = $[38];
    }
    let t20;
    if ($[39] === Symbol.for("react.memo_cache_sentinel")) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterSidebar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].currency,
            children: "$"
        }, void 0, false, {
            fileName: "[project]/frontend/ui/products/FilterSidebar.tsx",
            lineNumber: 191,
            columnNumber: 11
        }, this);
        $[39] = t20;
    } else {
        t20 = $[39];
    }
    let t21;
    if ($[40] !== setFilter) {
        t21 = ({
            "FilterSidebar[<input>.onChange]": (e_0)=>setFilter("maxPrice", e_0.target.value)
        })["FilterSidebar[<input>.onChange]"];
        $[40] = setFilter;
        $[41] = t21;
    } else {
        t21 = $[41];
    }
    let t22;
    if ($[42] !== filters.maxPrice || $[43] !== t21) {
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterSidebar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].section,
            children: [
                t19,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterSidebar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].priceWrapper,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        for: "maxPrice",
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterSidebar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].labelText,
                        children: [
                            t20,
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "number",
                                id: "maxPrice",
                                name: "maxPrice",
                                min: "0",
                                placeholder: "Ej: 500",
                                value: filters.maxPrice,
                                onChange: t21,
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterSidebar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].priceInput
                            }, void 0, false, {
                                fileName: "[project]/frontend/ui/products/FilterSidebar.tsx",
                                lineNumber: 208,
                                columnNumber: 141
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/frontend/ui/products/FilterSidebar.tsx",
                        lineNumber: 208,
                        columnNumber: 85
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/frontend/ui/products/FilterSidebar.tsx",
                    lineNumber: 208,
                    columnNumber: 48
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/ui/products/FilterSidebar.tsx",
            lineNumber: 208,
            columnNumber: 11
        }, this);
        $[42] = filters.maxPrice;
        $[43] = t21;
        $[44] = t22;
    } else {
        t22 = $[44];
    }
    let t23;
    if ($[45] !== t18 || $[46] !== t22 || $[47] !== t9) {
        t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterSidebar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].content,
            children: [
                t9,
                t18,
                t22
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/ui/products/FilterSidebar.tsx",
            lineNumber: 217,
            columnNumber: 11
        }, this);
        $[45] = t18;
        $[46] = t22;
        $[47] = t9;
        $[48] = t23;
    } else {
        t23 = $[48];
    }
    let t24;
    if ($[49] !== t23 || $[50] !== t5) {
        t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("aside", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterSidebar$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sidebar,
            children: [
                t5,
                t23
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/ui/products/FilterSidebar.tsx",
            lineNumber: 227,
            columnNumber: 11
        }, this);
        $[49] = t23;
        $[50] = t5;
        $[51] = t24;
    } else {
        t24 = $[51];
    }
    return t24;
}
_s(FilterSidebar, "7sE1orEn+yHdoCPqKOLRjbmXU/k=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$hooks$2f$useFilters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilterValues"]
    ];
});
_c = FilterSidebar;
var _c;
__turbopack_context__.k.register(_c, "FilterSidebar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/ui/products/Product.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "action": "Product-module__E1buCG__action",
  "addButton": "Product-module__E1buCG__addButton",
  "card": "Product-module__E1buCG__card",
  "category": "Product-module__E1buCG__category",
  "content": "Product-module__E1buCG__content",
  "description": "Product-module__E1buCG__description",
  "imageWrapper": "Product-module__E1buCG__imageWrapper",
  "loadingPlaceholder": "Product-module__E1buCG__loadingPlaceholder",
  "meta": "Product-module__E1buCG__meta",
  "price": "Product-module__E1buCG__price",
  "productImage": "Product-module__E1buCG__productImage",
  "productLink": "Product-module__E1buCG__productLink",
  "rating": "Product-module__E1buCG__rating",
  "selector": "Product-module__E1buCG__selector",
  "selectorRow": "Product-module__E1buCG__selectorRow",
  "spin": "Product-module__E1buCG__spin",
  "title": "Product-module__E1buCG__title",
  "titleBar": "Product-module__E1buCG__titleBar",
});
}),
"[project]/frontend/ui/products/Product.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Producto
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$Product$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/frontend/ui/products/Product.module.css [app-client] (css module)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$context$2f$cartStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/context/cartStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
function Producto(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(125);
    if ($[0] !== "a2c56418156aeb8ec013d3b3212b6f0db192459c25aa805ea4a1ffb2a986e35e") {
        for(let $i = 0; $i < 125; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "a2c56418156aeb8ec013d3b3212b6f0db192459c25aa805ea4a1ffb2a986e35e";
    }
    const { props } = t0;
    const { title, price, description, category, variants } = props;
    const firstVariant = variants[0];
    let t1;
    if ($[1] !== firstVariant?.slug || $[2] !== title) {
        t1 = firstVariant?.slug || title.toLowerCase().replace(/\s+/g, "-");
        $[1] = firstVariant?.slug;
        $[2] = title;
        $[3] = t1;
    } else {
        t1 = $[3];
    }
    const productSlug = t1;
    const [selectedColor, setSelectedColor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(firstVariant?.color ?? "");
    const [selectedSize, setSelectedSize] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(firstVariant?.size || null);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [isAdding, setIsAdding] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const addItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$context$2f$cartStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCartStore"])(_ProductoUseCartStore);
    let handleAddToCart;
    let t10;
    let t11;
    let t12;
    let t13;
    let t14;
    let t15;
    let t16;
    let t17;
    let t18;
    let t19;
    let t2;
    let t20;
    let t3;
    let t4;
    let t5;
    let t6;
    let t7;
    let t8;
    let t9;
    if ($[4] !== addItem || $[5] !== category || $[6] !== description || $[7] !== firstVariant || $[8] !== isAdding || $[9] !== loading || $[10] !== price || $[11] !== productSlug || $[12] !== selectedColor || $[13] !== selectedSize || $[14] !== title || $[15] !== variants) {
        t20 = Symbol.for("react.early_return_sentinel");
        bb0: {
            const uniqueColors = variants.filter(_ProductoVariantsFilter);
            let t21;
            if ($[36] !== selectedColor) {
                t21 = ({
                    "Producto[variants.filter()]": (v_0)=>v_0.color === selectedColor && v_0.size
                })["Producto[variants.filter()]"];
                $[36] = selectedColor;
                $[37] = t21;
            } else {
                t21 = $[37];
            }
            const uniqueSizes = variants.filter(t21).map(_ProductoAnonymous).filter(_ProductoAnonymous2);
            let t22;
            if ($[38] !== firstVariant || $[39] !== selectedColor || $[40] !== variants) {
                t22 = variants.find({
                    "Producto[variants.find()]": (v_2)=>v_2.color === selectedColor
                }["Producto[variants.find()]"]) || firstVariant;
                $[38] = firstVariant;
                $[39] = selectedColor;
                $[40] = variants;
                $[41] = t22;
            } else {
                t22 = $[41];
            }
            const imageVariant = t22;
            let t23;
            if ($[42] !== firstVariant || $[43] !== selectedColor || $[44] !== selectedSize || $[45] !== variants) {
                t23 = variants.find({
                    "Producto[variants.find()]": (v_4)=>v_4.color === selectedColor && v_4.size === selectedSize
                }["Producto[variants.find()]"]) || variants.find({
                    "Producto[variants.find()]": (v_3)=>v_3.color === selectedColor
                }["Producto[variants.find()]"]) || firstVariant;
                $[42] = firstVariant;
                $[43] = selectedColor;
                $[44] = selectedSize;
                $[45] = variants;
                $[46] = t23;
            } else {
                t23 = $[46];
            }
            const cartVariant = t23;
            if (!firstVariant) {
                t20 = null;
                break bb0;
            }
            let t24;
            if ($[47] !== variants) {
                t24 = ({
                    "Producto[handleColorChange]": (event)=>{
                        const newColor = event.target.value;
                        setSelectedColor(newColor);
                        const sizesForColor = variants.filter({
                            "Producto[handleColorChange > variants.filter()]": (v_5)=>v_5.color === newColor && v_5.size
                        }["Producto[handleColorChange > variants.filter()]"]).map(_ProductoHandleColorChangeAnonymous);
                        if (sizesForColor.length > 0) {
                            setSelectedSize(sizesForColor[0]);
                        }
                        setLoading(true);
                    }
                })["Producto[handleColorChange]"];
                $[47] = variants;
                $[48] = t24;
            } else {
                t24 = $[48];
            }
            const handleColorChange = t24;
            let t25;
            if ($[49] === Symbol.for("react.memo_cache_sentinel")) {
                t25 = ({
                    "Producto[handleSizeChange]": (event_0)=>{
                        setSelectedSize(event_0.target.value);
                    }
                })["Producto[handleSizeChange]"];
                $[49] = t25;
            } else {
                t25 = $[49];
            }
            const handleSizeChange = t25;
            let t26;
            if ($[50] !== addItem || $[51] !== cartVariant || $[52] !== isAdding || $[53] !== price || $[54] !== productSlug || $[55] !== title) {
                t26 = ({
                    "Producto[handleAddToCart]": ()=>{
                        if (isAdding) {
                            return;
                        }
                        setIsAdding(true);
                        addItem({
                            slug: productSlug,
                            title,
                            price,
                            quantity: 1,
                            variant: cartVariant,
                            image: cartVariant.image
                        });
                        setTimeout({
                            "Producto[handleAddToCart > setTimeout()]": ()=>setIsAdding(false)
                        }["Producto[handleAddToCart > setTimeout()]"], 600);
                    }
                })["Producto[handleAddToCart]"];
                $[50] = addItem;
                $[51] = cartVariant;
                $[52] = isAdding;
                $[53] = price;
                $[54] = productSlug;
                $[55] = title;
                $[56] = t26;
            } else {
                t26 = $[56];
            }
            handleAddToCart = t26;
            t17 = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$Product$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].card;
            t18 = `product-title-${productSlug}`;
            const t27 = `/products/${productSlug}`;
            let t28;
            if ($[57] !== loading) {
                t28 = loading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$Product$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].loadingPlaceholder
                }, void 0, false, {
                    fileName: "[project]/frontend/ui/products/Product.tsx",
                    lineNumber: 182,
                    columnNumber: 26
                }, this);
                $[57] = loading;
                $[58] = t28;
            } else {
                t28 = $[58];
            }
            const t29 = loading ? 0 : 1;
            let t30;
            if ($[59] !== t29) {
                t30 = {
                    objectFit: "contain",
                    opacity: t29
                };
                $[59] = t29;
                $[60] = t30;
            } else {
                t30 = $[60];
            }
            let t31;
            if ($[61] === Symbol.for("react.memo_cache_sentinel")) {
                t31 = ({
                    "Producto[<Image>.onLoad]": ()=>setLoading(false)
                })["Producto[<Image>.onLoad]"];
                $[61] = t31;
            } else {
                t31 = $[61];
            }
            let t32;
            if ($[62] !== imageVariant.image || $[63] !== t30 || $[64] !== title) {
                t32 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    src: imageVariant.image,
                    alt: title,
                    fill: true,
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$Product$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].productImage,
                    style: t30,
                    onLoad: t31
                }, void 0, false, {
                    fileName: "[project]/frontend/ui/products/Product.tsx",
                    lineNumber: 211,
                    columnNumber: 15
                }, this);
                $[62] = imageVariant.image;
                $[63] = t30;
                $[64] = title;
                $[65] = t32;
            } else {
                t32 = $[65];
            }
            let t33;
            if ($[66] !== t28 || $[67] !== t32) {
                t33 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$Product$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].imageWrapper,
                    children: [
                        t28,
                        t32
                    ]
                }, void 0, true, {
                    fileName: "[project]/frontend/ui/products/Product.tsx",
                    lineNumber: 221,
                    columnNumber: 15
                }, this);
                $[66] = t28;
                $[67] = t32;
                $[68] = t33;
            } else {
                t33 = $[68];
            }
            if ($[69] !== t27 || $[70] !== t33) {
                t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$Product$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].productLink,
                    href: t27,
                    children: t33
                }, void 0, false, {
                    fileName: "[project]/frontend/ui/products/Product.tsx",
                    lineNumber: 229,
                    columnNumber: 15
                }, this);
                $[69] = t27;
                $[70] = t33;
                $[71] = t19;
            } else {
                t19 = $[71];
            }
            t13 = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$Product$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].content;
            const t34 = `product-title-${productSlug}`;
            let t35;
            if ($[72] !== t34 || $[73] !== title) {
                t35 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                    id: t34,
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$Product$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].title,
                    children: title
                }, void 0, false, {
                    fileName: "[project]/frontend/ui/products/Product.tsx",
                    lineNumber: 240,
                    columnNumber: 15
                }, this);
                $[72] = t34;
                $[73] = title;
                $[74] = t35;
            } else {
                t35 = $[74];
            }
            let t36;
            if ($[75] !== category) {
                t36 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$Product$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].category,
                    children: category
                }, void 0, false, {
                    fileName: "[project]/frontend/ui/products/Product.tsx",
                    lineNumber: 249,
                    columnNumber: 15
                }, this);
                $[75] = category;
                $[76] = t36;
            } else {
                t36 = $[76];
            }
            if ($[77] !== t35 || $[78] !== t36) {
                t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$Product$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].titleBar,
                    children: [
                        t35,
                        t36
                    ]
                }, void 0, true, {
                    fileName: "[project]/frontend/ui/products/Product.tsx",
                    lineNumber: 256,
                    columnNumber: 15
                }, this);
                $[77] = t35;
                $[78] = t36;
                $[79] = t14;
            } else {
                t14 = $[79];
            }
            if ($[80] !== description) {
                t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$Product$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].description,
                    children: description
                }, void 0, false, {
                    fileName: "[project]/frontend/ui/products/Product.tsx",
                    lineNumber: 264,
                    columnNumber: 15
                }, this);
                $[80] = description;
                $[81] = t15;
            } else {
                t15 = $[81];
            }
            let t37;
            if ($[82] !== price) {
                t37 = price.toFixed(2);
                $[82] = price;
                $[83] = t37;
            } else {
                t37 = $[83];
            }
            if ($[84] !== t37) {
                t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$Product$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].meta,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$Product$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].price,
                        children: [
                            "Precio:  $",
                            t37
                        ]
                    }, void 0, true, {
                        fileName: "[project]/frontend/ui/products/Product.tsx",
                        lineNumber: 279,
                        columnNumber: 44
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/frontend/ui/products/Product.tsx",
                    lineNumber: 279,
                    columnNumber: 15
                }, this);
                $[84] = t37;
                $[85] = t16;
            } else {
                t16 = $[85];
            }
            t9 = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$Product$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].selectorRow;
            const t38 = `color-${productSlug}`;
            if ($[86] !== t38) {
                t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    htmlFor: t38,
                    className: "sr-only",
                    children: "Color"
                }, void 0, false, {
                    fileName: "[project]/frontend/ui/products/Product.tsx",
                    lineNumber: 288,
                    columnNumber: 15
                }, this);
                $[86] = t38;
                $[87] = t10;
            } else {
                t10 = $[87];
            }
            const t39 = `color-${productSlug}`;
            const t40 = uniqueColors.map(_ProductoUniqueColorsMap);
            if ($[88] !== handleColorChange || $[89] !== selectedColor || $[90] !== t39 || $[91] !== t40) {
                t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                    onChange: handleColorChange,
                    id: t39,
                    name: "color",
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$Product$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].selector,
                    value: selectedColor,
                    children: t40
                }, void 0, false, {
                    fileName: "[project]/frontend/ui/products/Product.tsx",
                    lineNumber: 297,
                    columnNumber: 15
                }, this);
                $[88] = handleColorChange;
                $[89] = selectedColor;
                $[90] = t39;
                $[91] = t40;
                $[92] = t11;
            } else {
                t11 = $[92];
            }
            const t41 = `size-${productSlug}`;
            if ($[93] !== t41) {
                t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    htmlFor: t41,
                    className: "sr-only",
                    children: "Talla"
                }, void 0, false, {
                    fileName: "[project]/frontend/ui/products/Product.tsx",
                    lineNumber: 308,
                    columnNumber: 15
                }, this);
                $[93] = t41;
                $[94] = t12;
            } else {
                t12 = $[94];
            }
            t2 = handleSizeChange;
            t3 = `size-${productSlug}`;
            t4 = "size";
            t5 = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$Product$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].selector;
            t6 = selectedSize || "";
            t7 = uniqueSizes.length <= 1;
            t8 = uniqueSizes.map(_ProductoUniqueSizesMap);
        }
        $[4] = addItem;
        $[5] = category;
        $[6] = description;
        $[7] = firstVariant;
        $[8] = isAdding;
        $[9] = loading;
        $[10] = price;
        $[11] = productSlug;
        $[12] = selectedColor;
        $[13] = selectedSize;
        $[14] = title;
        $[15] = variants;
        $[16] = handleAddToCart;
        $[17] = t10;
        $[18] = t11;
        $[19] = t12;
        $[20] = t13;
        $[21] = t14;
        $[22] = t15;
        $[23] = t16;
        $[24] = t17;
        $[25] = t18;
        $[26] = t19;
        $[27] = t2;
        $[28] = t20;
        $[29] = t3;
        $[30] = t4;
        $[31] = t5;
        $[32] = t6;
        $[33] = t7;
        $[34] = t8;
        $[35] = t9;
    } else {
        handleAddToCart = $[16];
        t10 = $[17];
        t11 = $[18];
        t12 = $[19];
        t13 = $[20];
        t14 = $[21];
        t15 = $[22];
        t16 = $[23];
        t17 = $[24];
        t18 = $[25];
        t19 = $[26];
        t2 = $[27];
        t20 = $[28];
        t3 = $[29];
        t4 = $[30];
        t5 = $[31];
        t6 = $[32];
        t7 = $[33];
        t8 = $[34];
        t9 = $[35];
    }
    if (t20 !== Symbol.for("react.early_return_sentinel")) {
        return t20;
    }
    let t21;
    if ($[95] !== t2 || $[96] !== t3 || $[97] !== t4 || $[98] !== t5 || $[99] !== t6 || $[100] !== t7 || $[101] !== t8) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
            onChange: t2,
            id: t3,
            name: t4,
            className: t5,
            value: t6,
            disabled: t7,
            children: t8
        }, void 0, false, {
            fileName: "[project]/frontend/ui/products/Product.tsx",
            lineNumber: 381,
            columnNumber: 11
        }, this);
        $[95] = t2;
        $[96] = t3;
        $[97] = t4;
        $[98] = t5;
        $[99] = t6;
        $[100] = t7;
        $[101] = t8;
        $[102] = t21;
    } else {
        t21 = $[102];
    }
    let t22;
    if ($[103] !== t10 || $[104] !== t11 || $[105] !== t12 || $[106] !== t21 || $[107] !== t9) {
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t9,
            children: [
                t10,
                t11,
                t12,
                t21
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/ui/products/Product.tsx",
            lineNumber: 395,
            columnNumber: 11
        }, this);
        $[103] = t10;
        $[104] = t11;
        $[105] = t12;
        $[106] = t21;
        $[107] = t9;
        $[108] = t22;
    } else {
        t22 = $[108];
    }
    const t23 = isAdding ? "A\xF1adido!" : "Agregar al carrito";
    let t24;
    if ($[109] !== handleAddToCart || $[110] !== isAdding || $[111] !== t23) {
        t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$Product$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].action,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$Product$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].addButton,
                onClick: handleAddToCart,
                disabled: isAdding,
                children: t23
            }, void 0, false, {
                fileName: "[project]/frontend/ui/products/Product.tsx",
                lineNumber: 408,
                columnNumber: 42
            }, this)
        }, void 0, false, {
            fileName: "[project]/frontend/ui/products/Product.tsx",
            lineNumber: 408,
            columnNumber: 11
        }, this);
        $[109] = handleAddToCart;
        $[110] = isAdding;
        $[111] = t23;
        $[112] = t24;
    } else {
        t24 = $[112];
    }
    let t25;
    if ($[113] !== t13 || $[114] !== t14 || $[115] !== t15 || $[116] !== t16 || $[117] !== t22 || $[118] !== t24) {
        t25 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: t13,
            children: [
                t14,
                t15,
                t16,
                t22,
                t24
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/ui/products/Product.tsx",
            lineNumber: 418,
            columnNumber: 11
        }, this);
        $[113] = t13;
        $[114] = t14;
        $[115] = t15;
        $[116] = t16;
        $[117] = t22;
        $[118] = t24;
        $[119] = t25;
    } else {
        t25 = $[119];
    }
    let t26;
    if ($[120] !== t17 || $[121] !== t18 || $[122] !== t19 || $[123] !== t25) {
        t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
            className: t17,
            "aria-labelledby": t18,
            children: [
                t19,
                t25
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/ui/products/Product.tsx",
            lineNumber: 431,
            columnNumber: 11
        }, this);
        $[120] = t17;
        $[121] = t18;
        $[122] = t19;
        $[123] = t25;
        $[124] = t26;
    } else {
        t26 = $[124];
    }
    return t26;
}
_s(Producto, "ZQoJpzya9b1uxS7ZEa4nZYjwyvI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$context$2f$cartStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCartStore"]
    ];
});
_c = Producto;
function _ProductoUniqueSizesMap(size_0, index_0) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
        value: size_0,
        children: size_0
    }, index_0, false, {
        fileName: "[project]/frontend/ui/products/Product.tsx",
        lineNumber: 443,
        columnNumber: 10
    }, this);
}
function _ProductoUniqueColorsMap(v_7) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
        value: v_7.color,
        children: v_7.color
    }, v_7.slug, false, {
        fileName: "[project]/frontend/ui/products/Product.tsx",
        lineNumber: 446,
        columnNumber: 10
    }, this);
}
function _ProductoHandleColorChangeAnonymous(v_6) {
    return v_6.size;
}
function _ProductoAnonymous2(size, index, arr_0) {
    return arr_0.indexOf(size) === index;
}
function _ProductoAnonymous(v_1) {
    return v_1.size;
}
function _ProductoVariantsFilter(v, i, arr) {
    return arr.findIndex({
        "Producto[variants.filter() > arr.findIndex()]": (v2)=>v2.color === v.color
    }["Producto[variants.filter() > arr.findIndex()]"]) === i;
}
function _ProductoUseCartStore(state) {
    return state.addItem;
}
var _c;
__turbopack_context__.k.register(_c, "Producto");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/ui/products/FilterDrawer.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "applyBtn": "FilterDrawer-module__NgTATa__applyBtn",
  "clearBtn": "FilterDrawer-module__NgTATa__clearBtn",
  "closeBtn": "FilterDrawer-module__NgTATa__closeBtn",
  "content": "FilterDrawer-module__NgTATa__content",
  "currency": "FilterDrawer-module__NgTATa__currency",
  "drawer": "FilterDrawer-module__NgTATa__drawer",
  "fadeIn": "FilterDrawer-module__NgTATa__fadeIn",
  "footer": "FilterDrawer-module__NgTATa__footer",
  "header": "FilterDrawer-module__NgTATa__header",
  "labelText": "FilterDrawer-module__NgTATa__labelText",
  "overlay": "FilterDrawer-module__NgTATa__overlay",
  "priceInput": "FilterDrawer-module__NgTATa__priceInput",
  "priceRange": "FilterDrawer-module__NgTATa__priceRange",
  "priceWrapper": "FilterDrawer-module__NgTATa__priceWrapper",
  "radio": "FilterDrawer-module__NgTATa__radio",
  "radioGroup": "FilterDrawer-module__NgTATa__radioGroup",
  "radioLabel": "FilterDrawer-module__NgTATa__radioLabel",
  "radioMark": "FilterDrawer-module__NgTATa__radioMark",
  "rangeLabels": "FilterDrawer-module__NgTATa__rangeLabels",
  "rangeSlider": "FilterDrawer-module__NgTATa__rangeSlider",
  "searchIcon": "FilterDrawer-module__NgTATa__searchIcon",
  "searchInput": "FilterDrawer-module__NgTATa__searchInput",
  "searchWrapper": "FilterDrawer-module__NgTATa__searchWrapper",
  "section": "FilterDrawer-module__NgTATa__section",
  "sectionTitle": "FilterDrawer-module__NgTATa__sectionTitle",
  "slideIn": "FilterDrawer-module__NgTATa__slideIn",
  "title": "FilterDrawer-module__NgTATa__title",
});
}),
"[project]/frontend/ui/products/FilterDrawer.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>FilterDrawer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$hooks$2f$useFilters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/hooks/useFilters.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterDrawer$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/frontend/ui/products/FilterDrawer.module.css [app-client] (css module)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
function FilterDrawer(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(65);
    if ($[0] !== "c62f3bb2508576c8c7bfb103c71c22ca597206cafaaeeeba1a51cb21129ae0bf") {
        for(let $i = 0; $i < 65; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "c62f3bb2508576c8c7bfb103c71c22ca597206cafaaeeeba1a51cb21129ae0bf";
    }
    const { products, onClose } = t0;
    let t1;
    if ($[1] !== products) {
        t1 = products || [];
        $[1] = products;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    let t2;
    if ($[3] !== t1) {
        t2 = {
            products: t1
        };
        $[3] = t1;
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    const { filters, localSearch, setFilter, clearFilters, hasActiveFilters, uniqueCategories } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$hooks$2f$useFilters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilterValues"])(t2);
    let t3;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = [];
        $[5] = t3;
    } else {
        t3 = $[5];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(_FilterDrawerUseEffect, t3);
    let t4;
    if ($[6] !== onClose) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterDrawer$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].overlay,
            onClick: onClose,
            "aria-hidden": "true"
        }, void 0, false, {
            fileName: "[project]/frontend/ui/products/FilterDrawer.tsx",
            lineNumber: 60,
            columnNumber: 10
        }, this);
        $[6] = onClose;
        $[7] = t4;
    } else {
        t4 = $[7];
    }
    let t5;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterDrawer$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].title,
            children: "Filtros"
        }, void 0, false, {
            fileName: "[project]/frontend/ui/products/FilterDrawer.tsx",
            lineNumber: 68,
            columnNumber: 10
        }, this);
        $[8] = t5;
    } else {
        t5 = $[8];
    }
    let t6;
    if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "24",
            height: "24",
            viewBox: "0 0 24 24",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "2",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                    x1: "18",
                    y1: "6",
                    x2: "6",
                    y2: "18"
                }, void 0, false, {
                    fileName: "[project]/frontend/ui/products/FilterDrawer.tsx",
                    lineNumber: 75,
                    columnNumber: 108
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                    x1: "6",
                    y1: "6",
                    x2: "18",
                    y2: "18"
                }, void 0, false, {
                    fileName: "[project]/frontend/ui/products/FilterDrawer.tsx",
                    lineNumber: 75,
                    columnNumber: 146
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/ui/products/FilterDrawer.tsx",
            lineNumber: 75,
            columnNumber: 10
        }, this);
        $[9] = t6;
    } else {
        t6 = $[9];
    }
    let t7;
    if ($[10] !== onClose) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterDrawer$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].header,
            children: [
                t5,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    type: "button",
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterDrawer$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].closeBtn,
                    onClick: onClose,
                    "aria-label": "Cerrar filtros",
                    children: t6
                }, void 0, false, {
                    fileName: "[project]/frontend/ui/products/FilterDrawer.tsx",
                    lineNumber: 82,
                    columnNumber: 48
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/ui/products/FilterDrawer.tsx",
            lineNumber: 82,
            columnNumber: 10
        }, this);
        $[10] = onClose;
        $[11] = t7;
    } else {
        t7 = $[11];
    }
    let t8;
    if ($[12] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterDrawer$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sectionTitle,
            children: "Buscar"
        }, void 0, false, {
            fileName: "[project]/frontend/ui/products/FilterDrawer.tsx",
            lineNumber: 90,
            columnNumber: 10
        }, this);
        $[12] = t8;
    } else {
        t8 = $[12];
    }
    let t9;
    if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterDrawer$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].searchIcon,
            width: "18",
            height: "18",
            viewBox: "0 0 24 24",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "2",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                    cx: "11",
                    cy: "11",
                    r: "8"
                }, void 0, false, {
                    fileName: "[project]/frontend/ui/products/FilterDrawer.tsx",
                    lineNumber: 97,
                    columnNumber: 138
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                    x1: "21",
                    y1: "21",
                    x2: "16.65",
                    y2: "16.65"
                }, void 0, false, {
                    fileName: "[project]/frontend/ui/products/FilterDrawer.tsx",
                    lineNumber: 97,
                    columnNumber: 170
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/ui/products/FilterDrawer.tsx",
            lineNumber: 97,
            columnNumber: 10
        }, this);
        $[13] = t9;
    } else {
        t9 = $[13];
    }
    let t10;
    if ($[14] !== setFilter) {
        t10 = ({
            "FilterDrawer[<input>.onChange]": (e)=>setFilter("search", e.target.value)
        })["FilterDrawer[<input>.onChange]"];
        $[14] = setFilter;
        $[15] = t10;
    } else {
        t10 = $[15];
    }
    let t11;
    if ($[16] !== localSearch || $[17] !== t10) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterDrawer$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].section,
            children: [
                t8,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterDrawer$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].searchWrapper,
                    children: [
                        t9,
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            type: "search",
                            id: "search",
                            name: "search",
                            placeholder: "Buscar productos...",
                            value: localSearch,
                            onChange: t10,
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterDrawer$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].searchInput
                        }, void 0, false, {
                            fileName: "[project]/frontend/ui/products/FilterDrawer.tsx",
                            lineNumber: 114,
                            columnNumber: 89
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/frontend/ui/products/FilterDrawer.tsx",
                    lineNumber: 114,
                    columnNumber: 47
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/ui/products/FilterDrawer.tsx",
            lineNumber: 114,
            columnNumber: 11
        }, this);
        $[16] = localSearch;
        $[17] = t10;
        $[18] = t11;
    } else {
        t11 = $[18];
    }
    let t12;
    if ($[19] === Symbol.for("react.memo_cache_sentinel")) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterDrawer$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sectionTitle,
            children: "Categoría"
        }, void 0, false, {
            fileName: "[project]/frontend/ui/products/FilterDrawer.tsx",
            lineNumber: 123,
            columnNumber: 11
        }, this);
        $[19] = t12;
    } else {
        t12 = $[19];
    }
    const t13 = filters.category === "";
    let t14;
    if ($[20] !== setFilter) {
        t14 = ({
            "FilterDrawer[<input>.onChange]": ()=>setFilter("category", "")
        })["FilterDrawer[<input>.onChange]"];
        $[20] = setFilter;
        $[21] = t14;
    } else {
        t14 = $[21];
    }
    let t15;
    if ($[22] !== t13 || $[23] !== t14) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
            type: "radio",
            name: "category",
            value: "",
            checked: t13,
            onChange: t14,
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterDrawer$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].radio
        }, void 0, false, {
            fileName: "[project]/frontend/ui/products/FilterDrawer.tsx",
            lineNumber: 141,
            columnNumber: 11
        }, this);
        $[22] = t13;
        $[23] = t14;
        $[24] = t15;
    } else {
        t15 = $[24];
    }
    let t16;
    let t17;
    if ($[25] === Symbol.for("react.memo_cache_sentinel")) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterDrawer$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].radioMark
        }, void 0, false, {
            fileName: "[project]/frontend/ui/products/FilterDrawer.tsx",
            lineNumber: 151,
            columnNumber: 11
        }, this);
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterDrawer$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].labelText,
            children: "Todas"
        }, void 0, false, {
            fileName: "[project]/frontend/ui/products/FilterDrawer.tsx",
            lineNumber: 152,
            columnNumber: 11
        }, this);
        $[25] = t16;
        $[26] = t17;
    } else {
        t16 = $[25];
        t17 = $[26];
    }
    let t18;
    if ($[27] !== t15) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterDrawer$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].radioLabel,
            children: [
                t15,
                t16,
                t17
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/ui/products/FilterDrawer.tsx",
            lineNumber: 161,
            columnNumber: 11
        }, this);
        $[27] = t15;
        $[28] = t18;
    } else {
        t18 = $[28];
    }
    let t19;
    if ($[29] !== filters.category || $[30] !== setFilter || $[31] !== uniqueCategories) {
        let t20;
        if ($[33] !== filters.category || $[34] !== setFilter) {
            t20 = ({
                "FilterDrawer[uniqueCategories.map()]": (category)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterDrawer$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].radioLabel,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "radio",
                                name: "category",
                                value: category,
                                checked: filters.category === category,
                                onChange: {
                                    "FilterDrawer[uniqueCategories.map() > <input>.onChange]": ()=>setFilter("category", category)
                                }["FilterDrawer[uniqueCategories.map() > <input>.onChange]"],
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterDrawer$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].radio
                            }, void 0, false, {
                                fileName: "[project]/frontend/ui/products/FilterDrawer.tsx",
                                lineNumber: 172,
                                columnNumber: 113
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterDrawer$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].radioMark
                            }, void 0, false, {
                                fileName: "[project]/frontend/ui/products/FilterDrawer.tsx",
                                lineNumber: 174,
                                columnNumber: 100
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterDrawer$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].labelText,
                                children: category
                            }, void 0, false, {
                                fileName: "[project]/frontend/ui/products/FilterDrawer.tsx",
                                lineNumber: 174,
                                columnNumber: 137
                            }, this)
                        ]
                    }, category, true, {
                        fileName: "[project]/frontend/ui/products/FilterDrawer.tsx",
                        lineNumber: 172,
                        columnNumber: 61
                    }, this)
            })["FilterDrawer[uniqueCategories.map()]"];
            $[33] = filters.category;
            $[34] = setFilter;
            $[35] = t20;
        } else {
            t20 = $[35];
        }
        t19 = uniqueCategories.map(t20);
        $[29] = filters.category;
        $[30] = setFilter;
        $[31] = uniqueCategories;
        $[32] = t19;
    } else {
        t19 = $[32];
    }
    let t20;
    if ($[36] !== t18 || $[37] !== t19) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterDrawer$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].section,
            children: [
                t12,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterDrawer$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].radioGroup,
                    children: [
                        t18,
                        t19
                    ]
                }, void 0, true, {
                    fileName: "[project]/frontend/ui/products/FilterDrawer.tsx",
                    lineNumber: 192,
                    columnNumber: 48
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/ui/products/FilterDrawer.tsx",
            lineNumber: 192,
            columnNumber: 11
        }, this);
        $[36] = t18;
        $[37] = t19;
        $[38] = t20;
    } else {
        t20 = $[38];
    }
    let t21;
    if ($[39] === Symbol.for("react.memo_cache_sentinel")) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterDrawer$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].sectionTitle,
            children: "Precio máximo"
        }, void 0, false, {
            fileName: "[project]/frontend/ui/products/FilterDrawer.tsx",
            lineNumber: 201,
            columnNumber: 11
        }, this);
        $[39] = t21;
    } else {
        t21 = $[39];
    }
    let t22;
    if ($[40] === Symbol.for("react.memo_cache_sentinel")) {
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterDrawer$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].currency,
            children: "$"
        }, void 0, false, {
            fileName: "[project]/frontend/ui/products/FilterDrawer.tsx",
            lineNumber: 208,
            columnNumber: 11
        }, this);
        $[40] = t22;
    } else {
        t22 = $[40];
    }
    let t23;
    if ($[41] !== setFilter) {
        t23 = ({
            "FilterDrawer[<input>.onChange]": (e_0)=>setFilter("maxPrice", e_0.target.value)
        })["FilterDrawer[<input>.onChange]"];
        $[41] = setFilter;
        $[42] = t23;
    } else {
        t23 = $[42];
    }
    let t24;
    if ($[43] !== filters.maxPrice || $[44] !== t23) {
        t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterDrawer$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].section,
            children: [
                t21,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterDrawer$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].priceWrapper,
                    children: [
                        t22,
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            type: "number",
                            id: "maxPrice",
                            name: "maxPrice",
                            min: "0",
                            placeholder: "Ej: 500",
                            value: filters.maxPrice,
                            onChange: t23,
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterDrawer$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].priceInput
                        }, void 0, false, {
                            fileName: "[project]/frontend/ui/products/FilterDrawer.tsx",
                            lineNumber: 225,
                            columnNumber: 90
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/frontend/ui/products/FilterDrawer.tsx",
                    lineNumber: 225,
                    columnNumber: 48
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/ui/products/FilterDrawer.tsx",
            lineNumber: 225,
            columnNumber: 11
        }, this);
        $[43] = filters.maxPrice;
        $[44] = t23;
        $[45] = t24;
    } else {
        t24 = $[45];
    }
    let t25;
    if ($[46] !== t11 || $[47] !== t20 || $[48] !== t24) {
        t25 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterDrawer$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].content,
            children: [
                t11,
                t20,
                t24
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/ui/products/FilterDrawer.tsx",
            lineNumber: 234,
            columnNumber: 11
        }, this);
        $[46] = t11;
        $[47] = t20;
        $[48] = t24;
        $[49] = t25;
    } else {
        t25 = $[49];
    }
    const t26 = !hasActiveFilters;
    let t27;
    if ($[50] !== clearFilters || $[51] !== t26) {
        t27 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: "button",
            onClick: clearFilters,
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterDrawer$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].clearBtn,
            disabled: t26,
            children: "Limpiar"
        }, void 0, false, {
            fileName: "[project]/frontend/ui/products/FilterDrawer.tsx",
            lineNumber: 245,
            columnNumber: 11
        }, this);
        $[50] = clearFilters;
        $[51] = t26;
        $[52] = t27;
    } else {
        t27 = $[52];
    }
    let t28;
    if ($[53] !== onClose) {
        t28 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: "button",
            onClick: onClose,
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterDrawer$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].applyBtn,
            children: "Ver resultados"
        }, void 0, false, {
            fileName: "[project]/frontend/ui/products/FilterDrawer.tsx",
            lineNumber: 254,
            columnNumber: 11
        }, this);
        $[53] = onClose;
        $[54] = t28;
    } else {
        t28 = $[54];
    }
    let t29;
    if ($[55] !== t27 || $[56] !== t28) {
        t29 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("footer", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterDrawer$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].footer,
            children: [
                t27,
                t28
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/ui/products/FilterDrawer.tsx",
            lineNumber: 262,
            columnNumber: 11
        }, this);
        $[55] = t27;
        $[56] = t28;
        $[57] = t29;
    } else {
        t29 = $[57];
    }
    let t30;
    if ($[58] !== t25 || $[59] !== t29 || $[60] !== t7) {
        t30 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("aside", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterDrawer$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].drawer,
            role: "dialog",
            "aria-modal": "true",
            "aria-label": "Filtros de productos",
            children: [
                t7,
                t25,
                t29
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/ui/products/FilterDrawer.tsx",
            lineNumber: 271,
            columnNumber: 11
        }, this);
        $[58] = t25;
        $[59] = t29;
        $[60] = t7;
        $[61] = t30;
    } else {
        t30 = $[61];
    }
    let t31;
    if ($[62] !== t30 || $[63] !== t4) {
        t31 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                t4,
                t30
            ]
        }, void 0, true);
        $[62] = t30;
        $[63] = t4;
        $[64] = t31;
    } else {
        t31 = $[64];
    }
    return t31;
}
_s(FilterDrawer, "HjxzEeQS06GsCn8/t2ZsAfU7b0o=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$hooks$2f$useFilters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilterValues"]
    ];
});
_c = FilterDrawer;
function _FilterDrawerUseEffect() {
    document.body.style.overflow = "hidden";
    return _temp;
}
function _temp() {
    document.body.style.overflow = "";
}
var _c;
__turbopack_context__.k.register(_c, "FilterDrawer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/ui/products/FilterToggle.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "toggleBtn": "FilterToggle-module__LVsLkq__toggleBtn",
});
}),
"[project]/frontend/ui/products/FilterToggle.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>FilterToggle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterToggle$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/frontend/ui/products/FilterToggle.module.css [app-client] (css module)");
'use client';
;
;
;
function FilterToggle(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(5);
    if ($[0] !== "41737a3cafdb98e962007470e3d593d8bfc745dbeab3ddcdf9bbd678f050c341") {
        for(let $i = 0; $i < 5; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "41737a3cafdb98e962007470e3d593d8bfc745dbeab3ddcdf9bbd678f050c341";
    }
    const { onClick } = t0;
    let t1;
    let t2;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            width: "20",
            height: "20",
            viewBox: "0 0 24 24",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "2",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                    x1: "4",
                    y1: "6",
                    x2: "20",
                    y2: "6"
                }, void 0, false, {
                    fileName: "[project]/frontend/ui/products/FilterToggle.tsx",
                    lineNumber: 19,
                    columnNumber: 108
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                    x1: "8",
                    y1: "12",
                    x2: "20",
                    y2: "12"
                }, void 0, false, {
                    fileName: "[project]/frontend/ui/products/FilterToggle.tsx",
                    lineNumber: 19,
                    columnNumber: 145
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                    x1: "12",
                    y1: "18",
                    x2: "20",
                    y2: "18"
                }, void 0, false, {
                    fileName: "[project]/frontend/ui/products/FilterToggle.tsx",
                    lineNumber: 19,
                    columnNumber: 184
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/ui/products/FilterToggle.tsx",
            lineNumber: 19,
            columnNumber: 10
        }, this);
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            children: "Filtros"
        }, void 0, false, {
            fileName: "[project]/frontend/ui/products/FilterToggle.tsx",
            lineNumber: 20,
            columnNumber: 10
        }, this);
        $[1] = t1;
        $[2] = t2;
    } else {
        t1 = $[1];
        t2 = $[2];
    }
    let t3;
    if ($[3] !== onClick) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: "button",
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterToggle$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].toggleBtn,
            onClick: onClick,
            "aria-label": "Abrir filtros",
            children: [
                t1,
                t2
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/ui/products/FilterToggle.tsx",
            lineNumber: 29,
            columnNumber: 10
        }, this);
        $[3] = onClick;
        $[4] = t3;
    } else {
        t3 = $[4];
    }
    return t3;
}
_c = FilterToggle;
var _c;
__turbopack_context__.k.register(_c, "FilterToggle");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/ui/products/FilterMobile.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>FilterMobile
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterDrawer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/ui/products/FilterDrawer.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterToggle$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/ui/products/FilterToggle.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
function FilterMobile(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(7);
    if ($[0] !== "fd12072d084c37835ec167bf790b392b89f5098a069d6e146c8c0e6c69082747") {
        for(let $i = 0; $i < 7; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "fd12072d084c37835ec167bf790b392b89f5098a069d6e146c8c0e6c69082747";
    }
    const { products } = t0;
    const [drawerOpen, setDrawerOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterToggle$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            onClick: {
                "FilterMobile[<FilterToggle>.onClick]": ()=>setDrawerOpen(true)
            }["FilterMobile[<FilterToggle>.onClick]"]
        }, void 0, false, {
            fileName: "[project]/frontend/ui/products/FilterMobile.tsx",
            lineNumber: 25,
            columnNumber: 10
        }, this);
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    let t2;
    if ($[2] !== drawerOpen || $[3] !== products) {
        t2 = drawerOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterDrawer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            products: products,
            onClose: {
                "FilterMobile[<FilterDrawer>.onClose]": ()=>setDrawerOpen(false)
            }["FilterMobile[<FilterDrawer>.onClose]"]
        }, void 0, false, {
            fileName: "[project]/frontend/ui/products/FilterMobile.tsx",
            lineNumber: 34,
            columnNumber: 24
        }, this);
        $[2] = drawerOpen;
        $[3] = products;
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    let t3;
    if ($[5] !== t2) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                t1,
                t2
            ]
        }, void 0, true);
        $[5] = t2;
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    return t3;
}
_s(FilterMobile, "i0pHI9YMbVyneVc1gk5xK0P2xMQ=");
_c = FilterMobile;
var _c;
__turbopack_context__.k.register(_c, "FilterMobile");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/frontend/app/products/page.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "content": "page-module__ammgMW__content",
  "emptyState": "page-module__ammgMW__emptyState",
  "filterTogglePlaceholder": "page-module__ammgMW__filterTogglePlaceholder",
  "grid": "page-module__ammgMW__grid",
  "hero": "page-module__ammgMW__hero",
  "main": "page-module__ammgMW__main",
  "mobileHeader": "page-module__ammgMW__mobileHeader",
  "page": "page-module__ammgMW__page",
  "productItem": "page-module__ammgMW__productItem",
  "pulse": "page-module__ammgMW__pulse",
  "resultCount": "page-module__ammgMW__resultCount",
  "sortSelect": "page-module__ammgMW__sortSelect",
});
}),
"[project]/frontend/ui/products/ProductGrid.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ProductGrid
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$Product$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/ui/products/Product.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterMobile$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/ui/products/FilterMobile.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$hooks$2f$useFilters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/hooks/useFilters.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$app$2f$products$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/frontend/app/products/page.module.css [app-client] (css module)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
function ProductGridContent(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(20);
    if ($[0] !== "a9166ad4012dbda4ce37b0eba29c6786f099d928bbdb3144772777aac82ec9d5") {
        for(let $i = 0; $i < 20; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "a9166ad4012dbda4ce37b0eba29c6786f099d928bbdb3144772777aac82ec9d5";
    }
    const { products } = t0;
    let t1;
    if ($[1] !== products) {
        t1 = {
            products
        };
        $[1] = products;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const { filteredProducts, restoreScrollPosition } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$hooks$2f$useFilters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilters"])(t1);
    let t2;
    let t3;
    if ($[3] !== restoreScrollPosition) {
        t2 = ({
            "ProductGridContent[useEffect()]": ()=>{
                restoreScrollPosition();
            }
        })["ProductGridContent[useEffect()]"];
        t3 = [
            restoreScrollPosition
        ];
        $[3] = restoreScrollPosition;
        $[4] = t2;
        $[5] = t3;
    } else {
        t2 = $[4];
        t3 = $[5];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t2, t3);
    let t4;
    if ($[6] !== products) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$FilterMobile$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            products: products
        }, void 0, false, {
            fileName: "[project]/frontend/ui/products/ProductGrid.tsx",
            lineNumber: 54,
            columnNumber: 10
        }, this);
        $[6] = products;
        $[7] = t4;
    } else {
        t4 = $[7];
    }
    let t5;
    if ($[8] !== filteredProducts.length) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$app$2f$products$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].resultCount,
            children: [
                filteredProducts.length,
                " productos"
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/ui/products/ProductGrid.tsx",
            lineNumber: 62,
            columnNumber: 10
        }, this);
        $[8] = filteredProducts.length;
        $[9] = t5;
    } else {
        t5 = $[9];
    }
    let t6;
    if ($[10] !== t4 || $[11] !== t5) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$app$2f$products$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].mobileHeader,
            children: [
                t4,
                t5
            ]
        }, void 0, true, {
            fileName: "[project]/frontend/ui/products/ProductGrid.tsx",
            lineNumber: 70,
            columnNumber: 10
        }, this);
        $[10] = t4;
        $[11] = t5;
        $[12] = t6;
    } else {
        t6 = $[12];
    }
    let t7;
    if ($[13] !== filteredProducts) {
        t7 = filteredProducts.length > 0 ? filteredProducts.map(_ProductGridContentFilteredProductsMap) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$app$2f$products$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].emptyState,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                children: "No se encontraron productos con los filtros seleccionados."
            }, void 0, false, {
                fileName: "[project]/frontend/ui/products/ProductGrid.tsx",
                lineNumber: 79,
                columnNumber: 138
            }, this)
        }, void 0, false, {
            fileName: "[project]/frontend/ui/products/ProductGrid.tsx",
            lineNumber: 79,
            columnNumber: 103
        }, this);
        $[13] = filteredProducts;
        $[14] = t7;
    } else {
        t7 = $[14];
    }
    let t8;
    if ($[15] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$app$2f$products$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].grid,
            children: t7
        }, void 0, false, {
            fileName: "[project]/frontend/ui/products/ProductGrid.tsx",
            lineNumber: 87,
            columnNumber: 10
        }, this);
        $[15] = t7;
        $[16] = t8;
    } else {
        t8 = $[16];
    }
    let t9;
    if ($[17] !== t6 || $[18] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                t6,
                t8
            ]
        }, void 0, true);
        $[17] = t6;
        $[18] = t8;
        $[19] = t9;
    } else {
        t9 = $[19];
    }
    return t9;
}
_s(ProductGridContent, "l+eVXTxbc9YZdrvwwYDCGvj0aEE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$hooks$2f$useFilters$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilters"]
    ];
});
_c = ProductGridContent;
function _ProductGridContentFilteredProductsMap(product) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$app$2f$products$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].productItem,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ui$2f$products$2f$Product$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            props: product
        }, void 0, false, {
            fileName: "[project]/frontend/ui/products/ProductGrid.tsx",
            lineNumber: 105,
            columnNumber: 95
        }, this)
    }, product.variants[0]?.slug || product.title, false, {
        fileName: "[project]/frontend/ui/products/ProductGrid.tsx",
        lineNumber: 105,
        columnNumber: 10
    }, this);
}
function ProductGrid(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(4);
    if ($[0] !== "a9166ad4012dbda4ce37b0eba29c6786f099d928bbdb3144772777aac82ec9d5") {
        for(let $i = 0; $i < 4; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "a9166ad4012dbda4ce37b0eba29c6786f099d928bbdb3144772777aac82ec9d5";
    }
    const { products } = t0;
    if (!products || products.length === 0) {
        let t1;
        if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
            t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$app$2f$products$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].grid,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$app$2f$products$2f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].emptyState,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: "Cargando productos..."
                    }, void 0, false, {
                        fileName: "[project]/frontend/ui/products/ProductGrid.tsx",
                        lineNumber: 121,
                        columnNumber: 76
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/frontend/ui/products/ProductGrid.tsx",
                    lineNumber: 121,
                    columnNumber: 41
                }, this)
            }, void 0, false, {
                fileName: "[project]/frontend/ui/products/ProductGrid.tsx",
                lineNumber: 121,
                columnNumber: 12
            }, this);
            $[1] = t1;
        } else {
            t1 = $[1];
        }
        return t1;
    }
    let t1;
    if ($[2] !== products) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ProductGridContent, {
            products: products
        }, void 0, false, {
            fileName: "[project]/frontend/ui/products/ProductGrid.tsx",
            lineNumber: 130,
            columnNumber: 10
        }, this);
        $[2] = products;
        $[3] = t1;
    } else {
        t1 = $[3];
    }
    return t1;
}
_c1 = ProductGrid;
var _c, _c1;
__turbopack_context__.k.register(_c, "ProductGridContent");
__turbopack_context__.k.register(_c1, "ProductGrid");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=frontend_f1b38539._.js.map