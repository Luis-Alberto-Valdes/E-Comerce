(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__f100bfe3._.css",
  "static/chunks/frontend_1b6ca65a._.js"
],
    source: "dynamic"
});
