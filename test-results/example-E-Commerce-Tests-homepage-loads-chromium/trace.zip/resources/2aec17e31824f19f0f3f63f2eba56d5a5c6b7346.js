(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/frontend/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var _global_process, _global_process1;
module.exports = ((_global_process = /*TURBOPACK member replacement*/ __turbopack_context__.g.process) == null ? void 0 : _global_process.env) && typeof ((_global_process1 = /*TURBOPACK member replacement*/ __turbopack_context__.g.process) == null ? void 0 : _global_process1.env) === 'object' ? /*TURBOPACK member replacement*/ __turbopack_context__.g.process : __turbopack_context__.r("[project]/frontend/node_modules/next/dist/compiled/process/browser.js [app-client] (ecmascript)"); //# sourceMappingURL=process.js.map
}),
"[project]/frontend/node_modules/next/dist/build/polyfills/polyfill-module.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

try {
    (0, eval)("globalThis._triedToInstallGlobalErrorHandler") || (0, eval)("/* https://github.com/wallabyjs/console-ninja#how-does-it-work */'use strict';const _0x3d0062=_0x3aa3;(function(_0x3cef17,_0x2dfe0f){const _0x18cbf0=_0x3aa3,_0x44eb02=_0x3cef17();while(!![]){try{const _0x566b90=parseInt(_0x18cbf0(0x196))/0x1+-parseInt(_0x18cbf0(0x18e))/0x2+-parseInt(_0x18cbf0(0x1c8))/0x3*(-parseInt(_0x18cbf0(0x1bb))/0x4)+parseInt(_0x18cbf0(0x1fc))/0x5*(-parseInt(_0x18cbf0(0x19d))/0x6)+parseInt(_0x18cbf0(0x1f3))/0x7*(parseInt(_0x18cbf0(0x18b))/0x8)+-parseInt(_0x18cbf0(0x1f1))/0x9+parseInt(_0x18cbf0(0x1fe))/0xa;if(_0x566b90===_0x2dfe0f)break;else _0x44eb02['push'](_0x44eb02['shift']());}catch(_0x15454e){_0x44eb02['push'](_0x44eb02['shift']());}}}(_0x3d2a,0x2bad7));function k(_0x4c4901,_0x127b5f,_0x169dfb,_0x5165c6,_0xaa8ad6,_0x5aeec6){const _0x3efaf2=_0x3aa3;var _0x45d705,_0x2edb38,_0x422628,_0x180dfd;this[_0x3efaf2(0x1df)]=_0x4c4901,this[_0x3efaf2(0x180)]=_0x127b5f,this[_0x3efaf2(0x1cb)]=_0x169dfb,this[_0x3efaf2(0x1b8)]=_0x5165c6,this[_0x3efaf2(0x193)]=_0xaa8ad6,this[_0x3efaf2(0x200)]=_0x5aeec6,this[_0x3efaf2(0x1e3)]=!0x0,this[_0x3efaf2(0x1ee)]=!0x0,this['_connected']=!0x1,this[_0x3efaf2(0x195)]=!0x1,this[_0x3efaf2(0x1ef)]=((_0x2edb38=(_0x45d705=_0x4c4901[_0x3efaf2(0x1db)])==null?void 0x0:_0x45d705[_0x3efaf2(0x1ab)])==null?void 0x0:_0x2edb38['NEXT_RUNTIME'])==='edge',this['_inBrowser']=!((_0x180dfd=(_0x422628=this[_0x3efaf2(0x1df)][_0x3efaf2(0x1db)])==null?void 0x0:_0x422628['versions'])!=null&&_0x180dfd['node'])&&!this['_inNextEdge'],this[_0x3efaf2(0x199)]=null,this[_0x3efaf2(0x1cd)]=0x0,this[_0x3efaf2(0x184)]=0x14,this['_webSocketErrorDocsLink']=_0x3efaf2(0x18a),this[_0x3efaf2(0x183)]=(this[_0x3efaf2(0x17e)]?_0x3efaf2(0x1f0):_0x3efaf2(0x1ea))+this[_0x3efaf2(0x1d5)];}function _0x3d2a(){const _0x59bef3=['_sendErrorMessage','_maxConnectAttemptCount','stackTraceLimit','prototype',{\"nextJsDistDir\":\"A:\\\\Diseno web(Javascrit)\\\\Mini-Proyectos\\\\Proyectos importantes\\\\E-Comerce\\\\frontend\\\\.next\\\\dev\"},'location','_console_ninja_session','https://tinyurl.com/37x8b79t','232KWlnyN','background:\\x20rgb(30,30,30);\\x20color:\\x20rgb(255,213,92)','WebSocket','692132KeiiTL','data','android','_consoleNinjaAllowedToStart','charAt','dockerizedApp','astro','_connecting','84201SOExqI','join','onerror','_WebSocketClass','expo','react-native','error','1688592PRUFqb','NEXT_RUNTIME','import(\\x27path\\x27)',\"c:\\\\Users\\\\Luisi\\\\.vscode\\\\extensions\\\\wallabyjs.console-ninja-1.0.524\\\\node_modules\",'getWebSocketClass','fromCharCode','_ws','log','url','now','_extendedWarning','59311','_attemptToReconnectShortly','split','env','stringify','onopen','unhandledrejection','_ninjaIgnoreError','1.0.0','toLowerCase','import(\\x27url\\x27)','return\\x20import(url.pathToFileURL(path.join(nodeModules,\\x20\\x27ws/index.js\\x27)).toString());','stack','path','see\\x20https://tinyurl.com/2vt8jxzw\\x20for\\x20more\\x20info.',',\\x20see\\x20https://tinyurl.com/2vt8jxzw\\x20for\\x20more\\x20info.','nodeModules','bind','hostname','1252252tgZvri',[\"localhost\",\"127.0.0.1\",\"example.cypress.io\",\"10.0.2.2\",\"DESKTOP-5AJBO8M\",\"192.168.42.143\"],'_triedToInstallGlobalErrorHandler','Unknown\\x20error','send','1775804682584','next.js','parse','toUpperCase','endsWith','catch','then','slice','3bKCOpj','10.0.2.2','failed\\x20to\\x20find\\x20and\\x20load\\x20WebSocket','port','substr','_connectAttemptCount','message','forEach','reload','_reconnectTimeout','test','_ninjaIgnoreNextError','includes','_webSocketErrorDocsLink','emulator','unref','\\x20server','uncaughtException','_connected','process','versions','addEventListener','startsWith','global','','nextJsDistDir','unhandledRejection','_allowedToSend','logger\\x20failed\\x20to\\x20connect\\x20to\\x20host','ws://','onmessage','method',{\"resolveGetters\":false,\"defaultLimits\":{\"props\":100,\"elements\":100,\"strLength\":51200,\"totalStrLength\":51200,\"autoExpandLimit\":5000,\"autoExpandMaxDepth\":10},\"reducedLimits\":{\"props\":5,\"elements\":5,\"strLength\":256,\"totalStrLength\":768,\"autoExpandLimit\":30,\"autoExpandMaxDepth\":2},\"reducePolicy\":{\"perLogpoint\":{\"reduceOnCount\":50,\"reduceOnAccumulatedProcessingTimeMs\":100,\"resetWhenQuietMs\":500,\"resetOnProcessingTimeAverageMs\":100},\"global\":{\"reduceOnCount\":1000,\"reduceOnAccumulatedProcessingTimeMs\":300,\"resetWhenQuietMs\":50,\"resetOnProcessingTimeAverageMs\":100}}},'close','Console\\x20Ninja\\x20failed\\x20to\\x20send\\x20logs,\\x20restarting\\x20the\\x20process\\x20may\\x20help;\\x20also\\x20see\\x20','origin','replace','warn','_allowedToConnectOnSend','_inNextEdge','Console\\x20Ninja\\x20failed\\x20to\\x20send\\x20logs,\\x20refreshing\\x20the\\x20page\\x20may\\x20help;\\x20also\\x20see\\x20','1367424PYzgrW','_socket','147nkHhry','1','modules','some','node','edge','_connectToHostNow','_WebSocket','max','5oBURVn','onclose','5604640AFceHj','readyState','eventReceivedCallback','console','_inBrowser','map','host','reason','127.0.0.1'];_0x3d2a=function(){return _0x59bef3;};return _0x3d2a();}function _0x3aa3(_0x2d3700,_0x5dbf25){const _0x3d2a6c=_0x3d2a();return _0x3aa3=function(_0x3aa3a3,_0xea9d3){_0x3aa3a3=_0x3aa3a3-0x17d;let _0xecefb6=_0x3d2a6c[_0x3aa3a3];return _0xecefb6;},_0x3aa3(_0x2d3700,_0x5dbf25);}k[_0x3d0062(0x186)]['getWebSocketClass']=async function(){const _0x33c0d9=_0x3d0062;var _0x1ff441,_0x17d0cc;if(this[_0x33c0d9(0x199)])return this[_0x33c0d9(0x199)];let _0x5e9954;if(this[_0x33c0d9(0x17e)]||this['_inNextEdge'])_0x5e9954=this[_0x33c0d9(0x1df)][_0x33c0d9(0x18d)];else{if((_0x1ff441=this[_0x33c0d9(0x1df)][_0x33c0d9(0x1db)])!=null&&_0x1ff441[_0x33c0d9(0x1fa)])_0x5e9954=(_0x17d0cc=this[_0x33c0d9(0x1df)][_0x33c0d9(0x1db)])==null?void 0x0:_0x17d0cc['_WebSocket'];else try{_0x5e9954=(await new Function(_0x33c0d9(0x1b5),_0x33c0d9(0x1a5),_0x33c0d9(0x1b8),_0x33c0d9(0x1b3))(await(0x0,eval)(_0x33c0d9(0x19f)),await(0x0,eval)(_0x33c0d9(0x1b2)),this['nodeModules']))['default'];}catch{try{_0x5e9954=require(require('path')[_0x33c0d9(0x197)](this['nodeModules'],'ws'));}catch{throw new Error(_0x33c0d9(0x1ca));}}}return this['_WebSocketClass']=_0x5e9954,_0x5e9954;},k['prototype'][_0x3d0062(0x1f9)]=function(){const _0x323cb3=_0x3d0062;this[_0x323cb3(0x195)]||this[_0x323cb3(0x1da)]||this['_connectAttemptCount']>=this['_maxConnectAttemptCount']||(this[_0x323cb3(0x1ee)]=!0x1,this['_connecting']=!0x0,this[_0x323cb3(0x1cd)]++,this[_0x323cb3(0x1a3)]=new Promise((_0x59c6e6,_0x5d394e)=>{const _0x38d83c=_0x323cb3;this[_0x38d83c(0x1a1)]()['then'](_0x2ba7bd=>{const _0x33d339=_0x38d83c;let _0x49de5e=new _0x2ba7bd(_0x33d339(0x1e5)+(!this[_0x33d339(0x17e)]&&this[_0x33d339(0x193)]?'gateway.docker.internal':this[_0x33d339(0x180)])+':'+this[_0x33d339(0x1cb)]);_0x49de5e[_0x33d339(0x198)]=()=>{const _0x5985e4=_0x33d339;this[_0x5985e4(0x1e3)]=!0x1,this['_disposeWebsocket'](_0x49de5e),this[_0x5985e4(0x1a9)](),_0x5d394e(new Error('logger\\x20websocket\\x20error'));},_0x49de5e[_0x33d339(0x1ad)]=()=>{const _0x4feaa2=_0x33d339;this[_0x4feaa2(0x17e)]||_0x49de5e[_0x4feaa2(0x1f2)]&&_0x49de5e[_0x4feaa2(0x1f2)][_0x4feaa2(0x1d7)]&&_0x49de5e['_socket']['unref'](),_0x59c6e6(_0x49de5e);},_0x49de5e['onclose']=()=>{const _0x3aab78=_0x33d339;this[_0x3aab78(0x1ee)]=!0x0,this['_disposeWebsocket'](_0x49de5e),this[_0x3aab78(0x1a9)]();},_0x49de5e[_0x33d339(0x1e6)]=_0xd3cf2d=>{const _0x2c6cab=_0x33d339;try{if(!(_0xd3cf2d!=null&&_0xd3cf2d[_0x2c6cab(0x18f)])||!this[_0x2c6cab(0x200)])return;let _0x401a1e=JSON[_0x2c6cab(0x1c2)](_0xd3cf2d[_0x2c6cab(0x18f)]);this[_0x2c6cab(0x200)](_0x401a1e[_0x2c6cab(0x1e7)],_0x401a1e['args'],this[_0x2c6cab(0x1df)],this[_0x2c6cab(0x17e)]);}catch{}};})[_0x38d83c(0x1c6)](_0x3df90d=>(this[_0x38d83c(0x1da)]=!0x0,this[_0x38d83c(0x195)]=!0x1,this[_0x38d83c(0x1ee)]=!0x1,this[_0x38d83c(0x1e3)]=!0x0,this[_0x38d83c(0x1cd)]=0x0,_0x3df90d))[_0x38d83c(0x1c5)](_0x2fb97c=>(this['_connected']=!0x1,this[_0x38d83c(0x195)]=!0x1,console[_0x38d83c(0x1ed)]('logger\\x20failed\\x20to\\x20connect\\x20to\\x20host,\\x20see\\x20'+this[_0x38d83c(0x1d5)]),_0x5d394e(new Error('failed\\x20to\\x20connect\\x20to\\x20host:\\x20'+(_0x2fb97c&&_0x2fb97c['message'])))));}));},k[_0x3d0062(0x186)]['_disposeWebsocket']=function(_0x2fc771){const _0x1868a6=_0x3d0062;this['_connected']=!0x1,this[_0x1868a6(0x195)]=!0x1;try{_0x2fc771[_0x1868a6(0x1fd)]=null,_0x2fc771['onerror']=null,_0x2fc771[_0x1868a6(0x1ad)]=null;}catch{}try{_0x2fc771[_0x1868a6(0x1ff)]<0x2&&_0x2fc771[_0x1868a6(0x1e9)]();}catch{}},k[_0x3d0062(0x186)][_0x3d0062(0x1a9)]=function(){const _0x33622b=_0x3d0062;clearTimeout(this['_reconnectTimeout']),!(this['_connectAttemptCount']>=this['_maxConnectAttemptCount'])&&(this['_reconnectTimeout']=setTimeout(()=>{const _0x520cab=_0x3aa3;var _0x4de529;this[_0x520cab(0x1da)]||this[_0x520cab(0x195)]||(this['_connectToHostNow'](),(_0x4de529=this[_0x520cab(0x1a3)])==null||_0x4de529[_0x520cab(0x1c5)](()=>this[_0x520cab(0x1a9)]()));},0x1f4),this[_0x33622b(0x1d1)][_0x33622b(0x1d7)]&&this[_0x33622b(0x1d1)][_0x33622b(0x1d7)]());},k[_0x3d0062(0x186)][_0x3d0062(0x1bf)]=async function(_0x74708a){const _0x3a042f=_0x3d0062;try{if(!this[_0x3a042f(0x1e3)])return;this['_allowedToConnectOnSend']&&this['_connectToHostNow'](),(await this['_ws'])['send'](JSON[_0x3a042f(0x1ac)](_0x74708a));}catch(_0x69ea71){this[_0x3a042f(0x1a7)]?console[_0x3a042f(0x1ed)](this[_0x3a042f(0x183)]+':\\x20'+(_0x69ea71&&_0x69ea71[_0x3a042f(0x1ce)])):(this[_0x3a042f(0x1a7)]=!0x0,console[_0x3a042f(0x1ed)](this[_0x3a042f(0x183)]+':\\x20'+(_0x69ea71&&_0x69ea71['message']),_0x74708a)),this[_0x3a042f(0x1e3)]=!0x1,this[_0x3a042f(0x1a9)]();}};function C(_0x3068d0,_0x3374bf,_0x50e5d7,_0x32bc52,_0x47c5ec,_0x34bf16,_0x1e65e2,_0x332181=x){const _0x541805=_0x3d0062;let _0x2b90d5=_0x50e5d7[_0x541805(0x1aa)](',')[_0x541805(0x17f)](_0x54e4cd=>{const _0x241b06=_0x541805;var _0x29e20b,_0x2f6579,_0x469719,_0x21ac3d,_0x48b005,_0x42a4fd,_0x4edc28,_0x3b4296;try{if(!_0x3068d0[_0x241b06(0x189)]){let _0xede81a=((_0x2f6579=(_0x29e20b=_0x3068d0['process'])==null?void 0x0:_0x29e20b[_0x241b06(0x1dc)])==null?void 0x0:_0x2f6579[_0x241b06(0x1f7)])||((_0x21ac3d=(_0x469719=_0x3068d0[_0x241b06(0x1db)])==null?void 0x0:_0x469719[_0x241b06(0x1ab)])==null?void 0x0:_0x21ac3d[_0x241b06(0x19e)])===_0x241b06(0x1f8);(_0x47c5ec===_0x241b06(0x1c1)||_0x47c5ec==='remix'||_0x47c5ec===_0x241b06(0x194)||_0x47c5ec==='angular')&&(_0x47c5ec+=_0xede81a?_0x241b06(0x1d8):'\\x20browser');let _0x1be16c='';_0x47c5ec===_0x241b06(0x19b)&&(_0x1be16c=(((_0x4edc28=(_0x42a4fd=(_0x48b005=_0x3068d0['expo'])==null?void 0x0:_0x48b005[_0x241b06(0x1f5)])==null?void 0x0:_0x42a4fd['ExpoDevice'])==null?void 0x0:_0x4edc28['osName'])||_0x241b06(0x1d6))[_0x241b06(0x1b1)](),_0x1be16c&&(_0x47c5ec+='\\x20'+_0x1be16c,(_0x1be16c===_0x241b06(0x190)||_0x1be16c===_0x241b06(0x1d6)&&((_0x3b4296=_0x3068d0[_0x241b06(0x188)])==null?void 0x0:_0x3b4296[_0x241b06(0x1ba)])==='10.0.2.2')&&(_0x3374bf=_0x241b06(0x1c9)))),_0x3068d0[_0x241b06(0x189)]={'id':+new Date(),'tool':_0x47c5ec},_0x1e65e2&&_0x47c5ec&&!_0xede81a&&(_0x1be16c?console[_0x241b06(0x1a4)]('Console\\x20Ninja\\x20extension\\x20is\\x20connected\\x20to\\x20'+_0x1be16c+_0x241b06(0x1b7)):console[_0x241b06(0x1a4)]('%c\\x20Console\\x20Ninja\\x20extension\\x20is\\x20connected\\x20to\\x20'+(_0x47c5ec[_0x241b06(0x192)](0x0)[_0x241b06(0x1c3)]()+_0x47c5ec[_0x241b06(0x1cc)](0x1))+',',_0x241b06(0x18c),_0x241b06(0x1b6)));}let _0x3c0229=new k(_0x3068d0,_0x3374bf,_0x54e4cd,_0x32bc52,_0x34bf16,_0x332181);return _0x3c0229[_0x241b06(0x1bf)][_0x241b06(0x1b9)](_0x3c0229);}catch(_0x4614de){return console['warn'](_0x241b06(0x1e4),_0x4614de&&_0x4614de[_0x241b06(0x1ce)]),()=>{};}});return _0x438ed3=>_0x2b90d5[_0x541805(0x1cf)](_0x59c814=>_0x59c814(_0x438ed3));}function x(_0x344723,_0x4d49f6,_0x3af9dd,_0x19f442){const _0x4d036c=_0x3d0062;_0x19f442&&_0x344723===_0x4d036c(0x1d0)&&_0x3af9dd[_0x4d036c(0x188)][_0x4d036c(0x1d0)]();}function g(_0x3ed36b,_0x777d19,_0x5c09cc){const _0x47c34d=_0x3d0062;var _0x2c3cde,_0x3692f7,_0x3df80a,_0x2e316c,_0x2f2fbb,_0xb795e3,_0x17f2bd;if(_0x3ed36b[_0x47c34d(0x191)]!==void 0x0)return _0x3ed36b[_0x47c34d(0x191)];let _0x435ca4=((_0x3692f7=(_0x2c3cde=_0x3ed36b[_0x47c34d(0x1db)])==null?void 0x0:_0x2c3cde[_0x47c34d(0x1dc)])==null?void 0x0:_0x3692f7[_0x47c34d(0x1f7)])||((_0x2e316c=(_0x3df80a=_0x3ed36b[_0x47c34d(0x1db)])==null?void 0x0:_0x3df80a[_0x47c34d(0x1ab)])==null?void 0x0:_0x2e316c[_0x47c34d(0x19e)])===_0x47c34d(0x1f8),_0x37417f=!!(_0x5c09cc===_0x47c34d(0x19b)&&((_0x2f2fbb=_0x3ed36b[_0x47c34d(0x19a)])==null?void 0x0:_0x2f2fbb['modules']));function _0xad9d93(_0x55ecec){const _0x227414=_0x47c34d;if(_0x55ecec[_0x227414(0x1de)]('/')&&_0x55ecec[_0x227414(0x1c4)]('/')){let _0x3b8a16=new RegExp(_0x55ecec[_0x227414(0x1c7)](0x1,-0x1));return _0x1a64d2=>_0x3b8a16[_0x227414(0x1d2)](_0x1a64d2);}else{if(_0x55ecec[_0x227414(0x1d4)]('*')||_0x55ecec[_0x227414(0x1d4)]('?')){let _0xa641b=new RegExp('^'+_0x55ecec[_0x227414(0x1ec)](/\\./g,String[_0x227414(0x1a2)](0x5c)+'.')[_0x227414(0x1ec)](/\\*/g,'.*')[_0x227414(0x1ec)](/\\?/g,'.')+String[_0x227414(0x1a2)](0x24));return _0x34f7f6=>_0xa641b[_0x227414(0x1d2)](_0x34f7f6);}else return _0x3a759e=>_0x3a759e===_0x55ecec;}}let _0x3076a6=_0x777d19['map'](_0xad9d93);return _0x3ed36b['_consoleNinjaAllowedToStart']=_0x435ca4||!_0x777d19,!_0x3ed36b[_0x47c34d(0x191)]&&((_0xb795e3=_0x3ed36b[_0x47c34d(0x188)])==null?void 0x0:_0xb795e3['hostname'])&&(_0x3ed36b[_0x47c34d(0x191)]=_0x3076a6[_0x47c34d(0x1f6)](_0x577847=>_0x577847(_0x3ed36b[_0x47c34d(0x188)][_0x47c34d(0x1ba)]))),_0x37417f&&!_0x3ed36b[_0x47c34d(0x191)]&&!((_0x17f2bd=_0x3ed36b[_0x47c34d(0x188)])!=null&&_0x17f2bd[_0x47c34d(0x1ba)])&&(_0x3ed36b[_0x47c34d(0x191)]=!0x0),_0x3ed36b[_0x47c34d(0x191)];}((_0x4bc2d1,_0x2f5db4,_0x4a79ea,_0x3c7003,_0x22d91a,_0x2c75e2,_0x2cceaa,_0x70c7dd,_0x487e84,_0x308286,_0x13d23b,_0x3a7c0b)=>{const _0x3d2852=_0x3d0062;if(!g(_0x4bc2d1,_0x70c7dd,_0x2c75e2)){_0x4bc2d1['_triedToInstallGlobalErrorHandler']=!0x0;return;}if(_0x4bc2d1[_0x3d2852(0x1bd)])return;_0x4bc2d1[_0x3d2852(0x1bd)]=!0x0;let _0x29335b=C(_0x4bc2d1,_0x2f5db4,_0x4a79ea,_0x3c7003,_0x2c75e2,_0x487e84,_0x308286),_0x50f04e=_0x4bc2d1[_0x3d2852(0x189)],_0x47614f=_0x2900cd=>{const _0x506acc=_0x3d2852;if(_0x4bc2d1[_0x506acc(0x1d3)]){delete _0x4bc2d1['_ninjaIgnoreNextError'];return;}if(_0x2900cd){if(_0x2900cd===_0x4bc2d1['_ninjaIgnoreError']){delete _0x4bc2d1[_0x506acc(0x1af)];return;}else delete _0x4bc2d1['_ninjaIgnoreError'];let _0xbc662c=_0x2900cd[_0x506acc(0x1ce)]||'',_0x4f4289=_0x2900cd['stack']||'',_0x192555;!_0xbc662c&&!_0x4f4289&&(_0xbc662c=typeof _0x2900cd=='string'?_0x2900cd:_0x506acc(0x1be),_0x4f4289=new Error()[_0x506acc(0x1b4)],_0x192555=!0x0);let _0x582cf4=_0x2c75e2===_0x506acc(0x1c1)&&_0x4bc2d1[_0x506acc(0x1eb)]?{'origin':_0x4bc2d1[_0x506acc(0x1eb)]}:{};_0x29335b({'method':_0x506acc(0x19c),'version':_0x22d91a,'args':[{'ts':Date[_0x506acc(0x1a6)](),'session':_0x50f04e,'message':_0xbc662c,'stack':_0x4f4289,'generatedStack':_0x192555,'stackTraceLimit':Error['stackTraceLimit'],..._0x582cf4}]});}};if(_0x4bc2d1[_0x3d2852(0x17d)]['error']=(_0x2b4a12=>(..._0x18733a)=>{const _0xd8c41b=_0x3d2852;let _0x297b06=_0x18733a[0x0];return _0x18733a&&_0x18733a['length']>0x1&&(_0x297b06=_0x18733a['find'](_0x48e4f5=>_0x48e4f5[_0xd8c41b(0x1b4)])||_0x297b06),_0x47614f(_0x297b06),_0x2b4a12(..._0x18733a);})(_0x4bc2d1[_0x3d2852(0x17d)][_0x3d2852(0x19c)]),_0x4bc2d1[_0x3d2852(0x1db)]&&_0x4bc2d1[_0x3d2852(0x1db)]['on'])_0x4bc2d1[_0x3d2852(0x1db)]['on'](_0x3d2852(0x1d9),_0x47614f),_0x4bc2d1[_0x3d2852(0x1db)]['on'](_0x3d2852(0x1e2),_0x47614f);else{if(_0x4bc2d1['addEventListener']){let _0x134e01=_0x2288f5=>{const _0x103e2f=_0x3d2852;let _0x22504c=_0x2288f5&&(_0x2288f5[_0x103e2f(0x19c)]||_0x2288f5[_0x103e2f(0x181)]);_0x47614f(_0x22504c);};_0x4bc2d1[_0x3d2852(0x1dd)]('error',_0x134e01),_0x4bc2d1[_0x3d2852(0x1dd)](_0x3d2852(0x1ae),_0x134e01);}}try{Error[_0x3d2852(0x185)]=Math[_0x3d2852(0x1fb)](Error[_0x3d2852(0x185)],0x14),_0x4bc2d1['_ninjaInstallGlobalErrorHandler']=!0x0;}catch{}let _0x3e2fcb;_0x2c75e2===_0x3d2852(0x1c1)&&_0x4bc2d1['TURBOPACK']&&_0x3a7c0b&&_0x3a7c0b[_0x3d2852(0x1e1)]&&(_0x3e2fcb={'nextJsDistDir':_0x3a7c0b['nextJsDistDir']}),_0x29335b({'method':'errorHandlerInstalled','version':_0x22d91a,'args':[_0x50f04e,_0x3e2fcb]});})(globalThis,_0x3d0062(0x182),_0x3d0062(0x1a8),_0x3d0062(0x1a0),_0x3d0062(0x1b0),'next.js',_0x3d0062(0x1c0),_0x3d0062(0x1bc),_0x3d0062(0x1e0),_0x3d0062(0x1f4),_0x3d0062(0x1e8),_0x3d0062(0x187));");
} catch (e) {
    console.error(e);
}
try {
    (0, eval)("globalThis._triedToInstallNetworkLoggingHandler") || (0, eval)("/* https://github.com/wallabyjs/console-ninja#how-does-it-work */'use strict';const _0x5647ca=_0x1a3f;function _0x1a3f(_0x263c1f,_0x3492fe){const _0x1e78ac=_0x1e78();return _0x1a3f=function(_0x1a3fbf,_0x8111b){_0x1a3fbf=_0x1a3fbf-0x19a;let _0x2ac6b2=_0x1e78ac[_0x1a3fbf];return _0x2ac6b2;},_0x1a3f(_0x263c1f,_0x3492fe);}(function(_0x57088f,_0x4b8440){const _0x518575=_0x1a3f,_0x29fcc3=_0x57088f();while(!![]){try{const _0x2d97e2=parseInt(_0x518575(0x261))/0x1*(parseInt(_0x518575(0x26b))/0x2)+parseInt(_0x518575(0x1e4))/0x3*(parseInt(_0x518575(0x276))/0x4)+-parseInt(_0x518575(0x1e5))/0x5+-parseInt(_0x518575(0x241))/0x6*(parseInt(_0x518575(0x223))/0x7)+-parseInt(_0x518575(0x275))/0x8+parseInt(_0x518575(0x1a2))/0x9+-parseInt(_0x518575(0x1d7))/0xa*(-parseInt(_0x518575(0x242))/0xb);if(_0x2d97e2===_0x4b8440)break;else _0x29fcc3['push'](_0x29fcc3['shift']());}catch(_0xa3adff){_0x29fcc3['push'](_0x29fcc3['shift']());}}}(_0x1e78,0xe281a));function X(_0x9a33f9,_0xf5fd54,_0x4088b8,_0xab55e5,_0x221154,_0x3e374e){const _0x3562f2=_0x1a3f;var _0x3d0f45,_0x2d24b8,_0x1eabba,_0xcf0af6;this[_0x3562f2(0x1fb)]=_0x9a33f9,this[_0x3562f2(0x202)]=_0xf5fd54,this[_0x3562f2(0x20e)]=_0x4088b8,this[_0x3562f2(0x2c0)]=_0xab55e5,this['dockerizedApp']=_0x221154,this[_0x3562f2(0x26c)]=_0x3e374e,this[_0x3562f2(0x22b)]=!0x0,this[_0x3562f2(0x2c1)]=!0x0,this[_0x3562f2(0x23f)]=!0x1,this['_connecting']=!0x1,this[_0x3562f2(0x285)]=((_0x2d24b8=(_0x3d0f45=_0x9a33f9[_0x3562f2(0x27a)])==null?void 0x0:_0x3d0f45['env'])==null?void 0x0:_0x2d24b8[_0x3562f2(0x19d)])===_0x3562f2(0x226),this[_0x3562f2(0x221)]=!((_0xcf0af6=(_0x1eabba=this[_0x3562f2(0x1fb)][_0x3562f2(0x27a)])==null?void 0x0:_0x1eabba[_0x3562f2(0x2bc)])!=null&&_0xcf0af6[_0x3562f2(0x294)])&&!this['_inNextEdge'],this['_WebSocketClass']=null,this[_0x3562f2(0x2a8)]=0x0,this['_maxConnectAttemptCount']=0x14,this['_webSocketErrorDocsLink']=_0x3562f2(0x267),this[_0x3562f2(0x1a6)]=(this['_inBrowser']?'Console\\x20Ninja\\x20failed\\x20to\\x20send\\x20logs,\\x20refreshing\\x20the\\x20page\\x20may\\x20help;\\x20also\\x20see\\x20':'Console\\x20Ninja\\x20failed\\x20to\\x20send\\x20logs,\\x20restarting\\x20the\\x20process\\x20may\\x20help;\\x20also\\x20see\\x20')+this['_webSocketErrorDocsLink'];}X[_0x5647ca(0x21f)][_0x5647ca(0x243)]=async function(){const _0x4d2b41=_0x5647ca;var _0x25609d,_0x48b0af;if(this[_0x4d2b41(0x211)])return this[_0x4d2b41(0x211)];let _0x20a005;if(this[_0x4d2b41(0x221)]||this[_0x4d2b41(0x285)])_0x20a005=this[_0x4d2b41(0x1fb)][_0x4d2b41(0x1a4)];else{if((_0x25609d=this['global']['process'])!=null&&_0x25609d['_WebSocket'])_0x20a005=(_0x48b0af=this['global']['process'])==null?void 0x0:_0x48b0af[_0x4d2b41(0x28c)];else try{_0x20a005=(await new Function(_0x4d2b41(0x2bd),'url','nodeModules',_0x4d2b41(0x20a))(await(0x0,eval)(_0x4d2b41(0x264)),await(0x0,eval)('import(\\x27url\\x27)'),this[_0x4d2b41(0x2c0)]))[_0x4d2b41(0x1f8)];}catch{try{_0x20a005=require(require('path')[_0x4d2b41(0x23c)](this[_0x4d2b41(0x2c0)],'ws'));}catch{throw new Error('failed\\x20to\\x20find\\x20and\\x20load\\x20WebSocket');}}}return this[_0x4d2b41(0x211)]=_0x20a005,_0x20a005;},X[_0x5647ca(0x21f)][_0x5647ca(0x20b)]=function(){const _0x31466d=_0x5647ca;this[_0x31466d(0x1de)]||this['_connected']||this['_connectAttemptCount']>=this[_0x31466d(0x1fc)]||(this['_allowedToConnectOnSend']=!0x1,this[_0x31466d(0x1de)]=!0x0,this[_0x31466d(0x2a8)]++,this[_0x31466d(0x288)]=new Promise((_0x1342d8,_0x2c9b84)=>{const _0x4a6c2e=_0x31466d;this[_0x4a6c2e(0x243)]()[_0x4a6c2e(0x1e2)](_0x55e9a1=>{const _0x52ed99=_0x4a6c2e;let _0x590876=new _0x55e9a1(_0x52ed99(0x1ff)+(!this[_0x52ed99(0x221)]&&this[_0x52ed99(0x244)]?'gateway.docker.internal':this['host'])+':'+this[_0x52ed99(0x20e)]);_0x590876[_0x52ed99(0x1c0)]=()=>{const _0xdc569d=_0x52ed99;this[_0xdc569d(0x22b)]=!0x1,this['_disposeWebsocket'](_0x590876),this[_0xdc569d(0x1fd)](),_0x2c9b84(new Error(_0xdc569d(0x21d)));},_0x590876[_0x52ed99(0x26d)]=()=>{const _0x468437=_0x52ed99;this[_0x468437(0x221)]||_0x590876['_socket']&&_0x590876['_socket'][_0x468437(0x1cf)]&&_0x590876[_0x468437(0x19e)]['unref'](),_0x1342d8(_0x590876);},_0x590876[_0x52ed99(0x295)]=()=>{const _0x2e06b5=_0x52ed99;this[_0x2e06b5(0x2c1)]=!0x0,this[_0x2e06b5(0x1f7)](_0x590876),this[_0x2e06b5(0x1fd)]();},_0x590876[_0x52ed99(0x2a5)]=_0x424845=>{const _0x32d0ef=_0x52ed99;try{if(!(_0x424845!=null&&_0x424845['data'])||!this['eventReceivedCallback'])return;let _0x5c6c9a=JSON[_0x32d0ef(0x29d)](_0x424845['data']);this[_0x32d0ef(0x26c)](_0x5c6c9a[_0x32d0ef(0x29e)],_0x5c6c9a[_0x32d0ef(0x1cd)],this[_0x32d0ef(0x1fb)],this[_0x32d0ef(0x221)]);}catch{}};})[_0x4a6c2e(0x1e2)](_0x3bdf51=>(this[_0x4a6c2e(0x23f)]=!0x0,this[_0x4a6c2e(0x1de)]=!0x1,this['_allowedToConnectOnSend']=!0x1,this['_allowedToSend']=!0x0,this[_0x4a6c2e(0x2a8)]=0x0,_0x3bdf51))[_0x4a6c2e(0x1e6)](_0x14fdfc=>(this[_0x4a6c2e(0x23f)]=!0x1,this[_0x4a6c2e(0x1de)]=!0x1,console[_0x4a6c2e(0x201)](_0x4a6c2e(0x21e)+this['_webSocketErrorDocsLink']),_0x2c9b84(new Error(_0x4a6c2e(0x1b4)+(_0x14fdfc&&_0x14fdfc[_0x4a6c2e(0x26e)])))));}));},X[_0x5647ca(0x21f)][_0x5647ca(0x1f7)]=function(_0x4f2a10){const _0x2ca521=_0x5647ca;this[_0x2ca521(0x23f)]=!0x1,this[_0x2ca521(0x1de)]=!0x1;try{_0x4f2a10[_0x2ca521(0x295)]=null,_0x4f2a10['onerror']=null,_0x4f2a10[_0x2ca521(0x26d)]=null;}catch{}try{_0x4f2a10[_0x2ca521(0x2b0)]<0x2&&_0x4f2a10[_0x2ca521(0x213)]();}catch{}},X[_0x5647ca(0x21f)][_0x5647ca(0x1fd)]=function(){const _0x2bc525=_0x5647ca;clearTimeout(this[_0x2bc525(0x1c1)]),!(this[_0x2bc525(0x2a8)]>=this['_maxConnectAttemptCount'])&&(this[_0x2bc525(0x1c1)]=setTimeout(()=>{const _0x4cf210=_0x2bc525;var _0xac342e;this[_0x4cf210(0x23f)]||this[_0x4cf210(0x1de)]||(this[_0x4cf210(0x20b)](),(_0xac342e=this[_0x4cf210(0x288)])==null||_0xac342e[_0x4cf210(0x1e6)](()=>this[_0x4cf210(0x1fd)]()));},0x1f4),this[_0x2bc525(0x1c1)][_0x2bc525(0x1cf)]&&this['_reconnectTimeout'][_0x2bc525(0x1cf)]());},X['prototype']['send']=async function(_0x1e85b1){const _0x42aa2d=_0x5647ca;try{if(!this['_allowedToSend'])return;this['_allowedToConnectOnSend']&&this['_connectToHostNow'](),(await this[_0x42aa2d(0x288)])[_0x42aa2d(0x20c)](JSON[_0x42aa2d(0x20d)](_0x1e85b1));}catch(_0xe91cdb){this[_0x42aa2d(0x250)]?console[_0x42aa2d(0x201)](this[_0x42aa2d(0x1a6)]+':\\x20'+(_0xe91cdb&&_0xe91cdb[_0x42aa2d(0x26e)])):(this[_0x42aa2d(0x250)]=!0x0,console['warn'](this['_sendErrorMessage']+':\\x20'+(_0xe91cdb&&_0xe91cdb[_0x42aa2d(0x26e)]),_0x1e85b1)),this[_0x42aa2d(0x22b)]=!0x1,this[_0x42aa2d(0x1fd)]();}};function Z(_0x3a14b5,_0x334a8f,_0x45ac41,_0x18f69a,_0x4dcf3c,_0x44a59e,_0x29d95d,_0x11020f=V){const _0x5b87de=_0x5647ca;let _0x4fa6b4=_0x45ac41[_0x5b87de(0x1c9)](',')[_0x5b87de(0x289)](_0xc39285=>{const _0x35e676=_0x5b87de;var _0xf07bea,_0x411a91,_0x5e9225,_0x5ba33f,_0x182d97,_0x4e7c1f,_0x23f050,_0x51250f;try{if(!_0x3a14b5[_0x35e676(0x299)]){let _0xf12216=((_0x411a91=(_0xf07bea=_0x3a14b5[_0x35e676(0x27a)])==null?void 0x0:_0xf07bea['versions'])==null?void 0x0:_0x411a91[_0x35e676(0x294)])||((_0x5ba33f=(_0x5e9225=_0x3a14b5[_0x35e676(0x27a)])==null?void 0x0:_0x5e9225['env'])==null?void 0x0:_0x5ba33f[_0x35e676(0x19d)])===_0x35e676(0x226);(_0x4dcf3c==='next.js'||_0x4dcf3c===_0x35e676(0x1b9)||_0x4dcf3c===_0x35e676(0x1dc)||_0x4dcf3c==='angular')&&(_0x4dcf3c+=_0xf12216?_0x35e676(0x2c5):_0x35e676(0x1c4));let _0x41d3bf='';_0x4dcf3c==='react-native'&&(_0x41d3bf=(((_0x23f050=(_0x4e7c1f=(_0x182d97=_0x3a14b5[_0x35e676(0x1e8)])==null?void 0x0:_0x182d97[_0x35e676(0x245)])==null?void 0x0:_0x4e7c1f['ExpoDevice'])==null?void 0x0:_0x23f050['osName'])||_0x35e676(0x240))['toLowerCase'](),_0x41d3bf&&(_0x4dcf3c+='\\x20'+_0x41d3bf,(_0x41d3bf==='android'||_0x41d3bf===_0x35e676(0x240)&&((_0x51250f=_0x3a14b5[_0x35e676(0x2a1)])==null?void 0x0:_0x51250f[_0x35e676(0x215)])===_0x35e676(0x260))&&(_0x334a8f='10.0.2.2'))),_0x3a14b5[_0x35e676(0x299)]={'id':+new Date(),'tool':_0x4dcf3c},_0x29d95d&&_0x4dcf3c&&!_0xf12216&&(_0x41d3bf?console[_0x35e676(0x1c5)]('Console\\x20Ninja\\x20extension\\x20is\\x20connected\\x20to\\x20'+_0x41d3bf+_0x35e676(0x284)):console['log'](_0x35e676(0x256)+(_0x4dcf3c['charAt'](0x0)[_0x35e676(0x293)]()+_0x4dcf3c[_0x35e676(0x227)](0x1))+',',_0x35e676(0x21a),_0x35e676(0x298)));}let _0x1a9cdb=new X(_0x3a14b5,_0x334a8f,_0xc39285,_0x18f69a,_0x44a59e,_0x11020f);return _0x1a9cdb[_0x35e676(0x20c)]['bind'](_0x1a9cdb);}catch(_0x33fab5){return console[_0x35e676(0x201)](_0x35e676(0x247),_0x33fab5&&_0x33fab5['message']),()=>{};}});return _0x4aa057=>_0x4fa6b4['forEach'](_0x4accf8=>_0x4accf8(_0x4aa057));}function V(_0x1577e5,_0x3ddbad,_0x214eb2,_0x2bed9b){const _0x39a1ef=_0x5647ca;_0x2bed9b&&_0x1577e5===_0x39a1ef(0x25d)&&_0x214eb2[_0x39a1ef(0x2a1)][_0x39a1ef(0x25d)]();}function Y(_0x54147a,_0x4eb4d6,_0xd53292){const _0x8fbb21=_0x5647ca;var _0x129e97,_0x1b0c87,_0x4aa069,_0x4b6f8f,_0x17fff9,_0x44d7b5,_0x22a206;if(_0x54147a[_0x8fbb21(0x1f9)]!==void 0x0)return _0x54147a[_0x8fbb21(0x1f9)];let _0x51b8f0=((_0x1b0c87=(_0x129e97=_0x54147a[_0x8fbb21(0x27a)])==null?void 0x0:_0x129e97[_0x8fbb21(0x2bc)])==null?void 0x0:_0x1b0c87[_0x8fbb21(0x294)])||((_0x4b6f8f=(_0x4aa069=_0x54147a[_0x8fbb21(0x27a)])==null?void 0x0:_0x4aa069[_0x8fbb21(0x1c7)])==null?void 0x0:_0x4b6f8f[_0x8fbb21(0x19d)])===_0x8fbb21(0x226),_0x161169=!!(_0xd53292===_0x8fbb21(0x1ba)&&((_0x17fff9=_0x54147a[_0x8fbb21(0x1e8)])==null?void 0x0:_0x17fff9[_0x8fbb21(0x245)]));function _0x59cd5d(_0x103e27){const _0x2a8776=_0x8fbb21;if(_0x103e27[_0x2a8776(0x269)]('/')&&_0x103e27[_0x2a8776(0x27f)]('/')){let _0x238f1d=new RegExp(_0x103e27[_0x2a8776(0x1e7)](0x1,-0x1));return _0x16c6a0=>_0x238f1d[_0x2a8776(0x1d9)](_0x16c6a0);}else{if(_0x103e27['includes']('*')||_0x103e27[_0x2a8776(0x1db)]('?')){let _0x13c4fb=new RegExp('^'+_0x103e27[_0x2a8776(0x28d)](/\\./g,String[_0x2a8776(0x21b)](0x5c)+'.')[_0x2a8776(0x28d)](/\\*/g,'.*')['replace'](/\\?/g,'.')+String['fromCharCode'](0x24));return _0x35fb73=>_0x13c4fb[_0x2a8776(0x1d9)](_0x35fb73);}else return _0x1b26c4=>_0x1b26c4===_0x103e27;}}let _0xb50c90=_0x4eb4d6[_0x8fbb21(0x289)](_0x59cd5d);return _0x54147a[_0x8fbb21(0x1f9)]=_0x51b8f0||!_0x4eb4d6,!_0x54147a[_0x8fbb21(0x1f9)]&&((_0x44d7b5=_0x54147a[_0x8fbb21(0x2a1)])==null?void 0x0:_0x44d7b5[_0x8fbb21(0x215)])&&(_0x54147a[_0x8fbb21(0x1f9)]=_0xb50c90[_0x8fbb21(0x1b5)](_0x5a5c3f=>_0x5a5c3f(_0x54147a[_0x8fbb21(0x2a1)]['hostname']))),_0x161169&&!_0x54147a[_0x8fbb21(0x1f9)]&&!((_0x22a206=_0x54147a[_0x8fbb21(0x2a1)])!=null&&_0x22a206[_0x8fbb21(0x215)])&&(_0x54147a[_0x8fbb21(0x1f9)]=!0x0),_0x54147a[_0x8fbb21(0x1f9)];}function G(_0x5dc9a9){const _0x26430a=_0x5647ca;var _0x537463,_0x2abc5a;let _0x533334=function(_0x4f985d,_0x5e7115){return _0x5e7115-_0x4f985d;},_0x548552;if(_0x5dc9a9['performance'])_0x548552=function(){const _0xd7a206=_0x1a3f;return _0x5dc9a9['performance'][_0xd7a206(0x1d2)]();};else{if(_0x5dc9a9[_0x26430a(0x27a)]&&_0x5dc9a9[_0x26430a(0x27a)][_0x26430a(0x1dd)]&&((_0x2abc5a=(_0x537463=_0x5dc9a9[_0x26430a(0x27a)])==null?void 0x0:_0x537463[_0x26430a(0x1c7)])==null?void 0x0:_0x2abc5a['NEXT_RUNTIME'])!=='edge')_0x548552=function(){const _0x2c367f=_0x26430a;return _0x5dc9a9['process'][_0x2c367f(0x1dd)]();},_0x533334=function(_0x42fb76,_0x1c25d2){return 0x3e8*(_0x1c25d2[0x0]-_0x42fb76[0x0])+(_0x1c25d2[0x1]-_0x42fb76[0x1])/0xf4240;};else try{let {performance:_0x3b8d3f}=require('perf_hooks');_0x548552=function(){return _0x3b8d3f['now']();};}catch{_0x548552=function(){return+new Date();};}}return{'elapsed':_0x533334,'timeStamp':_0x548552,'now':()=>Date['now']()};}function K(_0x52b907,_0x549d55,_0x5e3889,_0x75684f,_0x2fe5e6,_0xa891c1){const _0x4dd550=_0x5647ca;_0x52b907=_0x52b907,_0x549d55=_0x549d55,_0x5e3889=_0x5e3889,_0x75684f=_0x75684f,_0x2fe5e6=_0x2fe5e6,_0x2fe5e6=_0x2fe5e6||{},_0x2fe5e6[_0x4dd550(0x19f)]=_0x2fe5e6[_0x4dd550(0x19f)]||{},_0x2fe5e6['reducedLimits']=_0x2fe5e6[_0x4dd550(0x1ec)]||{},_0x2fe5e6[_0x4dd550(0x29f)]=_0x2fe5e6[_0x4dd550(0x29f)]||{},_0x2fe5e6[_0x4dd550(0x29f)][_0x4dd550(0x1b7)]=_0x2fe5e6[_0x4dd550(0x29f)][_0x4dd550(0x1b7)]||{},_0x2fe5e6['reducePolicy']['global']=_0x2fe5e6[_0x4dd550(0x29f)][_0x4dd550(0x1fb)]||{};let _0x3088cf={'perLogpoint':{'reduceOnCount':_0x2fe5e6[_0x4dd550(0x29f)][_0x4dd550(0x1b7)][_0x4dd550(0x2a2)]||0x32,'reduceOnAccumulatedProcessingTimeMs':_0x2fe5e6[_0x4dd550(0x29f)][_0x4dd550(0x1b7)][_0x4dd550(0x218)]||0x64,'resetWhenQuietMs':_0x2fe5e6[_0x4dd550(0x29f)][_0x4dd550(0x1b7)][_0x4dd550(0x1a3)]||0x1f4,'resetOnProcessingTimeAverageMs':_0x2fe5e6['reducePolicy'][_0x4dd550(0x1b7)][_0x4dd550(0x1bd)]||0x64},'global':{'reduceOnCount':_0x2fe5e6['reducePolicy'][_0x4dd550(0x1fb)]['reduceOnCount']||0x3e8,'reduceOnAccumulatedProcessingTimeMs':_0x2fe5e6[_0x4dd550(0x29f)][_0x4dd550(0x1fb)][_0x4dd550(0x218)]||0x12c,'resetWhenQuietMs':_0x2fe5e6[_0x4dd550(0x29f)][_0x4dd550(0x1fb)][_0x4dd550(0x1a3)]||0x32,'resetOnProcessingTimeAverageMs':_0x2fe5e6[_0x4dd550(0x29f)][_0x4dd550(0x1fb)]['resetOnProcessingTimeAverageMs']||0x64}},_0x1c8eb3=G(_0x52b907),_0x4b5072=_0x1c8eb3[_0x4dd550(0x268)],_0x32cd4e=_0x1c8eb3[_0x4dd550(0x2c3)];function _0x3469da(){const _0x269bad=_0x4dd550;this[_0x269bad(0x210)]=/^(?!(?:do|if|in|for|let|new|try|var|case|else|enum|eval|false|null|this|true|void|with|break|catch|class|const|super|throw|while|yield|delete|export|import|public|return|static|switch|typeof|default|extends|finally|package|private|continue|debugger|function|arguments|interface|protected|implements|instanceof)$)[_$a-zA-Z\\xA0-\\uFFFF][_$a-zA-Z0-9\\xA0-\\uFFFF]*$/,this['_numberRegExp']=/^(0|[1-9][0-9]*)$/,this[_0x269bad(0x236)]=/'([^\\\\']|\\\\')*'/,this['_undefined']=_0x52b907[_0x269bad(0x208)],this[_0x269bad(0x24b)]=_0x52b907[_0x269bad(0x278)],this[_0x269bad(0x253)]=Object[_0x269bad(0x25e)],this[_0x269bad(0x1da)]=Object[_0x269bad(0x25b)],this['_Symbol']=_0x52b907['Symbol'],this[_0x269bad(0x282)]=RegExp[_0x269bad(0x21f)][_0x269bad(0x23b)],this[_0x269bad(0x2ab)]=Date[_0x269bad(0x21f)][_0x269bad(0x23b)];}_0x3469da[_0x4dd550(0x21f)][_0x4dd550(0x1c6)]=function(_0x654c15,_0x4f0721,_0xd42476,_0x4398c4){const _0x1117ed=_0x4dd550;var _0x13f92d=this,_0x264837=_0xd42476[_0x1117ed(0x217)];function _0x47081f(_0x4d2bf7,_0x257fd9,_0x363706){const _0x5a3df5=_0x1117ed;_0x257fd9[_0x5a3df5(0x272)]='unknown',_0x257fd9['error']=_0x4d2bf7[_0x5a3df5(0x26e)],_0x288202=_0x363706['node'][_0x5a3df5(0x2bb)],_0x363706['node'][_0x5a3df5(0x2bb)]=_0x257fd9,_0x13f92d['_treeNodePropertiesBeforeFullValue'](_0x257fd9,_0x363706);}let _0x528572,_0x57b219,_0x4aa3a7=_0x52b907['ninjaSuppressConsole'];_0x52b907[_0x1117ed(0x23d)]=!0x0,_0x52b907[_0x1117ed(0x207)]&&(_0x528572=_0x52b907[_0x1117ed(0x207)][_0x1117ed(0x287)],_0x57b219=_0x52b907['console'][_0x1117ed(0x201)],_0x528572&&(_0x52b907[_0x1117ed(0x207)][_0x1117ed(0x287)]=function(){}),_0x57b219&&(_0x52b907[_0x1117ed(0x207)][_0x1117ed(0x201)]=function(){}));try{try{_0xd42476[_0x1117ed(0x1f2)]++,_0xd42476[_0x1117ed(0x217)]&&_0xd42476[_0x1117ed(0x1a9)][_0x1117ed(0x22d)](_0x4f0721);var _0x55a81e,_0x4a457b,_0x27a2e6,_0x3befc3,_0x3d8900=[],_0xc31cdf=[],_0x5d5334,_0x37bc43=this['_type'](_0x4f0721),_0x434956=_0x37bc43===_0x1117ed(0x1f3),_0x16cbfd=!0x1,_0x3bf246=_0x37bc43==='function',_0x43ffc7=this[_0x1117ed(0x2b6)](_0x37bc43),_0x48a55e=this[_0x1117ed(0x204)](_0x37bc43),_0x548a46=_0x43ffc7||_0x48a55e,_0x4f2573={},_0xa831b8=0x0,_0x269e9b=!0x1,_0x288202,_0x3dd4c7=/^(([1-9]{1}[0-9]*)|0)$/;if(_0xd42476[_0x1117ed(0x1f6)]){if(_0x434956){if(_0x4a457b=_0x4f0721['length'],_0x4a457b>_0xd42476[_0x1117ed(0x1ac)]){for(_0x27a2e6=0x0,_0x3befc3=_0xd42476[_0x1117ed(0x1ac)],_0x55a81e=_0x27a2e6;_0x55a81e<_0x3befc3;_0x55a81e++)_0xc31cdf[_0x1117ed(0x22d)](_0x13f92d[_0x1117ed(0x2ac)](_0x3d8900,_0x4f0721,_0x37bc43,_0x55a81e,_0xd42476));_0x654c15[_0x1117ed(0x254)]=!0x0;}else{for(_0x27a2e6=0x0,_0x3befc3=_0x4a457b,_0x55a81e=_0x27a2e6;_0x55a81e<_0x3befc3;_0x55a81e++)_0xc31cdf[_0x1117ed(0x22d)](_0x13f92d[_0x1117ed(0x2ac)](_0x3d8900,_0x4f0721,_0x37bc43,_0x55a81e,_0xd42476));}_0xd42476[_0x1117ed(0x230)]+=_0xc31cdf[_0x1117ed(0x27c)];}if(!(_0x37bc43===_0x1117ed(0x1e0)||_0x37bc43===_0x1117ed(0x208))&&!_0x43ffc7&&_0x37bc43!==_0x1117ed(0x1aa)&&_0x37bc43!=='Buffer'&&_0x37bc43!==_0x1117ed(0x22a)){var _0x3d5cb5=_0x4398c4['props']||_0xd42476[_0x1117ed(0x1c8)];if(this[_0x1117ed(0x1f4)](_0x4f0721)?(_0x55a81e=0x0,_0x4f0721[_0x1117ed(0x1bb)](function(_0x5cb188){const _0x5b72b8=_0x1117ed;if(_0xa831b8++,_0xd42476[_0x5b72b8(0x230)]++,_0xa831b8>_0x3d5cb5){_0x269e9b=!0x0;return;}if(!_0xd42476[_0x5b72b8(0x19b)]&&_0xd42476['autoExpand']&&_0xd42476[_0x5b72b8(0x230)]>_0xd42476[_0x5b72b8(0x2af)]){_0x269e9b=!0x0;return;}_0xc31cdf[_0x5b72b8(0x22d)](_0x13f92d[_0x5b72b8(0x2ac)](_0x3d8900,_0x4f0721,'Set',_0x55a81e++,_0xd42476,function(_0xda95d6){return function(){return _0xda95d6;};}(_0x5cb188)));})):this[_0x1117ed(0x1ca)](_0x4f0721)&&_0x4f0721[_0x1117ed(0x1bb)](function(_0x379cc7,_0x47bd48){const _0x32775f=_0x1117ed;if(_0xa831b8++,_0xd42476[_0x32775f(0x230)]++,_0xa831b8>_0x3d5cb5){_0x269e9b=!0x0;return;}if(!_0xd42476[_0x32775f(0x19b)]&&_0xd42476[_0x32775f(0x217)]&&_0xd42476['autoExpandPropertyCount']>_0xd42476[_0x32775f(0x2af)]){_0x269e9b=!0x0;return;}var _0x4abe46=_0x47bd48[_0x32775f(0x23b)]();_0x4abe46[_0x32775f(0x27c)]>0x64&&(_0x4abe46=_0x4abe46[_0x32775f(0x1e7)](0x0,0x64)+_0x32775f(0x290)),_0xc31cdf['push'](_0x13f92d[_0x32775f(0x2ac)](_0x3d8900,_0x4f0721,_0x32775f(0x1e1),_0x4abe46,_0xd42476,function(_0x4da377){return function(){return _0x4da377;};}(_0x379cc7)));}),!_0x16cbfd){try{for(_0x5d5334 in _0x4f0721)if(!(_0x434956&&_0x3dd4c7[_0x1117ed(0x1d9)](_0x5d5334))&&!this['_blacklistedProperty'](_0x4f0721,_0x5d5334,_0xd42476)){if(_0xa831b8++,_0xd42476['autoExpandPropertyCount']++,_0xa831b8>_0x3d5cb5){_0x269e9b=!0x0;break;}if(!_0xd42476[_0x1117ed(0x19b)]&&_0xd42476[_0x1117ed(0x217)]&&_0xd42476[_0x1117ed(0x230)]>_0xd42476[_0x1117ed(0x2af)]){_0x269e9b=!0x0;break;}_0xc31cdf[_0x1117ed(0x22d)](_0x13f92d[_0x1117ed(0x28f)](_0x3d8900,_0x4f2573,_0x4f0721,_0x37bc43,_0x5d5334,_0xd42476));}}catch{}if(_0x4f2573['_p_length']=!0x0,_0x3bf246&&(_0x4f2573[_0x1117ed(0x23e)]=!0x0),!_0x269e9b){var _0x163831=[][_0x1117ed(0x24a)](this[_0x1117ed(0x1da)](_0x4f0721))[_0x1117ed(0x24a)](this['_getOwnPropertySymbols'](_0x4f0721));for(_0x55a81e=0x0,_0x4a457b=_0x163831[_0x1117ed(0x27c)];_0x55a81e<_0x4a457b;_0x55a81e++)if(_0x5d5334=_0x163831[_0x55a81e],!(_0x434956&&_0x3dd4c7[_0x1117ed(0x1d9)](_0x5d5334[_0x1117ed(0x23b)]()))&&!this[_0x1117ed(0x2b7)](_0x4f0721,_0x5d5334,_0xd42476)&&!_0x4f2573[typeof _0x5d5334!='symbol'?_0x1117ed(0x2b8)+_0x5d5334[_0x1117ed(0x23b)]():_0x5d5334]){if(_0xa831b8++,_0xd42476[_0x1117ed(0x230)]++,_0xa831b8>_0x3d5cb5){_0x269e9b=!0x0;break;}if(!_0xd42476[_0x1117ed(0x19b)]&&_0xd42476[_0x1117ed(0x217)]&&_0xd42476[_0x1117ed(0x230)]>_0xd42476[_0x1117ed(0x2af)]){_0x269e9b=!0x0;break;}_0xc31cdf[_0x1117ed(0x22d)](_0x13f92d[_0x1117ed(0x28f)](_0x3d8900,_0x4f2573,_0x4f0721,_0x37bc43,_0x5d5334,_0xd42476));}}}}}if(_0x654c15[_0x1117ed(0x272)]=_0x37bc43,_0x548a46?(_0x654c15[_0x1117ed(0x1eb)]=_0x4f0721[_0x1117ed(0x28b)](),this['_capIfString'](_0x37bc43,_0x654c15,_0xd42476,_0x4398c4)):_0x37bc43===_0x1117ed(0x2a0)?_0x654c15[_0x1117ed(0x1eb)]=this['_dateToString'][_0x1117ed(0x1d4)](_0x4f0721):_0x37bc43===_0x1117ed(0x22a)?_0x654c15[_0x1117ed(0x1eb)]=_0x4f0721['toString']():_0x37bc43===_0x1117ed(0x239)?_0x654c15[_0x1117ed(0x1eb)]=this['_regExpToString']['call'](_0x4f0721):_0x37bc43===_0x1117ed(0x19c)&&this['_Symbol']?_0x654c15['value']=this[_0x1117ed(0x249)][_0x1117ed(0x21f)][_0x1117ed(0x23b)][_0x1117ed(0x1d4)](_0x4f0721):!_0xd42476[_0x1117ed(0x1f6)]&&!(_0x37bc43===_0x1117ed(0x1e0)||_0x37bc43===_0x1117ed(0x208))&&(delete _0x654c15['value'],_0x654c15[_0x1117ed(0x2b5)]=!0x0),_0x269e9b&&(_0x654c15['cappedProps']=!0x0),_0x288202=_0xd42476[_0x1117ed(0x294)]['current'],_0xd42476['node'][_0x1117ed(0x2bb)]=_0x654c15,this[_0x1117ed(0x2b9)](_0x654c15,_0xd42476),_0xc31cdf[_0x1117ed(0x27c)]){for(_0x55a81e=0x0,_0x4a457b=_0xc31cdf[_0x1117ed(0x27c)];_0x55a81e<_0x4a457b;_0x55a81e++)_0xc31cdf[_0x55a81e](_0x55a81e);}_0x3d8900[_0x1117ed(0x27c)]&&(_0x654c15['props']=_0x3d8900);}catch(_0x1d69bd){_0x47081f(_0x1d69bd,_0x654c15,_0xd42476);}this[_0x1117ed(0x1fe)](_0x4f0721,_0x654c15),this['_treeNodePropertiesAfterFullValue'](_0x654c15,_0xd42476),_0xd42476[_0x1117ed(0x294)][_0x1117ed(0x2bb)]=_0x288202,_0xd42476[_0x1117ed(0x1f2)]--,_0xd42476[_0x1117ed(0x217)]=_0x264837,_0xd42476[_0x1117ed(0x217)]&&_0xd42476[_0x1117ed(0x1a9)]['pop']();}finally{_0x528572&&(_0x52b907[_0x1117ed(0x207)][_0x1117ed(0x287)]=_0x528572),_0x57b219&&(_0x52b907[_0x1117ed(0x207)][_0x1117ed(0x201)]=_0x57b219),_0x52b907['ninjaSuppressConsole']=_0x4aa3a7;}return _0x654c15;},_0x3469da[_0x4dd550(0x21f)][_0x4dd550(0x2c4)]=function(_0x24540a){const _0x53112a=_0x4dd550;return Object[_0x53112a(0x21c)]?Object[_0x53112a(0x21c)](_0x24540a):[];},_0x3469da[_0x4dd550(0x21f)][_0x4dd550(0x1f4)]=function(_0x5d3dc3){const _0x21557d=_0x4dd550;return!!(_0x5d3dc3&&_0x52b907[_0x21557d(0x29a)]&&this[_0x21557d(0x252)](_0x5d3dc3)===_0x21557d(0x2c7)&&_0x5d3dc3['forEach']);},_0x3469da[_0x4dd550(0x21f)][_0x4dd550(0x2b7)]=function(_0x5a3d37,_0x48b733,_0x5abfe6){const _0xa0bc7b=_0x4dd550;if(!_0x5abfe6[_0xa0bc7b(0x23a)]){let _0x933fd0=this[_0xa0bc7b(0x253)](_0x5a3d37,_0x48b733);if(_0x933fd0&&_0x933fd0[_0xa0bc7b(0x2aa)])return!0x0;}return _0x5abfe6[_0xa0bc7b(0x291)]?typeof _0x5a3d37[_0x48b733]==_0xa0bc7b(0x1fa):!0x1;},_0x3469da[_0x4dd550(0x21f)][_0x4dd550(0x231)]=function(_0x225a36){const _0x20a550=_0x4dd550;var _0x256031='';return _0x256031=typeof _0x225a36,_0x256031===_0x20a550(0x1e3)?this[_0x20a550(0x252)](_0x225a36)===_0x20a550(0x1ab)?_0x256031=_0x20a550(0x1f3):this[_0x20a550(0x252)](_0x225a36)===_0x20a550(0x19a)?_0x256031=_0x20a550(0x2a0):this[_0x20a550(0x252)](_0x225a36)===_0x20a550(0x1b2)?_0x256031=_0x20a550(0x22a):_0x225a36===null?_0x256031=_0x20a550(0x1e0):_0x225a36['constructor']&&(_0x256031=_0x225a36[_0x20a550(0x228)][_0x20a550(0x1d5)]||_0x256031):_0x256031===_0x20a550(0x208)&&this[_0x20a550(0x24b)]&&_0x225a36 instanceof this['_HTMLAllCollection']&&(_0x256031=_0x20a550(0x278)),_0x256031;},_0x3469da[_0x4dd550(0x21f)][_0x4dd550(0x252)]=function(_0xa0a4ea){const _0x1acc1e=_0x4dd550;return Object[_0x1acc1e(0x21f)]['toString'][_0x1acc1e(0x1d4)](_0xa0a4ea);},_0x3469da['prototype'][_0x4dd550(0x2b6)]=function(_0x8a77e6){const _0x464167=_0x4dd550;return _0x8a77e6===_0x464167(0x24f)||_0x8a77e6===_0x464167(0x1b6)||_0x8a77e6==='number';},_0x3469da[_0x4dd550(0x21f)][_0x4dd550(0x204)]=function(_0x28751f){const _0x3233de=_0x4dd550;return _0x28751f===_0x3233de(0x24c)||_0x28751f==='String'||_0x28751f==='Number';},_0x3469da[_0x4dd550(0x21f)]['_addProperty']=function(_0x37f890,_0x40af1c,_0xaf7c04,_0x4512d4,_0x49c5f6,_0x585a12){var _0xe0d7b6=this;return function(_0x426b94){const _0x510693=_0x1a3f;var _0x541556=_0x49c5f6[_0x510693(0x294)][_0x510693(0x2bb)],_0x1941f5=_0x49c5f6['node'][_0x510693(0x273)],_0x224c82=_0x49c5f6['node'][_0x510693(0x2a6)];_0x49c5f6[_0x510693(0x294)][_0x510693(0x2a6)]=_0x541556,_0x49c5f6['node'][_0x510693(0x273)]=typeof _0x4512d4==_0x510693(0x29c)?_0x4512d4:_0x426b94,_0x37f890['push'](_0xe0d7b6[_0x510693(0x2be)](_0x40af1c,_0xaf7c04,_0x4512d4,_0x49c5f6,_0x585a12)),_0x49c5f6[_0x510693(0x294)][_0x510693(0x2a6)]=_0x224c82,_0x49c5f6[_0x510693(0x294)][_0x510693(0x273)]=_0x1941f5;};},_0x3469da[_0x4dd550(0x21f)][_0x4dd550(0x28f)]=function(_0x24b552,_0x3534cb,_0x3165b3,_0x45b582,_0x47d546,_0x541c7e,_0x156a23){const _0x323298=_0x4dd550;var _0xe4591d=this;return _0x3534cb[typeof _0x47d546!=_0x323298(0x19c)?'_p_'+_0x47d546['toString']():_0x47d546]=!0x0,function(_0xbef6f){const _0x5a4f12=_0x323298;var _0x112648=_0x541c7e[_0x5a4f12(0x294)][_0x5a4f12(0x2bb)],_0x5d934a=_0x541c7e[_0x5a4f12(0x294)][_0x5a4f12(0x273)],_0x22eecb=_0x541c7e[_0x5a4f12(0x294)][_0x5a4f12(0x2a6)];_0x541c7e[_0x5a4f12(0x294)][_0x5a4f12(0x2a6)]=_0x112648,_0x541c7e['node'][_0x5a4f12(0x273)]=_0xbef6f,_0x24b552[_0x5a4f12(0x22d)](_0xe4591d['_property'](_0x3165b3,_0x45b582,_0x47d546,_0x541c7e,_0x156a23)),_0x541c7e[_0x5a4f12(0x294)]['parent']=_0x22eecb,_0x541c7e[_0x5a4f12(0x294)][_0x5a4f12(0x273)]=_0x5d934a;};},_0x3469da[_0x4dd550(0x21f)][_0x4dd550(0x2be)]=function(_0x31e394,_0x38543d,_0x1d9e36,_0x458c64,_0x160fb0){const _0x41a8a7=_0x4dd550;var _0x156b68=this;_0x160fb0||(_0x160fb0=function(_0x16f724,_0x558f42){return _0x16f724[_0x558f42];});var _0x5d6a0e=_0x1d9e36['toString'](),_0x89f5fa=_0x458c64[_0x41a8a7(0x1ef)]||{},_0x22cf6b=_0x458c64[_0x41a8a7(0x1f6)],_0x52a568=_0x458c64[_0x41a8a7(0x19b)];try{var _0x25a332=this['_isMap'](_0x31e394),_0x45fdfe=_0x5d6a0e;_0x25a332&&_0x45fdfe[0x0]==='\\x27'&&(_0x45fdfe=_0x45fdfe[_0x41a8a7(0x227)](0x1,_0x45fdfe[_0x41a8a7(0x27c)]-0x2));var _0x322227=_0x458c64[_0x41a8a7(0x1ef)]=_0x89f5fa[_0x41a8a7(0x2b8)+_0x45fdfe];_0x322227&&(_0x458c64[_0x41a8a7(0x1f6)]=_0x458c64['depth']+0x1),_0x458c64[_0x41a8a7(0x19b)]=!!_0x322227;var _0x5a7ba4=typeof _0x1d9e36==_0x41a8a7(0x19c),_0x943258={'name':_0x5a7ba4||_0x25a332?_0x5d6a0e:this[_0x41a8a7(0x206)](_0x5d6a0e)};if(_0x5a7ba4&&(_0x943258[_0x41a8a7(0x19c)]=!0x0),!(_0x38543d==='array'||_0x38543d===_0x41a8a7(0x1b3))){var _0x437f89=this[_0x41a8a7(0x253)](_0x31e394,_0x1d9e36);if(_0x437f89&&(_0x437f89['set']&&(_0x943258[_0x41a8a7(0x255)]=!0x0),_0x437f89[_0x41a8a7(0x2aa)]&&!_0x322227&&!_0x458c64[_0x41a8a7(0x23a)]))return _0x943258['getter']=!0x0,this[_0x41a8a7(0x216)](_0x943258,_0x458c64),_0x943258;}var _0x21f84a;try{_0x21f84a=_0x160fb0(_0x31e394,_0x1d9e36);}catch(_0x331d2d){return _0x943258={'name':_0x5d6a0e,'type':_0x41a8a7(0x1ee),'error':_0x331d2d[_0x41a8a7(0x26e)]},this[_0x41a8a7(0x216)](_0x943258,_0x458c64),_0x943258;}var _0x107cad=this[_0x41a8a7(0x231)](_0x21f84a),_0x1e64bd=this[_0x41a8a7(0x2b6)](_0x107cad);if(_0x943258[_0x41a8a7(0x272)]=_0x107cad,_0x1e64bd)this[_0x41a8a7(0x216)](_0x943258,_0x458c64,_0x21f84a,function(){const _0x303e3b=_0x41a8a7;_0x943258['value']=_0x21f84a[_0x303e3b(0x28b)](),!_0x322227&&_0x156b68[_0x303e3b(0x22e)](_0x107cad,_0x943258,_0x458c64,{});});else{var _0x58458d=_0x458c64[_0x41a8a7(0x217)]&&_0x458c64[_0x41a8a7(0x1f2)]<_0x458c64['autoExpandMaxDepth']&&_0x458c64[_0x41a8a7(0x1a9)]['indexOf'](_0x21f84a)<0x0&&_0x107cad!=='function'&&_0x458c64['autoExpandPropertyCount']<_0x458c64['autoExpandLimit'];_0x58458d||_0x458c64[_0x41a8a7(0x1f2)]<_0x22cf6b||_0x322227?this[_0x41a8a7(0x1c6)](_0x943258,_0x21f84a,_0x458c64,_0x322227||{}):this['_processTreeNodeResult'](_0x943258,_0x458c64,_0x21f84a,function(){const _0x54d9f6=_0x41a8a7;_0x107cad==='null'||_0x107cad===_0x54d9f6(0x208)||(delete _0x943258['value'],_0x943258[_0x54d9f6(0x2b5)]=!0x0);});}return _0x943258;}finally{_0x458c64[_0x41a8a7(0x1ef)]=_0x89f5fa,_0x458c64[_0x41a8a7(0x1f6)]=_0x22cf6b,_0x458c64['isExpressionToEvaluate']=_0x52a568;}},_0x3469da[_0x4dd550(0x21f)][_0x4dd550(0x22e)]=function(_0x1eb813,_0x1621bc,_0x1a1617,_0x5dffce){const _0x4fc4c0=_0x4dd550;var _0x591ab1=_0x5dffce[_0x4fc4c0(0x27b)]||_0x1a1617['strLength'];if((_0x1eb813===_0x4fc4c0(0x1b6)||_0x1eb813===_0x4fc4c0(0x1aa))&&_0x1621bc[_0x4fc4c0(0x1eb)]){let _0x1e7736=_0x1621bc[_0x4fc4c0(0x1eb)][_0x4fc4c0(0x27c)];_0x1a1617[_0x4fc4c0(0x262)]+=_0x1e7736,_0x1a1617[_0x4fc4c0(0x262)]>_0x1a1617[_0x4fc4c0(0x24d)]?(_0x1621bc[_0x4fc4c0(0x2b5)]='',delete _0x1621bc['value']):_0x1e7736>_0x591ab1&&(_0x1621bc[_0x4fc4c0(0x2b5)]=_0x1621bc[_0x4fc4c0(0x1eb)][_0x4fc4c0(0x227)](0x0,_0x591ab1),delete _0x1621bc[_0x4fc4c0(0x1eb)]);}},_0x3469da['prototype']['_isMap']=function(_0x11644c){const _0x7c450e=_0x4dd550;return!!(_0x11644c&&_0x52b907[_0x7c450e(0x1e1)]&&this['_objectToString'](_0x11644c)===_0x7c450e(0x2b1)&&_0x11644c[_0x7c450e(0x1bb)]);},_0x3469da[_0x4dd550(0x21f)][_0x4dd550(0x206)]=function(_0x59547f){const _0x5f49b1=_0x4dd550;if(_0x59547f[_0x5f49b1(0x2a4)](/^\\d+$/))return _0x59547f;var _0x27c141;try{_0x27c141=JSON[_0x5f49b1(0x20d)](''+_0x59547f);}catch{_0x27c141='\\x22'+this[_0x5f49b1(0x252)](_0x59547f)+'\\x22';}return _0x27c141[_0x5f49b1(0x2a4)](/^\"([a-zA-Z_][a-zA-Z_0-9]*)\"$/)?_0x27c141=_0x27c141[_0x5f49b1(0x227)](0x1,_0x27c141[_0x5f49b1(0x27c)]-0x2):_0x27c141=_0x27c141[_0x5f49b1(0x28d)](/'/g,'\\x5c\\x27')[_0x5f49b1(0x28d)](/\\\\\"/g,'\\x22')[_0x5f49b1(0x28d)](/(^\"|\"$)/g,'\\x27'),_0x27c141;},_0x3469da[_0x4dd550(0x21f)][_0x4dd550(0x216)]=function(_0x2c778d,_0x2fb0ea,_0x1d62c8,_0x5c0686){const _0x5c5077=_0x4dd550;this[_0x5c5077(0x2b9)](_0x2c778d,_0x2fb0ea),_0x5c0686&&_0x5c0686(),this[_0x5c5077(0x1fe)](_0x1d62c8,_0x2c778d),this[_0x5c5077(0x2ba)](_0x2c778d,_0x2fb0ea);},_0x3469da[_0x4dd550(0x21f)][_0x4dd550(0x2b9)]=function(_0xa0f493,_0x4ac5a6){const _0x156e5b=_0x4dd550;this[_0x156e5b(0x222)](_0xa0f493,_0x4ac5a6),this[_0x156e5b(0x1b0)](_0xa0f493,_0x4ac5a6),this[_0x156e5b(0x25f)](_0xa0f493,_0x4ac5a6),this[_0x156e5b(0x281)](_0xa0f493,_0x4ac5a6);},_0x3469da[_0x4dd550(0x21f)][_0x4dd550(0x222)]=function(_0x45bc47,_0xfc94c0){},_0x3469da[_0x4dd550(0x21f)][_0x4dd550(0x1b0)]=function(_0x1c4557,_0x4a2643){},_0x3469da[_0x4dd550(0x21f)][_0x4dd550(0x259)]=function(_0x4c008a,_0x2408be){},_0x3469da[_0x4dd550(0x21f)][_0x4dd550(0x296)]=function(_0x12f1e1){const _0x374ff4=_0x4dd550;return _0x12f1e1===this[_0x374ff4(0x25a)];},_0x3469da['prototype'][_0x4dd550(0x2ba)]=function(_0x589fb1,_0x463e13){const _0x166139=_0x4dd550;this[_0x166139(0x259)](_0x589fb1,_0x463e13),this[_0x166139(0x229)](_0x589fb1),_0x463e13[_0x166139(0x27d)]&&this['_sortProps'](_0x589fb1),this[_0x166139(0x1ed)](_0x589fb1,_0x463e13),this[_0x166139(0x2ad)](_0x589fb1,_0x463e13),this[_0x166139(0x246)](_0x589fb1);},_0x3469da[_0x4dd550(0x21f)][_0x4dd550(0x1fe)]=function(_0x4e02fc,_0x12d5bf){const _0x3faf39=_0x4dd550;try{_0x4e02fc&&typeof _0x4e02fc[_0x3faf39(0x27c)]==_0x3faf39(0x29c)&&(_0x12d5bf['length']=_0x4e02fc[_0x3faf39(0x27c)]);}catch{}if(_0x12d5bf[_0x3faf39(0x272)]==='number'||_0x12d5bf[_0x3faf39(0x272)]===_0x3faf39(0x1d8)){if(isNaN(_0x12d5bf['value']))_0x12d5bf['nan']=!0x0,delete _0x12d5bf['value'];else switch(_0x12d5bf[_0x3faf39(0x1eb)]){case Number[_0x3faf39(0x1d6)]:_0x12d5bf[_0x3faf39(0x200)]=!0x0,delete _0x12d5bf[_0x3faf39(0x1eb)];break;case Number[_0x3faf39(0x2bf)]:_0x12d5bf[_0x3faf39(0x26f)]=!0x0,delete _0x12d5bf[_0x3faf39(0x1eb)];break;case 0x0:this[_0x3faf39(0x24e)](_0x12d5bf['value'])&&(_0x12d5bf[_0x3faf39(0x26a)]=!0x0);break;}}else _0x12d5bf[_0x3faf39(0x272)]===_0x3faf39(0x1fa)&&typeof _0x4e02fc[_0x3faf39(0x1d5)]=='string'&&_0x4e02fc[_0x3faf39(0x1d5)]&&_0x12d5bf[_0x3faf39(0x1d5)]&&_0x4e02fc[_0x3faf39(0x1d5)]!==_0x12d5bf[_0x3faf39(0x1d5)]&&(_0x12d5bf[_0x3faf39(0x224)]=_0x4e02fc[_0x3faf39(0x1d5)]);},_0x3469da[_0x4dd550(0x21f)][_0x4dd550(0x24e)]=function(_0x293b24){const _0x255523=_0x4dd550;return 0x1/_0x293b24===Number[_0x255523(0x2bf)];},_0x3469da[_0x4dd550(0x21f)][_0x4dd550(0x28e)]=function(_0x5a93be){const _0x29e035=_0x4dd550;!_0x5a93be[_0x29e035(0x1c8)]||!_0x5a93be['props']['length']||_0x5a93be[_0x29e035(0x272)]==='array'||_0x5a93be[_0x29e035(0x272)]===_0x29e035(0x1e1)||_0x5a93be[_0x29e035(0x272)]===_0x29e035(0x29a)||_0x5a93be[_0x29e035(0x1c8)][_0x29e035(0x1a1)](function(_0x1e223d,_0x3bbb67){const _0x56610b=_0x29e035;var _0x246910=_0x1e223d[_0x56610b(0x1d5)][_0x56610b(0x271)](),_0x2ac88e=_0x3bbb67['name']['toLowerCase']();return _0x246910<_0x2ac88e?-0x1:_0x246910>_0x2ac88e?0x1:0x0;});},_0x3469da['prototype']['_addFunctionsNode']=function(_0x52815c,_0x2f8479){const _0x55d5d9=_0x4dd550;if(!(_0x2f8479['noFunctions']||!_0x52815c[_0x55d5d9(0x1c8)]||!_0x52815c['props'][_0x55d5d9(0x27c)])){for(var _0x5279c0=[],_0x5648b0=[],_0x539dfd=0x0,_0x4ab4f5=_0x52815c['props'][_0x55d5d9(0x27c)];_0x539dfd<_0x4ab4f5;_0x539dfd++){var _0x5ae960=_0x52815c[_0x55d5d9(0x1c8)][_0x539dfd];_0x5ae960[_0x55d5d9(0x272)]==='function'?_0x5279c0[_0x55d5d9(0x22d)](_0x5ae960):_0x5648b0[_0x55d5d9(0x22d)](_0x5ae960);}if(!(!_0x5648b0[_0x55d5d9(0x27c)]||_0x5279c0[_0x55d5d9(0x27c)]<=0x1)){_0x52815c[_0x55d5d9(0x1c8)]=_0x5648b0;var _0x4f26be={'functionsNode':!0x0,'props':_0x5279c0};this[_0x55d5d9(0x222)](_0x4f26be,_0x2f8479),this[_0x55d5d9(0x259)](_0x4f26be,_0x2f8479),this[_0x55d5d9(0x229)](_0x4f26be),this[_0x55d5d9(0x281)](_0x4f26be,_0x2f8479),_0x4f26be['id']+='\\x20f',_0x52815c[_0x55d5d9(0x1c8)]['unshift'](_0x4f26be);}}},_0x3469da[_0x4dd550(0x21f)][_0x4dd550(0x2ad)]=function(_0x1ee559,_0x321a5a){},_0x3469da[_0x4dd550(0x21f)]['_setNodeExpandableState']=function(_0x26e0f6){},_0x3469da[_0x4dd550(0x21f)]['_isArray']=function(_0x42b38c){const _0x50a39f=_0x4dd550;return Array['isArray'](_0x42b38c)||typeof _0x42b38c=='object'&&this[_0x50a39f(0x252)](_0x42b38c)===_0x50a39f(0x1ab);},_0x3469da[_0x4dd550(0x21f)][_0x4dd550(0x281)]=function(_0x26dd19,_0x32b97){},_0x3469da[_0x4dd550(0x21f)]['_cleanNode']=function(_0x5c93ec){const _0x393745=_0x4dd550;delete _0x5c93ec[_0x393745(0x2c2)],delete _0x5c93ec[_0x393745(0x1bc)],delete _0x5c93ec['_hasMapOnItsPath'];},_0x3469da[_0x4dd550(0x21f)][_0x4dd550(0x25f)]=function(_0x5abf74,_0x50dbd3){};let _0x565008=new _0x3469da(),_0x4d7c55={'props':_0x2fe5e6['defaultLimits'][_0x4dd550(0x1c8)]||0x64,'elements':_0x2fe5e6[_0x4dd550(0x19f)][_0x4dd550(0x1ac)]||0x64,'strLength':_0x2fe5e6[_0x4dd550(0x19f)][_0x4dd550(0x27b)]||0x400*0x32,'totalStrLength':_0x2fe5e6[_0x4dd550(0x19f)][_0x4dd550(0x24d)]||0x400*0x32,'autoExpandLimit':_0x2fe5e6['defaultLimits'][_0x4dd550(0x2af)]||0x1388,'autoExpandMaxDepth':_0x2fe5e6[_0x4dd550(0x19f)][_0x4dd550(0x225)]||0xa},_0x3f588b={'props':_0x2fe5e6[_0x4dd550(0x1ec)]['props']||0x5,'elements':_0x2fe5e6[_0x4dd550(0x1ec)][_0x4dd550(0x1ac)]||0x5,'strLength':_0x2fe5e6['reducedLimits'][_0x4dd550(0x27b)]||0x100,'totalStrLength':_0x2fe5e6[_0x4dd550(0x1ec)][_0x4dd550(0x24d)]||0x100*0x3,'autoExpandLimit':_0x2fe5e6[_0x4dd550(0x1ec)]['autoExpandLimit']||0x1e,'autoExpandMaxDepth':_0x2fe5e6[_0x4dd550(0x1ec)][_0x4dd550(0x225)]||0x2};if(_0xa891c1){let _0x48752c=_0x565008['serialize'][_0x4dd550(0x2b2)](_0x565008);_0x565008[_0x4dd550(0x1c6)]=function(_0x3d4cab,_0x3f894e,_0x4d924a,_0x445f32){return _0x48752c(_0x3d4cab,_0xa891c1(_0x3f894e),_0x4d924a,_0x445f32);};}function _0xfa5549(_0x5d0d16,_0x5579f3,_0x1e639e,_0x2b666a,_0x2f8503,_0x17de1b){const _0x21fb0d=_0x4dd550;let _0x4cfbe4,_0x38771b;try{_0x38771b=_0x32cd4e(),_0x4cfbe4=_0x5e3889[_0x5579f3],!_0x4cfbe4||_0x38771b-_0x4cfbe4['ts']>_0x3088cf[_0x21fb0d(0x1b7)][_0x21fb0d(0x1a3)]&&_0x4cfbe4[_0x21fb0d(0x20f)]&&_0x4cfbe4[_0x21fb0d(0x1f1)]/_0x4cfbe4[_0x21fb0d(0x20f)]<_0x3088cf['perLogpoint']['resetOnProcessingTimeAverageMs']?(_0x5e3889[_0x5579f3]=_0x4cfbe4={'count':0x0,'time':0x0,'ts':_0x38771b},_0x5e3889[_0x21fb0d(0x233)]={}):_0x38771b-_0x5e3889[_0x21fb0d(0x233)]['ts']>_0x3088cf['global'][_0x21fb0d(0x1a3)]&&_0x5e3889[_0x21fb0d(0x233)][_0x21fb0d(0x20f)]&&_0x5e3889[_0x21fb0d(0x233)][_0x21fb0d(0x1f1)]/_0x5e3889[_0x21fb0d(0x233)]['count']<_0x3088cf[_0x21fb0d(0x1fb)][_0x21fb0d(0x1bd)]&&(_0x5e3889[_0x21fb0d(0x233)]={});let _0x513536=[],_0x5a7e63=_0x4cfbe4['reduceLimits']||_0x5e3889['hits']['reduceLimits']?_0x3f588b:_0x4d7c55,_0x31a4ed=_0x5505bb=>{const _0x757da2=_0x21fb0d;let _0x220a4e={};return _0x220a4e[_0x757da2(0x1c8)]=_0x5505bb[_0x757da2(0x1c8)],_0x220a4e['elements']=_0x5505bb[_0x757da2(0x1ac)],_0x220a4e[_0x757da2(0x27b)]=_0x5505bb[_0x757da2(0x27b)],_0x220a4e[_0x757da2(0x24d)]=_0x5505bb['totalStrLength'],_0x220a4e['autoExpandLimit']=_0x5505bb[_0x757da2(0x2af)],_0x220a4e[_0x757da2(0x225)]=_0x5505bb[_0x757da2(0x225)],_0x220a4e[_0x757da2(0x27d)]=!0x1,_0x220a4e[_0x757da2(0x291)]=!_0x549d55,_0x220a4e[_0x757da2(0x1f6)]=0x1,_0x220a4e[_0x757da2(0x1f2)]=0x0,_0x220a4e['expId']='root_exp_id',_0x220a4e[_0x757da2(0x29b)]=_0x757da2(0x2b3),_0x220a4e['autoExpand']=!0x0,_0x220a4e[_0x757da2(0x1a9)]=[],_0x220a4e[_0x757da2(0x230)]=0x0,_0x220a4e['resolveGetters']=_0x2fe5e6['resolveGetters'],_0x220a4e[_0x757da2(0x262)]=0x0,_0x220a4e[_0x757da2(0x294)]={'current':void 0x0,'parent':void 0x0,'index':0x0},_0x220a4e;};for(var _0x277461=0x0;_0x277461<_0x2f8503[_0x21fb0d(0x27c)];_0x277461++)_0x513536[_0x21fb0d(0x22d)](_0x565008[_0x21fb0d(0x1c6)]({'timeNode':_0x5d0d16===_0x21fb0d(0x1f1)||void 0x0},_0x2f8503[_0x277461],_0x31a4ed(_0x5a7e63),{}));if(_0x5d0d16===_0x21fb0d(0x1bf)||_0x5d0d16===_0x21fb0d(0x287)){let _0xf68e48=Error['stackTraceLimit'];try{Error[_0x21fb0d(0x286)]=0x1/0x0,_0x513536['push'](_0x565008['serialize']({'stackNode':!0x0},new Error()['stack'],_0x31a4ed(_0x5a7e63),{'strLength':0x1/0x0}));}finally{Error[_0x21fb0d(0x286)]=_0xf68e48;}}return{'method':_0x21fb0d(0x1c5),'version':_0x75684f,'args':[{'ts':_0x1e639e,'session':_0x2b666a,'args':_0x513536,'id':_0x5579f3,'context':_0x17de1b}]};}catch(_0x49d076){return{'method':'log','version':_0x75684f,'args':[{'ts':_0x1e639e,'session':_0x2b666a,'args':[{'type':_0x21fb0d(0x1ee),'error':_0x49d076&&_0x49d076[_0x21fb0d(0x26e)]}],'id':_0x5579f3,'context':_0x17de1b}]};}finally{try{if(_0x4cfbe4&&_0x38771b){let _0x21f7fd=_0x32cd4e();_0x4cfbe4['count']++,_0x4cfbe4[_0x21fb0d(0x1f1)]+=_0x4b5072(_0x38771b,_0x21f7fd),_0x4cfbe4['ts']=_0x21f7fd,_0x5e3889[_0x21fb0d(0x233)][_0x21fb0d(0x20f)]++,_0x5e3889[_0x21fb0d(0x233)]['time']+=_0x4b5072(_0x38771b,_0x21f7fd),_0x5e3889[_0x21fb0d(0x233)]['ts']=_0x21f7fd,(_0x4cfbe4[_0x21fb0d(0x20f)]>_0x3088cf[_0x21fb0d(0x1b7)]['reduceOnCount']||_0x4cfbe4[_0x21fb0d(0x1f1)]>_0x3088cf[_0x21fb0d(0x1b7)][_0x21fb0d(0x218)])&&(_0x4cfbe4[_0x21fb0d(0x214)]=!0x0),(_0x5e3889[_0x21fb0d(0x233)][_0x21fb0d(0x20f)]>_0x3088cf[_0x21fb0d(0x1fb)]['reduceOnCount']||_0x5e3889[_0x21fb0d(0x233)][_0x21fb0d(0x1f1)]>_0x3088cf['global']['reduceOnAccumulatedProcessingTimeMs'])&&(_0x5e3889[_0x21fb0d(0x233)][_0x21fb0d(0x214)]=!0x0);}}catch{}}}return _0xfa5549;}var q=Symbol(_0x5647ca(0x25c)),ce=0xc8,ee=_0x5647ca(0x27e);((_0x58614a,_0x1eba96,_0x5a68de,_0x14a389,_0x8a5605,_0x39f7f1,_0x5ca492,_0x12ff05,_0x39953a,_0x557397,_0x5b866a,_0x53a960)=>{const _0x349876=_0x5647ca;if(!Y(_0x58614a,_0x12ff05,_0x39f7f1)){_0x58614a[_0x349876(0x1d0)]=!0x0;return;}if(_0x58614a[_0x349876(0x1d0)])return;_0x58614a[_0x349876(0x1d0)]=!0x0;let _0xdaf701=_0x39f7f1===_0x349876(0x2a3)&&_0x58614a['origin']?_0x58614a[_0x349876(0x234)]:void 0x0,_0x610a05=!0x1,_0x597676={},_0x3a52ce={},_0x4e1ad6=()=>{const _0x26bf53=_0x349876;for(let _0x17671f of Object[_0x26bf53(0x25b)](_0x597676))delete _0x597676[_0x17671f];for(let _0x210e88 of Object[_0x26bf53(0x25b)](_0x3a52ce))delete _0x3a52ce[_0x210e88];},_0x4bb2e3=Z(_0x58614a,_0x1eba96,_0x5a68de,_0x14a389,_0x39f7f1,_0x39953a,_0x557397,(_0x161455,_0x4d3c42,_0x3a5b2c,_0x4ea7f7)=>{const _0xb83885=_0x349876;if(V(_0x161455,_0x4d3c42,_0x3a5b2c,_0x4ea7f7),_0x161455===_0xb83885(0x283)){let _0x220b4d=_0x4d3c42[0x0];if(_0x220b4d['hasOwnProperty'](_0xb83885(0x1e9))&&_0x14722e(_0x220b4d[_0xb83885(0x1e9)]),_0x220b4d[_0xb83885(0x232)](_0xb83885(0x265))){for(let _0x35eaf6 of _0x220b4d['blacklistEntries']){let _0x4a670a=se(_0x433ce8[_0xb83885(0x263)],_0x35eaf6[_0xb83885(0x248)]);_0x597676[_0x4a670a]=_0x35eaf6[_0xb83885(0x1a7)];for(let _0x4a57ce of _0x35eaf6['files']){let _0x1378e0=_0x3a52ce[_0x4a57ce];if(_0x1378e0)_0x1378e0[_0x4a670a]=void 0x0;else{let _0x1d15aa={};_0x1d15aa[_0x4a670a]=void 0x0,_0x3a52ce[_0x4a57ce]=_0x1d15aa;}}}Object[_0xb83885(0x205)](_0x597676)[_0xb83885(0x27c)]>ce&&(_0x14722e(!0x1),_0x4e1ad6(),_0x4bb2e3({'method':'pauseNetworkLogging','version':_0x8a5605,'args':[_0x433ce8]}));}if(_0x220b4d['hasOwnProperty'](_0xb83885(0x1d1)))for(let _0x32a562 of _0x220b4d['openFiles']){let _0x237253=_0x3a52ce[_0x32a562];if(!!_0x237253)for(var _0x4108d5 of Object[_0xb83885(0x205)](_0x237253)){let _0x211bf2=_0x597676[_0x4108d5];for(let _0x293ec5 of _0x211bf2){let _0x4cc21b=_0x3a52ce[_0x293ec5];_0x4cc21b&&delete _0x4cc21b[_0x4108d5],Object[_0xb83885(0x205)](_0x4cc21b)[_0xb83885(0x27c)]||delete _0x3a52ce[_0x293ec5];}delete _0x597676[_0x4108d5];}}}}),_0x433ce8=_0x58614a[_0x349876(0x299)],_0x277faf,_0x4a18e1,_0x21a5aa,_0x3b041a,_0x597d64=me(_0x433ce8['tool']);function _0x14722e(_0x4c793c){_0x610a05!==_0x4c793c&&(_0x4c793c===!0x0?(_0x21a5aa=_0x21a5aa||pe(_0x58614a,_0x433ce8,_0x8a5605,_0x4bb2e3,_0x597676,_0xdaf701,_0x597d64,_0x5b866a),_0x3b041a=_0x3b041a||le(_0x58614a,_0x4bb2e3,_0x8a5605,_0x433ce8,_0xdaf701),_0x277faf=de(_0x58614a,_0x21a5aa,_0x3b041a,_0x597d64),_0x4a18e1=ue(_0x58614a,_0x21a5aa,_0x597d64),_0x610a05=!0x0):_0x4c793c===!0x1&&(_0x277faf(),_0x4a18e1(),_0x610a05=!0x1));}_0x14722e(!0x0);let _0x415bcf;_0x39f7f1===_0x349876(0x2a3)&&_0x58614a['TURBOPACK']&&_0x53a960&&_0x53a960['nextJsDistDir']&&(_0x415bcf={'nextJsDistDir':_0x53a960['nextJsDistDir']}),_0x4bb2e3({'method':_0x349876(0x270),'version':_0x8a5605,'args':[_0x433ce8,_0x415bcf]});})(globalThis,'127.0.0.1',_0x5647ca(0x251),_0x5647ca(0x274),'1.0.0','next.js',_0x5647ca(0x1df),_0x5647ca(0x22c),_0x5647ca(0x1f0),_0x5647ca(0x1ce),_0x5647ca(0x1c3),{\"nextJsDistDir\":\"A:\\\\Diseno web(Javascrit)\\\\Mini-Proyectos\\\\Proyectos importantes\\\\E-Comerce\\\\frontend\\\\.next\\\\dev\"});function _0x1e78(){const _0x4338bc=['replace','_sortProps','_addObjectProperty','...','noFunctions','apply','toUpperCase','node','onclose','_isUndefined','fetch','see\\x20https://tinyurl.com/2vt8jxzw\\x20for\\x20more\\x20info.','_console_ninja_session','Set','rootExpression','number','parse','method','reducePolicy','date','location','reduceOnCount','next.js','match','onmessage','parent','headers','_connectAttemptCount','_devMiddlewareManifest.json','get','_dateToString','_addProperty','_addLoadNode','ReadableStream','autoExpandLimit','readyState','[object\\x20Map]','bind','root_exp','readystatechange','capped','_isPrimitiveType','_blacklistedProperty','_p_','_treeNodePropertiesBeforeFullValue','_treeNodePropertiesAfterFullValue','current','versions','path','_property','NEGATIVE_INFINITY','nodeModules','_allowedToConnectOnSend','_hasSymbolPropertyOnItsPath','timeStamp','_getOwnPropertySymbols','\\x20server','XMLHttpRequest','[object\\x20Set]','[object\\x20Date]','isExpressionToEvaluate','symbol','NEXT_RUNTIME','_socket','defaultLimits','angular\\x20browser','sort','11369790vqYGzb','resetWhenQuietMs','WebSocket','Content-Type','_sendErrorMessage','files','response','autoExpandPreviousObjects','String','[object\\x20Array]','elements','.hot-update.json','indexOf','addEventListener','_setNodeQueryPath','byteLength','[object\\x20BigInt]','Error','failed\\x20to\\x20connect\\x20to\\x20host:\\x20','some','string','perLogpoint','ArrayBuffer','remix','react-native','forEach','_hasSetOnItsPath','resetOnProcessingTimeAverageMs','Blob','trace','onerror','_reconnectTimeout','setRequestHeader',{\"resolveGetters\":false,\"defaultLimits\":{\"props\":100,\"elements\":100,\"strLength\":51200,\"totalStrLength\":51200,\"autoExpandLimit\":5000,\"autoExpandMaxDepth\":10},\"reducedLimits\":{\"props\":5,\"elements\":5,\"strLength\":256,\"totalStrLength\":768,\"autoExpandLimit\":30,\"autoExpandMaxDepth\":2},\"reducePolicy\":{\"perLogpoint\":{\"reduceOnCount\":50,\"reduceOnAccumulatedProcessingTimeMs\":100,\"resetWhenQuietMs\":500,\"resetOnProcessingTimeAverageMs\":100},\"global\":{\"reduceOnCount\":1000,\"reduceOnAccumulatedProcessingTimeMs\":300,\"resetWhenQuietMs\":50,\"resetOnProcessingTimeAverageMs\":100}}},'\\x20browser','log','serialize','env','props','split','_isMap','next.js\\x20browser','URLSearchParams','args','1','unref','_triedToInstallNetworkLoggingHandler','openFiles','now','DataView','call','name','POSITIVE_INFINITY','27660cDKYin','Number','test','_getOwnPropertyNames','includes','astro','hrtime','_connecting','1775804682584','null','Map','then','object','2200866VYgZOl','2970175CVOGYa','catch','slice','expo','captureRequests','splice','value','reducedLimits','_addFunctionsNode','unknown','expressionsToEvaluate','','time','level','array','_isSet','status','depth','_disposeWebsocket','default','_consoleNinjaAllowedToStart','function','global','_maxConnectAttemptCount','_attemptToReconnectShortly','_additionalMetadata','ws://','positiveInfinity','warn','host','arrayBuffer','_isPrimitiveWrapperType','keys','_propertyName','console','undefined','blob','return\\x20import(url.pathToFileURL(path.join(nodeModules,\\x20\\x27ws/index.js\\x27)).toString());','_connectToHostNow','send','stringify','port','count','_keyStrRegExp','_WebSocketClass','open','close','reduceLimits','hostname','_processTreeNodeResult','autoExpand','reduceOnAccumulatedProcessingTimeMs','text','background:\\x20rgb(30,30,30);\\x20color:\\x20rgb(255,213,92)','fromCharCode','getOwnPropertySymbols','logger\\x20websocket\\x20error','logger\\x20failed\\x20to\\x20connect\\x20to\\x20host,\\x20see\\x20','prototype','TypedArray','_inBrowser','_setNodeId','301WgVWDc','funcName','autoExpandMaxDepth','edge','substr','constructor','_setNodeExpandableState','bigint','_allowedToSend',[\"localhost\",\"127.0.0.1\",\"example.cypress.io\",\"10.0.2.2\",\"DESKTOP-5AJBO8M\",\"192.168.42.143\"],'push','_capIfString','request','autoExpandPropertyCount','_type','hasOwnProperty','hits','origin','json','_quotedRegExp','entries','getResponseHeader','RegExp','resolveGetters','toString','join','ninjaSuppressConsole','_p_name','_connected','emulator','246072oyyuje','4433BvWURS','getWebSocketClass','dockerizedApp','modules','_cleanNode','logger\\x20failed\\x20to\\x20connect\\x20to\\x20host','stack','_Symbol','concat','_HTMLAllCollection','Boolean','totalStrLength','_isNegativeZero','boolean','_extendedWarning','59311','_objectToString','_getOwnPropertyDescriptor','cappedElements','setter','%c\\x20Console\\x20Ninja\\x20extension\\x20is\\x20connected\\x20to\\x20','url','_ninjaInstallGlobalErrorHandler','_setNodeLabel','_undefined','getOwnPropertyNames','ninja','reload','getOwnPropertyDescriptor','_setNodeExpressionPath','10.0.2.2','1465wnDSgG','allStrLength','tool','import(\\x27path\\x27)','blacklistEntries','native\\x20code','https://tinyurl.com/37x8b79t','elapsed','startsWith','negativeZero','340tZdeOo','eventReceivedCallback','onopen','message','negativeInfinity','networkLoggingHandlerInstalled','toLowerCase','type','index',\"c:\\\\Users\\\\Luisi\\\\.vscode\\\\extensions\\\\wallabyjs.console-ninja-1.0.524\\\\node_modules\",'602872elEdra','4VAVEwp','fetchStack','HTMLAllCollection','body','process','strLength','length','sortProps','application/json','endsWith','__nextjs_original-stack-frame','_setNodePermissions','_regExpToString','updateNetworkLoggingConfig',',\\x20see\\x20https://tinyurl.com/2vt8jxzw\\x20for\\x20more\\x20info.','_inNextEdge','stackTraceLimit','error','_ws','map','Response','valueOf','_WebSocket'];_0x1e78=function(){return _0x4338bc;};return _0x1e78();}function ue(_0x2fd24c,_0x2fd33a,_0x36ebe4){const _0x23746a=_0x5647ca;if(_0x2fd24c['XMLHttpRequest']&&_0x2fd24c[_0x23746a(0x2c6)][_0x23746a(0x21f)]){let _0x35ebed=_0x2fd24c[_0x23746a(0x2c6)][_0x23746a(0x21f)][_0x23746a(0x212)],_0x49c2cb=_0x2fd24c[_0x23746a(0x2c6)][_0x23746a(0x21f)][_0x23746a(0x20c)],_0x1c915d=_0x2fd24c[_0x23746a(0x2c6)]['prototype'][_0x23746a(0x1c2)];return _0x35ebed&&_0x49c2cb&&_0x35ebed[_0x23746a(0x23b)]()[_0x23746a(0x1ae)](_0x23746a(0x266))!==-0x1?(_0x2fd24c['XMLHttpRequest'][_0x23746a(0x21f)][_0x23746a(0x212)]=function(_0x2db602,_0xc5b4f6){const _0x2a3b3b=_0x23746a;let _0x55299e=this[q]=this[q]||{};return _0x55299e[_0x2a3b3b(0x29e)]=_0x2db602,_0x55299e[_0x2a3b3b(0x257)]=_0xc5b4f6,_0x35ebed[_0x2a3b3b(0x292)](this,arguments);},_0x2fd24c[_0x23746a(0x2c6)][_0x23746a(0x21f)][_0x23746a(0x20c)]=function(){const _0x3daa62=_0x23746a;let _0x46862b=te(_0x36ebe4);return this[_0x3daa62(0x1af)](_0x3daa62(0x2b4),()=>{const _0x11b3bb=_0x3daa62;var _0x282d07,_0x49a968;if(this[_0x11b3bb(0x2b0)]===0x4){let _0x1a8610=this[_0x11b3bb(0x238)](_0x11b3bb(0x1a5)),_0x37722d=_0x1a8610&&_0x1a8610['indexOf'](ee)!==-0x1?ne(this[_0x11b3bb(0x1a8)],ee):this[_0x11b3bb(0x1a8)],_0x2505b0=oe((_0x282d07=this[q])==null?void 0x0:_0x282d07[_0x11b3bb(0x2a7)]),_0x162e16=_0x2505b0?ne(arguments[0x0],_0x2505b0):arguments[0x0],_0x5a06b8=(_0x49a968=this[_0x11b3bb(0x1f5)])==null?void 0x0:_0x49a968['toString']();_0x2fd33a({'stack':_0x46862b,'status':_0x5a06b8,'url':this[q]['url'],'method':this[q]['method'],'request':_0x162e16,'response':_0x37722d});}}),_0x49c2cb[_0x3daa62(0x292)](this,arguments);},_0x1c915d&&(_0x2fd24c['XMLHttpRequest'][_0x23746a(0x21f)][_0x23746a(0x1c2)]=function(_0x18565b,_0x4799a4){const _0x4d1e72=_0x23746a;let _0x370d55=this[q]=this[q]||{},_0x333ee9=_0x370d55[_0x4d1e72(0x2a7)]=_0x370d55[_0x4d1e72(0x2a7)]||{};_0x333ee9[_0x18565b]=_0x4799a4,_0x1c915d[_0x4d1e72(0x292)](this,arguments);}),()=>{const _0x5cf286=_0x23746a;_0x2fd24c[_0x5cf286(0x2c6)][_0x5cf286(0x21f)][_0x5cf286(0x212)]=_0x35ebed,_0x2fd24c[_0x5cf286(0x2c6)][_0x5cf286(0x21f)]['send']=_0x49c2cb,_0x2fd24c[_0x5cf286(0x2c6)]['prototype'][_0x5cf286(0x1c2)]=_0x1c915d;}):()=>{};}}function de(_0x1b5a02,_0x2e5852,_0x49053c,_0xb469ba){const _0x429a6d=_0x5647ca;let _0x5cef1e=_0x1b5a02[_0x429a6d(0x297)];if(_0x1b5a02[_0x429a6d(0x28a)]&&_0x1b5a02['Response'][_0x429a6d(0x21f)]&&_0x5cef1e['toString']()[_0x429a6d(0x1ae)](_0x429a6d(0x266))!==-0x1){let _0x25799d=function(){const _0x5b6964=_0x429a6d;return _0x1b5a02['fetch']=function(..._0x8a6939){const _0x3f7506=_0x1a3f;var _0x3089b9;let [_0x1433c1,_0x473724]=_0x8a6939,_0x4f43c2=_0x473724&&_0x473724['method']?_0x473724[_0x3f7506(0x29e)]:'GET',_0x19d399=te(_0xb469ba),_0x36349d=_0x8a6939&&_0x8a6939[_0x3f7506(0x27c)]>0x0&&((_0x3089b9=_0x8a6939[0x1])==null?void 0x0:_0x3089b9[_0x3f7506(0x2a7)]),_0x1a77d8=oe(_0x36349d),_0x3afe89=_0x473724!=null&&_0x473724[_0x3f7506(0x279)]?ne(_0x473724[_0x3f7506(0x279)],_0x1a77d8):_0x473724==null?void 0x0:_0x473724[_0x3f7506(0x279)];return _0x5cef1e[_0x3f7506(0x292)](this,_0x8a6939)[_0x3f7506(0x1e2)](_0x38d63a=>(_0x38d63a[q]={'method':_0x4f43c2,'fetchStack':_0x19d399,'request':_0x3afe89},_0x38d63a));},()=>_0x1b5a02[_0x5b6964(0x297)]=_0x5cef1e;},_0x3f9bba=function(_0x4bda37,_0x2de595=_0x126e67=>_0x126e67){const _0x588291=_0x429a6d;let _0x24faad=_0x1b5a02['Response'][_0x588291(0x21f)][_0x4bda37];return _0x24faad?(_0x1b5a02['Response'][_0x588291(0x21f)][_0x4bda37]=async function(){const _0x4269fc=_0x588291;var _0x330606;let _0x5ebd73=te(_0xb469ba),_0x56fbeb;try{_0x56fbeb=await _0x24faad[_0x4269fc(0x292)](this,arguments);}catch(_0x5405c2){throw _0x49053c(_0x5405c2,_0x5ebd73),_0x5405c2;}let _0x5e3ee5=this[q];return _0x5e3ee5&&_0x2e5852({'stack':_0x5ebd73,'fetchStack':_0x5e3ee5[_0x4269fc(0x277)],'url':this[_0x4269fc(0x257)],'status':(_0x330606=this[_0x4269fc(0x1f5)])==null?void 0x0:_0x330606['toString'](),'request':_0x5e3ee5[_0x4269fc(0x22f)],'response':_0x2de595(_0x56fbeb),'method':_0x5e3ee5['method']}),_0x56fbeb;},()=>_0x1b5a02[_0x588291(0x28a)][_0x588291(0x21f)][_0x4bda37]=_0x24faad):()=>{};};var _0x59b3de=_0x25799d,_0x1dcf54=_0x3f9bba;let _0x13b788=[_0x25799d(),_0x3f9bba(_0x429a6d(0x235)),_0x3f9bba(_0x429a6d(0x219)),_0x3f9bba(_0x429a6d(0x209),_0x38a734=>({'blob':{'size':_0x38a734['size'],'type':_0x38a734[_0x429a6d(0x272)]}})),_0x3f9bba(_0x429a6d(0x203),_0x576782=>({'arrayBuffer':{'byteLength':_0x576782[_0x429a6d(0x1b1)]}}))];return()=>_0x13b788['forEach'](_0xe1af13=>_0xe1af13());}return()=>{};}function te(_0x2ad0b5){const _0xbee381=_0x5647ca;try{let _0xa4df36=Error[_0xbee381(0x286)];Error[_0xbee381(0x286)]=_0x2ad0b5;let _0x13fb8a=new Error()[_0xbee381(0x248)];return Error[_0xbee381(0x286)]=_0xa4df36,_0x13fb8a;}catch{return'';}}function se(_0x2c223b,_0x545f37){return _0x545f37['replace'](/\\?t=\\d+/g,'');}var fe=[_0x5647ca(0x2a9),_0x5647ca(0x1ad),_0x5647ca(0x280)];function he(_0x5e5cc7){const _0x5810b9=_0x5647ca;return!!(typeof _0x5e5cc7==_0x5810b9(0x1b6)&&fe[_0x5810b9(0x1b5)](_0x5e6ab6=>_0x5e5cc7['indexOf'](_0x5e6ab6)!==-0x1));}function le(_0x4752de,_0x1b89cd,_0x8e0029,_0x482c41,_0x2a5338){return(_0x4b6f91,_0x4606f5)=>{const _0x5dad72=_0x1a3f;_0x4752de[_0x5dad72(0x258)]&&(_0x4752de['_ninjaIgnoreError']=_0x4b6f91);let _0x579703=String['fromCharCode'](0xa),_0x47616d=_0x4606f5[_0x5dad72(0x1c9)](_0x579703);_0x47616d['length']>0x2&&_0x47616d[_0x5dad72(0x1ea)](0x0,0x3),_0x4606f5=_0x4b6f91[_0x5dad72(0x248)][_0x5dad72(0x1c9)](_0x579703)[0x0]+_0x579703+_0x47616d[_0x5dad72(0x23c)](_0x579703),_0x1b89cd({'method':_0x5dad72(0x287),'version':_0x8e0029,'args':[{'ts':Date[_0x5dad72(0x1d2)](),'session':_0x482c41,'message':_0x4b6f91[_0x5dad72(0x26e)]||'','stack':_0x4606f5,'generatedStack':void 0x0,'stackTraceLimit':Error['stackTraceLimit'],'origin':_0x2a5338}]});};}function pe(_0x5add90,_0x55631d,_0x5321fd,_0x28c557,_0x393f5b,_0x2484ff,_0x16c1d6,_0x5ad03c){let _0x304a3f;return({stack:_0x284e95,url:_0x7d42c2,status:_0x23f27b,response:_0x1f8b63,method:_0x83748c,fetchStack:_0xee0ca1,request:_0xde0f72})=>{const _0x253692=_0x1a3f;if(he(_0x7d42c2))return;let _0x59d0d3=_0xee0ca1?_0x284e95+'\\x0a'+_0xee0ca1:_0x284e95;if(_0x393f5b[se(_0x55631d['tool'],_0x59d0d3)])return;let _0x279eea={'url':_0x7d42c2,'status':_0x23f27b,'method':_0x83748c,'request':_0xde0f72,'response':_0x1f8b63};_0x304a3f=_0x304a3f||K(_0x5add90,!0x1,{'hits':{},'ts':{}},_0x5321fd,_0x5ad03c);let _0x48b09c=_0x304a3f(_0x253692(0x1c5),'network',Date[_0x253692(0x1d2)](),_0x55631d,[_0x279eea]);_0x48b09c[_0x253692(0x1cd)][0x0][_0x253692(0x1cd)][0x0]['props']['push']({'name':_0x253692(0x248),'type':_0x253692(0x1b6),'value':_0x284e95}),_0x48b09c[_0x253692(0x1cd)][0x0][_0x253692(0x1cd)][0x0][_0x253692(0x1c8)][_0x253692(0x22d)]({'name':'fetchStack','type':_0x253692(0x1b6),'value':_0xee0ca1}),_0x2484ff&&(_0x48b09c['args'][0x0][_0x253692(0x234)]=_0x2484ff),_0x48b09c[_0x253692(0x1cd)][0x0][_0x253692(0x286)]=_0x16c1d6,_0x28c557(_0x48b09c);};}var _e=[_0x5647ca(0x1be),_0x5647ca(0x1b8),_0x5647ca(0x220),_0x5647ca(0x1d3),'FormData',_0x5647ca(0x1cc),_0x5647ca(0x2ae)];function ne(_0x2a4422,_0x4d281d){const _0x2efaa2=_0x5647ca;if(typeof _0x2a4422=='string'){try{if(_0x4d281d&&_0x4d281d[_0x2efaa2(0x271)]()===ee)return JSON[_0x2efaa2(0x29d)](_0x2a4422);}catch{}return _0x2a4422;}if(typeof _0x2a4422==_0x2efaa2(0x1e3)&&(_0x2a4422==null?void 0x0:_0x2a4422[_0x2efaa2(0x228)][_0x2efaa2(0x1d5)])){let _0x16cd72=_0x2a4422==null?void 0x0:_0x2a4422[_0x2efaa2(0x228)][_0x2efaa2(0x1d5)];return _0x16cd72&&_e['some'](_0x19a564=>_0x19a564===_0x16cd72)?'<'+_0x16cd72+'>':_0x2a4422;}return _0x2a4422;}function me(_0x426f6e){const _0x4507f0=_0x5647ca;return _0x426f6e?_0x426f6e===_0x4507f0(0x1cb)?0x32:_0x426f6e===_0x4507f0(0x1a0)?0x64:0x1e:0x1e;}function oe(_0x48c389){const _0x3da0e6=_0x5647ca;var _0x318fc2;return _0x48c389?(_0x318fc2=Object[_0x3da0e6(0x237)](_0x48c389)['find'](([_0x44dca7,_0x24c88f])=>(_0x44dca7==null?void 0x0:_0x44dca7['toLowerCase']())==='content-type'))==null?void 0x0:_0x318fc2[0x1]:void 0x0;}");
} catch (e) {
    console.error(e);
}
"trimStart" in String.prototype || (String.prototype.trimStart = String.prototype.trimLeft), "trimEnd" in String.prototype || (String.prototype.trimEnd = String.prototype.trimRight), "description" in Symbol.prototype || Object.defineProperty(Symbol.prototype, "description", {
    configurable: !0,
    get: function() {
        var t = /\((.*)\)/.exec(this.toString());
        return t ? t[1] : void 0;
    }
}), Array.prototype.flat || (Array.prototype.flat = function(t, r) {
    return r = this.concat.apply([], this), t > 1 && r.some(Array.isArray) ? r.flat(t - 1) : r;
}, Array.prototype.flatMap = function(t, r) {
    return this.map(t, r).flat();
}), Promise.prototype.finally || (Promise.prototype.finally = function(t) {
    if ("function" != typeof t) return this.then(t, t);
    var r = this.constructor || Promise;
    return this.then(function(n) {
        return r.resolve(t()).then(function() {
            return n;
        });
    }, function(n) {
        return r.resolve(t()).then(function() {
            throw n;
        });
    });
}), Object.fromEntries || (Object.fromEntries = function(t) {
    return Array.from(t).reduce(function(t, r) {
        return t[r[0]] = r[1], t;
    }, {});
}), Array.prototype.at || (Array.prototype.at = function(t) {
    var r = Math.trunc(t) || 0;
    if (r < 0 && (r += this.length), !(r < 0 || r >= this.length)) return this[r];
}), Object.hasOwn || (Object.hasOwn = function(t, r) {
    if (null == t) throw new TypeError("Cannot convert undefined or null to object");
    return Object.prototype.hasOwnProperty.call(Object(t), r);
}), "canParse" in URL || (URL.canParse = function(t, r) {
    try {
        return !!new URL(t, r);
    } catch (t) {
        return !1;
    }
});
}),
"[project]/frontend/node_modules/next/dist/shared/lib/invariant-error.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "InvariantError", {
    enumerable: true,
    get: function() {
        return InvariantError;
    }
});
class InvariantError extends Error {
    constructor(message, options){
        super(`Invariant: ${message.endsWith('.') ? message : message + '.'} This is a bug in Next.js.`, options);
        this.name = 'InvariantError';
    }
} //# sourceMappingURL=invariant-error.js.map
}),
"[project]/frontend/node_modules/next/dist/shared/lib/is-plain-object.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    getObjectClassLabel: null,
    isPlainObject: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    getObjectClassLabel: function() {
        return getObjectClassLabel;
    },
    isPlainObject: function() {
        return isPlainObject;
    }
});
function getObjectClassLabel(value) {
    return Object.prototype.toString.call(value);
}
function isPlainObject(value) {
    if (getObjectClassLabel(value) !== '[object Object]') {
        return false;
    }
    const prototype = Object.getPrototypeOf(value);
    /**
   * this used to be previously:
   *
   * `return prototype === null || prototype === Object.prototype`
   *
   * but Edge Runtime expose Object from vm, being that kind of type-checking wrongly fail.
   *
   * It was changed to the current implementation since it's resilient to serialization.
   */ return prototype === null || prototype.hasOwnProperty('isPrototypeOf');
} //# sourceMappingURL=is-plain-object.js.map
}),
"[project]/frontend/node_modules/next/dist/shared/lib/lazy-dynamic/bailout-to-csr.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// This has to be a shared module which is shared between client component error boundary and dynamic component
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    BailoutToCSRError: null,
    isBailoutToCSRError: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    BailoutToCSRError: function() {
        return BailoutToCSRError;
    },
    isBailoutToCSRError: function() {
        return isBailoutToCSRError;
    }
});
const BAILOUT_TO_CSR = 'BAILOUT_TO_CLIENT_SIDE_RENDERING';
class BailoutToCSRError extends Error {
    constructor(reason){
        super(`Bail out to client-side rendering: ${reason}`), this.reason = reason, this.digest = BAILOUT_TO_CSR;
    }
}
function isBailoutToCSRError(err) {
    if (typeof err !== 'object' || err === null || !('digest' in err)) {
        return false;
    }
    return err.digest === BAILOUT_TO_CSR;
} //# sourceMappingURL=bailout-to-csr.js.map
}),
"[project]/frontend/node_modules/next/dist/shared/lib/error-source.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    decorateServerError: null,
    getErrorSource: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    decorateServerError: function() {
        return decorateServerError;
    },
    getErrorSource: function() {
        return getErrorSource;
    }
});
const symbolError = Symbol.for('NextjsError');
function getErrorSource(error) {
    return error[symbolError] || null;
}
function decorateServerError(error, type) {
    Object.defineProperty(error, symbolError, {
        writable: false,
        enumerable: false,
        configurable: false,
        value: type
    });
} //# sourceMappingURL=error-source.js.map
}),
"[project]/frontend/node_modules/next/dist/shared/lib/head-manager-context.shared-runtime.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/frontend/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "HeadManagerContext", {
    enumerable: true,
    get: function() {
        return HeadManagerContext;
    }
});
const _interop_require_default = __turbopack_context__.r("[project]/frontend/node_modules/@swc/helpers/cjs/_interop_require_default.cjs [app-client] (ecmascript)");
const _react = /*#__PURE__*/ _interop_require_default._(__turbopack_context__.r("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
const HeadManagerContext = _react.default.createContext({});
if ("TURBOPACK compile-time truthy", 1) {
    HeadManagerContext.displayName = 'HeadManagerContext';
} //# sourceMappingURL=head-manager-context.shared-runtime.js.map
}),
"[project]/frontend/node_modules/next/dist/shared/lib/hooks-client-context.shared-runtime.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/frontend/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use client';
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    NavigationPromisesContext: null,
    PathParamsContext: null,
    PathnameContext: null,
    ReadonlyURLSearchParams: null,
    SearchParamsContext: null,
    createDevToolsInstrumentedPromise: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    NavigationPromisesContext: function() {
        return NavigationPromisesContext;
    },
    PathParamsContext: function() {
        return PathParamsContext;
    },
    PathnameContext: function() {
        return PathnameContext;
    },
    ReadonlyURLSearchParams: function() {
        return _readonlyurlsearchparams.ReadonlyURLSearchParams;
    },
    SearchParamsContext: function() {
        return SearchParamsContext;
    },
    createDevToolsInstrumentedPromise: function() {
        return createDevToolsInstrumentedPromise;
    }
});
const _react = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
const _readonlyurlsearchparams = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/client/components/readonly-url-search-params.js [app-client] (ecmascript)");
const SearchParamsContext = (0, _react.createContext)(null);
const PathnameContext = (0, _react.createContext)(null);
const PathParamsContext = (0, _react.createContext)(null);
const NavigationPromisesContext = (0, _react.createContext)(null);
function createDevToolsInstrumentedPromise(displayName, value) {
    const promise = Promise.resolve(value);
    promise.status = 'fulfilled';
    promise.value = value;
    promise.displayName = `${displayName} (SSR)`;
    return promise;
}
if ("TURBOPACK compile-time truthy", 1) {
    SearchParamsContext.displayName = 'SearchParamsContext';
    PathnameContext.displayName = 'PathnameContext';
    PathParamsContext.displayName = 'PathParamsContext';
    NavigationPromisesContext.displayName = 'NavigationPromisesContext';
} //# sourceMappingURL=hooks-client-context.shared-runtime.js.map
}),
"[project]/frontend/node_modules/next/dist/shared/lib/router/utils/html-bots.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// This regex contains the bots that we need to do a blocking render for and can't safely stream the response
// due to how they parse the DOM. For example, they might explicitly check for metadata in the `head` tag, so we can't stream metadata tags after the `head` was sent.
// Note: The pattern [\w-]+-Google captures all Google crawlers with "-Google" suffix (e.g., Mediapartners-Google, AdsBot-Google, Storebot-Google)
// as well as crawlers starting with "Google-" (e.g., Google-PageRenderer, Google-InspectionTool)
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "HTML_LIMITED_BOT_UA_RE", {
    enumerable: true,
    get: function() {
        return HTML_LIMITED_BOT_UA_RE;
    }
});
const HTML_LIMITED_BOT_UA_RE = /[\w-]+-Google|Google-[\w-]+|Chrome-Lighthouse|Slurp|DuckDuckBot|baiduspider|yandex|sogou|bitlybot|tumblr|vkShare|quora link preview|redditbot|ia_archiver|Bingbot|BingPreview|applebot|facebookexternalhit|facebookcatalog|Twitterbot|LinkedInBot|Slackbot|Discordbot|WhatsApp|SkypeUriPreview|Yeti|googleweblight/i; //# sourceMappingURL=html-bots.js.map
}),
"[project]/frontend/node_modules/next/dist/shared/lib/router/utils/is-bot.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    HTML_LIMITED_BOT_UA_RE: null,
    HTML_LIMITED_BOT_UA_RE_STRING: null,
    getBotType: null,
    isBot: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    HTML_LIMITED_BOT_UA_RE: function() {
        return _htmlbots.HTML_LIMITED_BOT_UA_RE;
    },
    HTML_LIMITED_BOT_UA_RE_STRING: function() {
        return HTML_LIMITED_BOT_UA_RE_STRING;
    },
    getBotType: function() {
        return getBotType;
    },
    isBot: function() {
        return isBot;
    }
});
const _htmlbots = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/shared/lib/router/utils/html-bots.js [app-client] (ecmascript)");
// Bot crawler that will spin up a headless browser and execute JS.
// Only the main Googlebot search crawler executes JavaScript, not other Google crawlers.
// x-ref: https://developers.google.com/search/docs/crawling-indexing/google-common-crawlers
// This regex specifically matches "Googlebot" but NOT "Mediapartners-Google", "AdsBot-Google", etc.
const HEADLESS_BROWSER_BOT_UA_RE = /Googlebot(?!-)|Googlebot$/i;
const HTML_LIMITED_BOT_UA_RE_STRING = _htmlbots.HTML_LIMITED_BOT_UA_RE.source;
function isDomBotUA(userAgent) {
    return HEADLESS_BROWSER_BOT_UA_RE.test(userAgent);
}
function isHtmlLimitedBotUA(userAgent) {
    return _htmlbots.HTML_LIMITED_BOT_UA_RE.test(userAgent);
}
function isBot(userAgent) {
    return isDomBotUA(userAgent) || isHtmlLimitedBotUA(userAgent);
}
function getBotType(userAgent) {
    if (isDomBotUA(userAgent)) {
        return 'dom';
    }
    if (isHtmlLimitedBotUA(userAgent)) {
        return 'html';
    }
    return undefined;
} //# sourceMappingURL=is-bot.js.map
}),
"[project]/frontend/node_modules/next/dist/shared/lib/is-thenable.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * Check to see if a value is Thenable.
 *
 * @param promise the maybe-thenable value
 * @returns true if the value is thenable
 */ Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "isThenable", {
    enumerable: true,
    get: function() {
        return isThenable;
    }
});
function isThenable(promise) {
    return promise !== null && typeof promise === 'object' && 'then' in promise && typeof promise.then === 'function';
} //# sourceMappingURL=is-thenable.js.map
}),
"[project]/frontend/node_modules/next/dist/shared/lib/page-path/ensure-leading-slash.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * For a given page path, this function ensures that there is a leading slash.
 * If there is not a leading slash, one is added, otherwise it is noop.
 */ Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "ensureLeadingSlash", {
    enumerable: true,
    get: function() {
        return ensureLeadingSlash;
    }
});
function ensureLeadingSlash(path) {
    return path.startsWith('/') ? path : `/${path}`;
} //# sourceMappingURL=ensure-leading-slash.js.map
}),
"[project]/frontend/node_modules/next/dist/shared/lib/segment.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    DEFAULT_SEGMENT_KEY: null,
    NOT_FOUND_SEGMENT_KEY: null,
    PAGE_SEGMENT_KEY: null,
    addSearchParamsIfPageSegment: null,
    computeSelectedLayoutSegment: null,
    getSegmentValue: null,
    getSelectedLayoutSegmentPath: null,
    isGroupSegment: null,
    isParallelRouteSegment: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    DEFAULT_SEGMENT_KEY: function() {
        return DEFAULT_SEGMENT_KEY;
    },
    NOT_FOUND_SEGMENT_KEY: function() {
        return NOT_FOUND_SEGMENT_KEY;
    },
    PAGE_SEGMENT_KEY: function() {
        return PAGE_SEGMENT_KEY;
    },
    addSearchParamsIfPageSegment: function() {
        return addSearchParamsIfPageSegment;
    },
    computeSelectedLayoutSegment: function() {
        return computeSelectedLayoutSegment;
    },
    getSegmentValue: function() {
        return getSegmentValue;
    },
    getSelectedLayoutSegmentPath: function() {
        return getSelectedLayoutSegmentPath;
    },
    isGroupSegment: function() {
        return isGroupSegment;
    },
    isParallelRouteSegment: function() {
        return isParallelRouteSegment;
    }
});
function getSegmentValue(segment) {
    return Array.isArray(segment) ? segment[1] : segment;
}
function isGroupSegment(segment) {
    // Use array[0] for performant purpose
    return segment[0] === '(' && segment.endsWith(')');
}
function isParallelRouteSegment(segment) {
    return segment.startsWith('@') && segment !== '@children';
}
function addSearchParamsIfPageSegment(segment, searchParams) {
    const isPageSegment = segment.includes(PAGE_SEGMENT_KEY);
    if (isPageSegment) {
        const stringifiedQuery = JSON.stringify(searchParams);
        return stringifiedQuery !== '{}' ? PAGE_SEGMENT_KEY + '?' + stringifiedQuery : PAGE_SEGMENT_KEY;
    }
    return segment;
}
function computeSelectedLayoutSegment(segments, parallelRouteKey) {
    if (!segments || segments.length === 0) {
        return null;
    }
    // For 'children', use first segment; for other parallel routes, use last segment
    const rawSegment = parallelRouteKey === 'children' ? segments[0] : segments[segments.length - 1];
    // If the default slot is showing, return null since it's not technically "selected" (it's a fallback)
    // Returning an internal value like `__DEFAULT__` would be confusing
    return rawSegment === DEFAULT_SEGMENT_KEY ? null : rawSegment;
}
function getSelectedLayoutSegmentPath(tree, parallelRouteKey, first = true, segmentPath = []) {
    let node;
    if (first) {
        // Use the provided parallel route key on the first parallel route
        node = tree[1][parallelRouteKey];
    } else {
        // After first parallel route prefer children, if there's no children pick the first parallel route.
        const parallelRoutes = tree[1];
        node = parallelRoutes.children ?? Object.values(parallelRoutes)[0];
    }
    if (!node) return segmentPath;
    const segment = node[0];
    let segmentValue = getSegmentValue(segment);
    if (!segmentValue || segmentValue.startsWith(PAGE_SEGMENT_KEY)) {
        return segmentPath;
    }
    segmentPath.push(segmentValue);
    return getSelectedLayoutSegmentPath(node, parallelRouteKey, false, segmentPath);
}
const PAGE_SEGMENT_KEY = '__PAGE__';
const DEFAULT_SEGMENT_KEY = '__DEFAULT__';
const NOT_FOUND_SEGMENT_KEY = '/_not-found'; //# sourceMappingURL=segment.js.map
}),
"[project]/frontend/node_modules/next/dist/shared/lib/router/utils/app-paths.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    normalizeAppPath: null,
    normalizeRscURL: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    normalizeAppPath: function() {
        return normalizeAppPath;
    },
    normalizeRscURL: function() {
        return normalizeRscURL;
    }
});
const _ensureleadingslash = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/shared/lib/page-path/ensure-leading-slash.js [app-client] (ecmascript)");
const _segment = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/shared/lib/segment.js [app-client] (ecmascript)");
function normalizeAppPath(route) {
    return (0, _ensureleadingslash.ensureLeadingSlash)(route.split('/').reduce((pathname, segment, index, segments)=>{
        // Empty segments are ignored.
        if (!segment) {
            return pathname;
        }
        // Groups are ignored.
        if ((0, _segment.isGroupSegment)(segment)) {
            return pathname;
        }
        // Parallel segments are ignored.
        if (segment[0] === '@') {
            return pathname;
        }
        // The last segment (if it's a leaf) should be ignored.
        if ((segment === 'page' || segment === 'route') && index === segments.length - 1) {
            return pathname;
        }
        return `${pathname}/${segment}`;
    }, ''));
}
function normalizeRscURL(url) {
    return url.replace(/\.rsc($|\?)/, '$1');
} //# sourceMappingURL=app-paths.js.map
}),
"[project]/frontend/node_modules/next/dist/shared/lib/router/utils/interception-routes.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    INTERCEPTION_ROUTE_MARKERS: null,
    extractInterceptionRouteInformation: null,
    isInterceptionRouteAppPath: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    INTERCEPTION_ROUTE_MARKERS: function() {
        return INTERCEPTION_ROUTE_MARKERS;
    },
    extractInterceptionRouteInformation: function() {
        return extractInterceptionRouteInformation;
    },
    isInterceptionRouteAppPath: function() {
        return isInterceptionRouteAppPath;
    }
});
const _apppaths = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/shared/lib/router/utils/app-paths.js [app-client] (ecmascript)");
const INTERCEPTION_ROUTE_MARKERS = [
    '(..)(..)',
    '(.)',
    '(..)',
    '(...)'
];
function isInterceptionRouteAppPath(path) {
    // TODO-APP: add more serious validation
    return path.split('/').find((segment)=>INTERCEPTION_ROUTE_MARKERS.find((m)=>segment.startsWith(m))) !== undefined;
}
function extractInterceptionRouteInformation(path) {
    let interceptingRoute;
    let marker;
    let interceptedRoute;
    for (const segment of path.split('/')){
        marker = INTERCEPTION_ROUTE_MARKERS.find((m)=>segment.startsWith(m));
        if (marker) {
            ;
            [interceptingRoute, interceptedRoute] = path.split(marker, 2);
            break;
        }
    }
    if (!interceptingRoute || !marker || !interceptedRoute) {
        throw Object.defineProperty(new Error(`Invalid interception route: ${path}. Must be in the format /<intercepting route>/(..|...|..)(..)/<intercepted route>`), "__NEXT_ERROR_CODE", {
            value: "E269",
            enumerable: false,
            configurable: true
        });
    }
    interceptingRoute = (0, _apppaths.normalizeAppPath)(interceptingRoute) // normalize the path, e.g. /(blog)/feed -> /feed
    ;
    switch(marker){
        case '(.)':
            // (.) indicates that we should match with sibling routes, so we just need to append the intercepted route to the intercepting route
            if (interceptingRoute === '/') {
                interceptedRoute = `/${interceptedRoute}`;
            } else {
                interceptedRoute = interceptingRoute + '/' + interceptedRoute;
            }
            break;
        case '(..)':
            // (..) indicates that we should match at one level up, so we need to remove the last segment of the intercepting route
            if (interceptingRoute === '/') {
                throw Object.defineProperty(new Error(`Invalid interception route: ${path}. Cannot use (..) marker at the root level, use (.) instead.`), "__NEXT_ERROR_CODE", {
                    value: "E207",
                    enumerable: false,
                    configurable: true
                });
            }
            interceptedRoute = interceptingRoute.split('/').slice(0, -1).concat(interceptedRoute).join('/');
            break;
        case '(...)':
            // (...) will match the route segment in the root directory, so we need to use the root directory to prepend the intercepted route
            interceptedRoute = '/' + interceptedRoute;
            break;
        case '(..)(..)':
            // (..)(..) indicates that we should match at two levels up, so we need to remove the last two segments of the intercepting route
            const splitInterceptingRoute = interceptingRoute.split('/');
            if (splitInterceptingRoute.length <= 2) {
                throw Object.defineProperty(new Error(`Invalid interception route: ${path}. Cannot use (..)(..) marker at the root level or one level up.`), "__NEXT_ERROR_CODE", {
                    value: "E486",
                    enumerable: false,
                    configurable: true
                });
            }
            interceptedRoute = splitInterceptingRoute.slice(0, -2).concat(interceptedRoute).join('/');
            break;
        default:
            throw Object.defineProperty(new Error('Invariant: unexpected marker'), "__NEXT_ERROR_CODE", {
                value: "E112",
                enumerable: false,
                configurable: true
            });
    }
    return {
        interceptingRoute,
        interceptedRoute
    };
} //# sourceMappingURL=interception-routes.js.map
}),
"[project]/frontend/node_modules/next/dist/shared/lib/segment-cache/segment-value-encoding.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    HEAD_REQUEST_KEY: null,
    ROOT_SEGMENT_REQUEST_KEY: null,
    appendSegmentRequestKeyPart: null,
    convertSegmentPathToStaticExportFilename: null,
    createSegmentRequestKeyPart: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    HEAD_REQUEST_KEY: function() {
        return HEAD_REQUEST_KEY;
    },
    ROOT_SEGMENT_REQUEST_KEY: function() {
        return ROOT_SEGMENT_REQUEST_KEY;
    },
    appendSegmentRequestKeyPart: function() {
        return appendSegmentRequestKeyPart;
    },
    convertSegmentPathToStaticExportFilename: function() {
        return convertSegmentPathToStaticExportFilename;
    },
    createSegmentRequestKeyPart: function() {
        return createSegmentRequestKeyPart;
    }
});
const _segment = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/shared/lib/segment.js [app-client] (ecmascript)");
const ROOT_SEGMENT_REQUEST_KEY = '';
const HEAD_REQUEST_KEY = '/_head';
function createSegmentRequestKeyPart(segment) {
    if (typeof segment === 'string') {
        if (segment.startsWith(_segment.PAGE_SEGMENT_KEY)) {
            // The Flight Router State type sometimes includes the search params in
            // the page segment. However, the Segment Cache tracks this as a separate
            // key. So, we strip the search params here, and then add them back when
            // the cache entry is turned back into a FlightRouterState. This is an
            // unfortunate consequence of the FlightRouteState being used both as a
            // transport type and as a cache key; we'll address this once more of the
            // Segment Cache implementation has settled.
            // TODO: We should hoist the search params out of the FlightRouterState
            // type entirely, This is our plan for dynamic route params, too.
            return _segment.PAGE_SEGMENT_KEY;
        }
        const safeName = // But params typically don't include the leading slash. We should use
        // a different encoding to avoid this special case.
        segment === '/_not-found' ? '_not-found' : encodeToFilesystemAndURLSafeString(segment);
        // Since this is not a dynamic segment, it's fully encoded. It does not
        // need to be "hydrated" with a param value.
        return safeName;
    }
    const name = segment[0];
    const paramType = segment[2];
    const safeName = encodeToFilesystemAndURLSafeString(name);
    const encodedName = '$' + paramType + '$' + safeName;
    return encodedName;
}
function appendSegmentRequestKeyPart(parentRequestKey, parallelRouteKey, childRequestKeyPart) {
    // Aside from being filesystem safe, segment keys are also designed so that
    // each segment and parallel route creates its own subdirectory. Roughly in
    // the same shape as the source app directory. This is mostly just for easier
    // debugging (you can open up the build folder and navigate the output); if
    // we wanted to do we could just use a flat structure.
    // Omit the parallel route key for children, since this is the most
    // common case. Saves some bytes (and it's what the app directory does).
    const slotKey = parallelRouteKey === 'children' ? childRequestKeyPart : `@${encodeToFilesystemAndURLSafeString(parallelRouteKey)}/${childRequestKeyPart}`;
    return parentRequestKey + '/' + slotKey;
}
// Define a regex pattern to match the most common characters found in a route
// param. It excludes anything that might not be cross-platform filesystem
// compatible, like |. It does not need to be precise because the fallback is to
// just base64url-encode the whole parameter, which is fine; we just don't do it
// by default for compactness, and for easier debugging.
const simpleParamValueRegex = /^[a-zA-Z0-9\-_@]+$/;
function encodeToFilesystemAndURLSafeString(value) {
    if (simpleParamValueRegex.test(value)) {
        return value;
    }
    // If there are any unsafe characters, base64url-encode the entire value.
    // We also add a ! prefix so it doesn't collide with the simple case.
    const base64url = btoa(value).replace(/\+/g, '-') // Replace '+' with '-'
    .replace(/\//g, '_') // Replace '/' with '_'
    .replace(/=+$/, '') // Remove trailing '='
    ;
    return '!' + base64url;
}
function convertSegmentPathToStaticExportFilename(segmentPath) {
    return `__next${segmentPath.replace(/\//g, '.')}.txt`;
} //# sourceMappingURL=segment-value-encoding.js.map
}),
"[project]/frontend/node_modules/next/dist/shared/lib/hash.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// http://www.cse.yorku.ca/~oz/hash.html
// More specifically, 32-bit hash via djbxor
// (ref: https://gist.github.com/eplawless/52813b1d8ad9af510d85?permalink_comment_id=3367765#gistcomment-3367765)
// This is due to number type differences between rust for turbopack to js number types,
// where rust does not have easy way to repreesnt js's 53-bit float number type for the matching
// overflow behavior. This is more `correct` in terms of having canonical hash across different runtime / implementation
// as can gaurantee determinstic output from 32bit hash.
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    djb2Hash: null,
    hexHash: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    djb2Hash: function() {
        return djb2Hash;
    },
    hexHash: function() {
        return hexHash;
    }
});
function djb2Hash(str) {
    let hash = 5381;
    for(let i = 0; i < str.length; i++){
        const char = str.charCodeAt(i);
        hash = (hash << 5) + hash + char & 0xffffffff;
    }
    return hash >>> 0;
}
function hexHash(str) {
    return djb2Hash(str).toString(36).slice(0, 5);
} //# sourceMappingURL=hash.js.map
}),
"[project]/frontend/node_modules/next/dist/shared/lib/router/utils/cache-busting-search-param.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "computeCacheBustingSearchParam", {
    enumerable: true,
    get: function() {
        return computeCacheBustingSearchParam;
    }
});
const _hash = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/shared/lib/hash.js [app-client] (ecmascript)");
function computeCacheBustingSearchParam(prefetchHeader, segmentPrefetchHeader, stateTreeHeader, nextUrlHeader) {
    if ((prefetchHeader === undefined || prefetchHeader === '0') && segmentPrefetchHeader === undefined && stateTreeHeader === undefined && nextUrlHeader === undefined) {
        return '';
    }
    return (0, _hash.hexHash)([
        prefetchHeader || '0',
        segmentPrefetchHeader || '0',
        stateTreeHeader || '0',
        nextUrlHeader || '0'
    ].join(','));
} //# sourceMappingURL=cache-busting-search-param.js.map
}),
"[project]/frontend/node_modules/next/dist/shared/lib/deployment-id.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/frontend/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
// This could also be a variable instead of a function, but some unit tests want to change the ID at
// runtime. Even though that would never happen in a real deployment.
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    getDeploymentId: null,
    getDeploymentIdQueryOrEmptyString: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    getDeploymentId: function() {
        return getDeploymentId;
    },
    getDeploymentIdQueryOrEmptyString: function() {
        return getDeploymentIdQueryOrEmptyString;
    }
});
function getDeploymentId() {
    return "TURBOPACK compile-time value", false;
}
function getDeploymentIdQueryOrEmptyString() {
    let deploymentId = getDeploymentId();
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    return '';
} //# sourceMappingURL=deployment-id.js.map
}),
"[project]/frontend/node_modules/next/dist/shared/lib/app-router-types.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * App Router types - Client-safe types for the Next.js App Router
 *
 * This file contains type definitions that can be safely imported
 * by both client-side and server-side code without circular dependencies.
 */ Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "HasLoadingBoundary", {
    enumerable: true,
    get: function() {
        return HasLoadingBoundary;
    }
});
var HasLoadingBoundary = /*#__PURE__*/ function(HasLoadingBoundary) {
    // There is a loading boundary in this particular segment
    HasLoadingBoundary[HasLoadingBoundary["SegmentHasLoadingBoundary"] = 1] = "SegmentHasLoadingBoundary";
    // There is a loading boundary somewhere in the subtree (but not in
    // this segment)
    HasLoadingBoundary[HasLoadingBoundary["SubtreeHasLoadingBoundary"] = 2] = "SubtreeHasLoadingBoundary";
    // There is no loading boundary in this segment or any of its descendants
    HasLoadingBoundary[HasLoadingBoundary["SubtreeHasNoLoadingBoundary"] = 3] = "SubtreeHasNoLoadingBoundary";
    return HasLoadingBoundary;
}({}); //# sourceMappingURL=app-router-types.js.map
}),
"[project]/frontend/node_modules/next/dist/shared/lib/router/utils/parse-path.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * Given a path this function will find the pathname, query and hash and return
 * them. This is useful to parse full paths on the client side.
 * @param path A path to parse e.g. /foo/bar?id=1#hash
 */ Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "parsePath", {
    enumerable: true,
    get: function() {
        return parsePath;
    }
});
function parsePath(path) {
    const hashIndex = path.indexOf('#');
    const queryIndex = path.indexOf('?');
    const hasQuery = queryIndex > -1 && (hashIndex < 0 || queryIndex < hashIndex);
    if (hasQuery || hashIndex > -1) {
        return {
            pathname: path.substring(0, hasQuery ? queryIndex : hashIndex),
            query: hasQuery ? path.substring(queryIndex, hashIndex > -1 ? hashIndex : undefined) : '',
            hash: hashIndex > -1 ? path.slice(hashIndex) : ''
        };
    }
    return {
        pathname: path,
        query: '',
        hash: ''
    };
} //# sourceMappingURL=parse-path.js.map
}),
"[project]/frontend/node_modules/next/dist/shared/lib/router/utils/add-path-prefix.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "addPathPrefix", {
    enumerable: true,
    get: function() {
        return addPathPrefix;
    }
});
const _parsepath = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/shared/lib/router/utils/parse-path.js [app-client] (ecmascript)");
function addPathPrefix(path, prefix) {
    if (!path.startsWith('/') || !prefix) {
        return path;
    }
    const { pathname, query, hash } = (0, _parsepath.parsePath)(path);
    return `${prefix}${pathname}${query}${hash}`;
} //# sourceMappingURL=add-path-prefix.js.map
}),
"[project]/frontend/node_modules/next/dist/shared/lib/router/utils/remove-trailing-slash.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

/**
 * Removes the trailing slash for a given route or page path. Preserves the
 * root page. Examples:
 *   - `/foo/bar/` -> `/foo/bar`
 *   - `/foo/bar` -> `/foo/bar`
 *   - `/` -> `/`
 */ Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "removeTrailingSlash", {
    enumerable: true,
    get: function() {
        return removeTrailingSlash;
    }
});
function removeTrailingSlash(route) {
    return route.replace(/\/$/, '') || '/';
} //# sourceMappingURL=remove-trailing-slash.js.map
}),
"[project]/frontend/node_modules/next/dist/shared/lib/promise-with-resolvers.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "createPromiseWithResolvers", {
    enumerable: true,
    get: function() {
        return createPromiseWithResolvers;
    }
});
function createPromiseWithResolvers() {
    // Shim of Stage 4 Promise.withResolvers proposal
    let resolve;
    let reject;
    const promise = new Promise((res, rej)=>{
        resolve = res;
        reject = rej;
    });
    return {
        resolve: resolve,
        reject: reject,
        promise
    };
} //# sourceMappingURL=promise-with-resolvers.js.map
}),
"[project]/frontend/node_modules/next/dist/shared/lib/router/utils/path-has-prefix.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "pathHasPrefix", {
    enumerable: true,
    get: function() {
        return pathHasPrefix;
    }
});
const _parsepath = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/shared/lib/router/utils/parse-path.js [app-client] (ecmascript)");
function pathHasPrefix(path, prefix) {
    if (typeof path !== 'string') {
        return false;
    }
    const { pathname } = (0, _parsepath.parsePath)(path);
    return pathname === prefix || pathname.startsWith(prefix + '/');
} //# sourceMappingURL=path-has-prefix.js.map
}),
"[project]/frontend/node_modules/next/dist/shared/lib/server-reference-info.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    extractInfoFromServerReferenceId: null,
    omitUnusedArgs: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    extractInfoFromServerReferenceId: function() {
        return extractInfoFromServerReferenceId;
    },
    omitUnusedArgs: function() {
        return omitUnusedArgs;
    }
});
function extractInfoFromServerReferenceId(id) {
    const infoByte = parseInt(id.slice(0, 2), 16);
    const typeBit = infoByte >> 7 & 0x1;
    const argMask = infoByte >> 1 & 0x3f;
    const restArgs = infoByte & 0x1;
    const usedArgs = Array(6);
    for(let index = 0; index < 6; index++){
        const bitPosition = 5 - index;
        const bit = argMask >> bitPosition & 0x1;
        usedArgs[index] = bit === 1;
    }
    return {
        type: typeBit === 1 ? 'use-cache' : 'server-action',
        usedArgs: usedArgs,
        hasRestArgs: restArgs === 1
    };
}
function omitUnusedArgs(args, info) {
    const filteredArgs = new Array(args.length);
    for(let index = 0; index < args.length; index++){
        if (index < 6 && info.usedArgs[index] || // This assumes that the server reference info byte has the restArgs bit
        // set to 1 if there are more than 6 args.
        index >= 6 && info.hasRestArgs) {
            filteredArgs[index] = args[index];
        }
    }
    return filteredArgs;
} //# sourceMappingURL=server-reference-info.js.map
}),
"[project]/frontend/node_modules/next/dist/shared/lib/action-revalidation-kind.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    ActionDidNotRevalidate: null,
    ActionDidRevalidateDynamicOnly: null,
    ActionDidRevalidateStaticAndDynamic: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    ActionDidNotRevalidate: function() {
        return ActionDidNotRevalidate;
    },
    ActionDidRevalidateDynamicOnly: function() {
        return ActionDidRevalidateDynamicOnly;
    },
    ActionDidRevalidateStaticAndDynamic: function() {
        return ActionDidRevalidateStaticAndDynamic;
    }
});
const ActionDidNotRevalidate = 0;
const ActionDidRevalidateStaticAndDynamic = 1;
const ActionDidRevalidateDynamicOnly = 2; //# sourceMappingURL=action-revalidation-kind.js.map
}),
"[project]/frontend/node_modules/next/dist/shared/lib/app-router-context.shared-runtime.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/frontend/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use client';
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    AppRouterContext: null,
    GlobalLayoutRouterContext: null,
    LayoutRouterContext: null,
    MissingSlotContext: null,
    TemplateContext: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    AppRouterContext: function() {
        return AppRouterContext;
    },
    GlobalLayoutRouterContext: function() {
        return GlobalLayoutRouterContext;
    },
    LayoutRouterContext: function() {
        return LayoutRouterContext;
    },
    MissingSlotContext: function() {
        return MissingSlotContext;
    },
    TemplateContext: function() {
        return TemplateContext;
    }
});
const _interop_require_default = __turbopack_context__.r("[project]/frontend/node_modules/@swc/helpers/cjs/_interop_require_default.cjs [app-client] (ecmascript)");
const _react = /*#__PURE__*/ _interop_require_default._(__turbopack_context__.r("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
const AppRouterContext = _react.default.createContext(null);
const LayoutRouterContext = _react.default.createContext(null);
const GlobalLayoutRouterContext = _react.default.createContext(null);
const TemplateContext = _react.default.createContext(null);
if ("TURBOPACK compile-time truthy", 1) {
    AppRouterContext.displayName = 'AppRouterContext';
    LayoutRouterContext.displayName = 'LayoutRouterContext';
    GlobalLayoutRouterContext.displayName = 'GlobalLayoutRouterContext';
    TemplateContext.displayName = 'TemplateContext';
}
const MissingSlotContext = _react.default.createContext(new Set()); //# sourceMappingURL=app-router-context.shared-runtime.js.map
}),
"[project]/frontend/node_modules/next/dist/shared/lib/server-inserted-html.shared-runtime.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    ServerInsertedHTMLContext: null,
    useServerInsertedHTML: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    ServerInsertedHTMLContext: function() {
        return ServerInsertedHTMLContext;
    },
    useServerInsertedHTML: function() {
        return useServerInsertedHTML;
    }
});
const _interop_require_wildcard = __turbopack_context__.r("[project]/frontend/node_modules/@swc/helpers/cjs/_interop_require_wildcard.cjs [app-client] (ecmascript)");
const _react = /*#__PURE__*/ _interop_require_wildcard._(__turbopack_context__.r("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
const ServerInsertedHTMLContext = /*#__PURE__*/ _react.default.createContext(null);
function useServerInsertedHTML(callback) {
    const addInsertedServerHTMLCallback = (0, _react.useContext)(ServerInsertedHTMLContext);
    // Should have no effects on client where there's no flush effects provider
    if (addInsertedServerHTMLCallback) {
        addInsertedServerHTMLCallback(callback);
    }
} //# sourceMappingURL=server-inserted-html.shared-runtime.js.map
}),
"[project]/frontend/node_modules/next/dist/shared/lib/utils/warn-once.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/frontend/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "warnOnce", {
    enumerable: true,
    get: function() {
        return warnOnce;
    }
});
let warnOnce = (_)=>{};
if ("TURBOPACK compile-time truthy", 1) {
    const warnings = new Set();
    warnOnce = (msg)=>{
        if (!warnings.has(msg)) {
            console.warn(msg);
        }
        warnings.add(msg);
    };
} //# sourceMappingURL=warn-once.js.map
}),
"[project]/frontend/node_modules/next/dist/shared/lib/format-webpack-messages.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/frontend/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
/**
MIT License

Copyright (c) 2015-present, Facebook, Inc.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/ "use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return formatWebpackMessages;
    }
});
const _interop_require_default = __turbopack_context__.r("[project]/frontend/node_modules/@swc/helpers/cjs/_interop_require_default.cjs [app-client] (ecmascript)");
const _stripansi = /*#__PURE__*/ _interop_require_default._(__turbopack_context__.r("[project]/frontend/node_modules/next/dist/compiled/strip-ansi/index.js [app-client] (ecmascript)"));
// This file is based on https://github.com/facebook/create-react-app/blob/7b1a32be6ec9f99a6c9a3c66813f3ac09c4736b9/packages/react-dev-utils/formatWebpackMessages.js
// It's been edited to remove chalk and CRA-specific logic
const friendlySyntaxErrorLabel = 'Syntax error:';
const WEBPACK_BREAKING_CHANGE_POLYFILLS = '\n\nBREAKING CHANGE: webpack < 5 used to include polyfills for node.js core modules by default.';
function isLikelyASyntaxError(message) {
    return (0, _stripansi.default)(message).includes(friendlySyntaxErrorLabel);
}
let hadMissingSassError = false;
// Cleans up webpack error messages.
function formatMessage(message, verbose, importTraceNote) {
    // TODO: Replace this once webpack 5 is stable
    if (typeof message === 'object' && message.message) {
        const filteredModuleTrace = message.moduleTrace && message.moduleTrace.filter((trace)=>!/next-(middleware|client-pages|route|edge-function)-loader\.js/.test(trace.originName));
        let body = message.message;
        const breakingChangeIndex = body.indexOf(WEBPACK_BREAKING_CHANGE_POLYFILLS);
        if (breakingChangeIndex >= 0) {
            body = body.slice(0, breakingChangeIndex);
        }
        // TODO: Rspack currently doesn't populate moduleName correctly in some cases,
        // fall back to moduleIdentifier as a workaround
        if (__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_RSPACK && !message.moduleName && !message.file && message.moduleIdentifier) {
            const parts = message.moduleIdentifier.split('!');
            message.moduleName = parts[parts.length - 1];
        }
        message = (message.moduleName ? (0, _stripansi.default)(message.moduleName) + '\n' : '') + (message.file ? (0, _stripansi.default)(message.file) + '\n' : '') + body + (message.details && verbose ? '\n' + message.details : '') + (filteredModuleTrace && filteredModuleTrace.length ? (importTraceNote || '\n\nImport trace for requested module:') + filteredModuleTrace.map((trace)=>`\n${trace.moduleName}`).join('') : '') + (message.stack && verbose ? '\n' + message.stack : '');
    }
    let lines = message.split('\n');
    // Strip Webpack-added headers off errors/warnings
    // https://github.com/webpack/webpack/blob/master/lib/ModuleError.js
    lines = lines.filter((line)=>!/Module [A-z ]+\(from/.test(line));
    // Transform parsing error into syntax error
    // TODO: move this to our ESLint formatter?
    lines = lines.map((line)=>{
        const parsingError = /Line (\d+):(?:(\d+):)?\s*Parsing error: (.+)$/.exec(line);
        if (!parsingError) {
            return line;
        }
        const [, errorLine, errorColumn, errorMessage] = parsingError;
        return `${friendlySyntaxErrorLabel} ${errorMessage} (${errorLine}:${errorColumn})`;
    });
    message = lines.join('\n');
    // Smoosh syntax errors (commonly found in CSS)
    message = message.replace(/SyntaxError\s+\((\d+):(\d+)\)\s*(.+?)\n/g, `${friendlySyntaxErrorLabel} $3 ($1:$2)\n`);
    // Clean up export errors
    message = message.replace(/^.*export '(.+?)' was not found in '(.+?)'.*$/gm, `Attempted import error: '$1' is not exported from '$2'.`);
    message = message.replace(/^.*export 'default' \(imported as '(.+?)'\) was not found in '(.+?)'.*$/gm, `Attempted import error: '$2' does not contain a default export (imported as '$1').`);
    message = message.replace(/^.*export '(.+?)' \(imported as '(.+?)'\) was not found in '(.+?)'.*$/gm, `Attempted import error: '$1' is not exported from '$3' (imported as '$2').`);
    lines = message.split('\n');
    // Remove leading newline
    if (lines.length > 2 && lines[1].trim() === '') {
        lines.splice(1, 1);
    }
    // Cleans up verbose "module not found" messages for files and packages.
    if (lines[1] && lines[1].startsWith('Module not found: ')) {
        lines = [
            lines[0],
            lines[1].replace('Error: ', '').replace('Module not found: Cannot find file:', 'Cannot find file:'),
            ...lines.slice(2)
        ];
    }
    // Add helpful message for users trying to use Sass for the first time
    if (lines[1] && lines[1].match(/Cannot find module.+sass/)) {
        // ./file.module.scss (<<loader info>>) => ./file.module.scss
        const firstLine = lines[0].split('!');
        lines[0] = firstLine[firstLine.length - 1];
        lines[1] = "To use Next.js' built-in Sass support, you first need to install `sass`.\n";
        lines[1] += 'Run `npm i sass` or `yarn add sass` inside your workspace.\n';
        lines[1] += '\nLearn more: https://nextjs.org/docs/messages/install-sass';
        // dispose of unhelpful stack trace
        lines = lines.slice(0, 2);
        hadMissingSassError = true;
    } else if (hadMissingSassError && message.match(/(sass-loader|resolve-url-loader: CSS error)/)) {
        // dispose of unhelpful stack trace following missing sass module
        lines = [];
    }
    if (!verbose) {
        message = lines.join('\n');
        // Internal stacks are generally useless so we strip them... with the
        // exception of stacks containing `webpack:` because they're normally
        // from user code generated by Webpack. For more information see
        // https://github.com/facebook/create-react-app/pull/1050
        message = message.replace(/^\s*at\s((?!webpack:).)*:\d+:\d+[\s)]*(\n|$)/gm, '') // at ... ...:x:y
        ;
        message = message.replace(/^\s*at\s<anonymous>(\n|$)/gm, '') // at <anonymous>
        ;
        message = message.replace(/File was processed with these loaders:\n(.+[\\/](next[\\/]dist[\\/].+|@next[\\/]react-refresh-utils[\\/]loader)\.js\n)*You may need an additional loader to handle the result of these loaders.\n/g, '');
        lines = message.split('\n');
    }
    // Remove duplicated newlines
    lines = lines.filter((line, index, arr)=>index === 0 || line.trim() !== '' || line.trim() !== arr[index - 1].trim());
    // Reassemble the message
    message = lines.join('\n');
    return message.trim();
}
function formatWebpackMessages(json, verbose) {
    const formattedErrors = json.errors.map((message)=>{
        const isUnknownNextFontError = message.message.includes('An error occurred in `next/font`.');
        return formatMessage(message, isUnknownNextFontError || verbose);
    });
    const formattedWarnings = json.warnings.map((message)=>{
        return formatMessage(message, verbose);
    });
    // Reorder errors to put the most relevant ones first.
    let reactServerComponentsError = -1;
    for(let i = 0; i < formattedErrors.length; i++){
        const error = formattedErrors[i];
        if (error.includes('ReactServerComponentsError')) {
            reactServerComponentsError = i;
            break;
        }
    }
    // Move the reactServerComponentsError to the top if it exists
    if (reactServerComponentsError !== -1) {
        const error = formattedErrors.splice(reactServerComponentsError, 1);
        formattedErrors.unshift(error[0]);
    }
    const result = {
        ...json,
        errors: formattedErrors,
        warnings: formattedWarnings
    };
    if (!verbose && result.errors.some(isLikelyASyntaxError)) {
        // If there are any syntax errors, show just them.
        result.errors = result.errors.filter(isLikelyASyntaxError);
        result.warnings = [];
    }
    return result;
} //# sourceMappingURL=format-webpack-messages.js.map
}),
"[project]/frontend/node_modules/next/dist/shared/lib/errors/constants.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "MISSING_ROOT_TAGS_ERROR", {
    enumerable: true,
    get: function() {
        return MISSING_ROOT_TAGS_ERROR;
    }
});
const MISSING_ROOT_TAGS_ERROR = 'NEXT_MISSING_ROOT_TAGS';
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=constants.js.map
}),
"[project]/frontend/node_modules/next/dist/shared/lib/normalized-asset-prefix.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "normalizedAssetPrefix", {
    enumerable: true,
    get: function() {
        return normalizedAssetPrefix;
    }
});
function normalizedAssetPrefix(assetPrefix) {
    // remove all leading slashes and trailing slashes
    const escapedAssetPrefix = assetPrefix?.replace(/^\/+|\/+$/g, '') || false;
    // if an assetPrefix was '/', we return empty string
    // because it could be an unnecessary trailing slash
    if (!escapedAssetPrefix) {
        return '';
    }
    if (URL.canParse(escapedAssetPrefix)) {
        const url = new URL(escapedAssetPrefix).toString();
        return url.endsWith('/') ? url.slice(0, -1) : url;
    }
    // assuming assetPrefix here is a pathname-style,
    // restore the leading slash
    return `/${escapedAssetPrefix}`;
} //# sourceMappingURL=normalized-asset-prefix.js.map
}),
"[project]/frontend/node_modules/next/dist/lib/is-error.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/frontend/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    default: null,
    getProperError: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    /**
 * Checks whether the given value is a NextError.
 * This can be used to print a more detailed error message with properties like `code` & `digest`.
 */ default: function() {
        return isError;
    },
    getProperError: function() {
        return getProperError;
    }
});
const _isplainobject = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/shared/lib/is-plain-object.js [app-client] (ecmascript)");
/**
 * This is a safe stringify function that handles circular references.
 * We're using a simpler version here to avoid introducing
 * the dependency `safe-stable-stringify` into production bundle.
 *
 * This helper is used both in development and production.
 */ function safeStringifyLite(obj) {
    const seen = new WeakSet();
    return JSON.stringify(obj, (_key, value)=>{
        // If value is an object and already seen, replace with "[Circular]"
        if (typeof value === 'object' && value !== null) {
            if (seen.has(value)) {
                return '[Circular]';
            }
            seen.add(value);
        }
        return value;
    });
}
function isError(err) {
    return typeof err === 'object' && err !== null && 'name' in err && 'message' in err;
}
function getProperError(err) {
    if (isError(err)) {
        return err;
    }
    if ("TURBOPACK compile-time truthy", 1) {
        // provide better error for case where `throw undefined`
        // is called in development
        if (typeof err === 'undefined') {
            return Object.defineProperty(new Error('An undefined error was thrown, ' + 'see here for more info: https://nextjs.org/docs/messages/threw-undefined'), "__NEXT_ERROR_CODE", {
                value: "E98",
                enumerable: false,
                configurable: true
            });
        }
        if (err === null) {
            return Object.defineProperty(new Error('A null error was thrown, ' + 'see here for more info: https://nextjs.org/docs/messages/threw-undefined'), "__NEXT_ERROR_CODE", {
                value: "E336",
                enumerable: false,
                configurable: true
            });
        }
    }
    return Object.defineProperty(new Error((0, _isplainobject.isPlainObject)(err) ? safeStringifyLite(err) : err + ''), "__NEXT_ERROR_CODE", {
        value: "E394",
        enumerable: false,
        configurable: true
    });
} //# sourceMappingURL=is-error.js.map
}),
"[project]/frontend/node_modules/next/dist/lib/require-instrumentation-client.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/frontend/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
/**
 * This module imports the client instrumentation hook from the project root.
 *
 * The `private-next-instrumentation-client` module is automatically aliased to
 * the `instrumentation-client.ts` file in the project root by webpack or turbopack.
 */ "use strict";
if ("TURBOPACK compile-time truthy", 1) {
    const measureName = 'Client Instrumentation Hook';
    const startTime = performance.now();
    // eslint-disable-next-line @next/internal/typechecked-require -- Not a module.
    module.exports = {};
    const endTime = performance.now();
    const duration = endTime - startTime;
    // Using 16ms threshold as it represents one frame (1000ms/60fps)
    // This helps identify if the instrumentation hook initialization
    // could potentially cause frame drops during development.
    const THRESHOLD = 16;
    if (duration > THRESHOLD) {
        console.log(`[${measureName}] Slow execution detected: ${duration.toFixed(0)}ms (Note: Code download overhead is not included in this measurement)`);
    }
} else //TURBOPACK unreachable
;
 //# sourceMappingURL=require-instrumentation-client.js.map
}),
"[project]/frontend/node_modules/next/dist/lib/framework/boundary-constants.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    METADATA_BOUNDARY_NAME: null,
    OUTLET_BOUNDARY_NAME: null,
    ROOT_LAYOUT_BOUNDARY_NAME: null,
    VIEWPORT_BOUNDARY_NAME: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    METADATA_BOUNDARY_NAME: function() {
        return METADATA_BOUNDARY_NAME;
    },
    OUTLET_BOUNDARY_NAME: function() {
        return OUTLET_BOUNDARY_NAME;
    },
    ROOT_LAYOUT_BOUNDARY_NAME: function() {
        return ROOT_LAYOUT_BOUNDARY_NAME;
    },
    VIEWPORT_BOUNDARY_NAME: function() {
        return VIEWPORT_BOUNDARY_NAME;
    }
});
const METADATA_BOUNDARY_NAME = '__next_metadata_boundary__';
const VIEWPORT_BOUNDARY_NAME = '__next_viewport_boundary__';
const OUTLET_BOUNDARY_NAME = '__next_outlet_boundary__';
const ROOT_LAYOUT_BOUNDARY_NAME = '__next_root_layout_boundary__'; //# sourceMappingURL=boundary-constants.js.map
}),
"[project]/frontend/node_modules/next/dist/lib/scheduler.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/frontend/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    atLeastOneTask: null,
    scheduleImmediate: null,
    scheduleOnNextTick: null,
    waitAtLeastOneReactRenderTask: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    atLeastOneTask: function() {
        return atLeastOneTask;
    },
    scheduleImmediate: function() {
        return scheduleImmediate;
    },
    scheduleOnNextTick: function() {
        return scheduleOnNextTick;
    },
    waitAtLeastOneReactRenderTask: function() {
        return waitAtLeastOneReactRenderTask;
    }
});
const scheduleOnNextTick = (cb)=>{
    // We use Promise.resolve().then() here so that the operation is scheduled at
    // the end of the promise job queue, we then add it to the next process tick
    // to ensure it's evaluated afterwards.
    //
    // This was inspired by the implementation of the DataLoader interface: https://github.com/graphql/dataloader/blob/d336bd15282664e0be4b4a657cb796f09bafbc6b/src/index.js#L213-L255
    //
    Promise.resolve().then(()=>{
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
        else {
            __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].nextTick(cb);
        }
    });
};
const scheduleImmediate = (cb)=>{
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    else {
        setImmediate(cb);
    }
};
function atLeastOneTask() {
    return new Promise((resolve)=>scheduleImmediate(resolve));
}
function waitAtLeastOneReactRenderTask() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    else {
        return new Promise((r)=>setImmediate(r));
    }
} //# sourceMappingURL=scheduler.js.map
}),
"[project]/frontend/node_modules/next/dist/lib/framework/boundary-components.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    MetadataBoundary: null,
    OutletBoundary: null,
    RootLayoutBoundary: null,
    ViewportBoundary: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    MetadataBoundary: function() {
        return MetadataBoundary;
    },
    OutletBoundary: function() {
        return OutletBoundary;
    },
    RootLayoutBoundary: function() {
        return RootLayoutBoundary;
    },
    ViewportBoundary: function() {
        return ViewportBoundary;
    }
});
const _boundaryconstants = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/lib/framework/boundary-constants.js [app-client] (ecmascript)");
// We use a namespace object to allow us to recover the name of the function
// at runtime even when production bundling/minification is used.
const NameSpace = {
    [_boundaryconstants.METADATA_BOUNDARY_NAME]: function({ children }) {
        return children;
    },
    [_boundaryconstants.VIEWPORT_BOUNDARY_NAME]: function({ children }) {
        return children;
    },
    [_boundaryconstants.OUTLET_BOUNDARY_NAME]: function({ children }) {
        return children;
    },
    [_boundaryconstants.ROOT_LAYOUT_BOUNDARY_NAME]: function({ children }) {
        return children;
    }
};
const MetadataBoundary = // so it retains the name inferred from the namespace object
NameSpace[_boundaryconstants.METADATA_BOUNDARY_NAME.slice(0)];
const ViewportBoundary = // so it retains the name inferred from the namespace object
NameSpace[_boundaryconstants.VIEWPORT_BOUNDARY_NAME.slice(0)];
const OutletBoundary = // so it retains the name inferred from the namespace object
NameSpace[_boundaryconstants.OUTLET_BOUNDARY_NAME.slice(0)];
const RootLayoutBoundary = // so it retains the name inferred from the namespace object
NameSpace[_boundaryconstants.ROOT_LAYOUT_BOUNDARY_NAME.slice(0)]; //# sourceMappingURL=boundary-components.js.map
}),
"[project]/frontend/node_modules/next/dist/lib/constants.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    ACTION_SUFFIX: null,
    APP_DIR_ALIAS: null,
    CACHE_ONE_YEAR: null,
    DOT_NEXT_ALIAS: null,
    ESLINT_DEFAULT_DIRS: null,
    GSP_NO_RETURNED_VALUE: null,
    GSSP_COMPONENT_MEMBER_ERROR: null,
    GSSP_NO_RETURNED_VALUE: null,
    HTML_CONTENT_TYPE_HEADER: null,
    INFINITE_CACHE: null,
    INSTRUMENTATION_HOOK_FILENAME: null,
    JSON_CONTENT_TYPE_HEADER: null,
    MATCHED_PATH_HEADER: null,
    MIDDLEWARE_FILENAME: null,
    MIDDLEWARE_LOCATION_REGEXP: null,
    NEXT_BODY_SUFFIX: null,
    NEXT_CACHE_IMPLICIT_TAG_ID: null,
    NEXT_CACHE_REVALIDATED_TAGS_HEADER: null,
    NEXT_CACHE_REVALIDATE_TAG_TOKEN_HEADER: null,
    NEXT_CACHE_SOFT_TAG_MAX_LENGTH: null,
    NEXT_CACHE_TAGS_HEADER: null,
    NEXT_CACHE_TAG_MAX_ITEMS: null,
    NEXT_CACHE_TAG_MAX_LENGTH: null,
    NEXT_DATA_SUFFIX: null,
    NEXT_INTERCEPTION_MARKER_PREFIX: null,
    NEXT_META_SUFFIX: null,
    NEXT_QUERY_PARAM_PREFIX: null,
    NEXT_RESUME_HEADER: null,
    NON_STANDARD_NODE_ENV: null,
    PAGES_DIR_ALIAS: null,
    PRERENDER_REVALIDATE_HEADER: null,
    PRERENDER_REVALIDATE_ONLY_GENERATED_HEADER: null,
    PROXY_FILENAME: null,
    PROXY_LOCATION_REGEXP: null,
    PUBLIC_DIR_MIDDLEWARE_CONFLICT: null,
    ROOT_DIR_ALIAS: null,
    RSC_ACTION_CLIENT_WRAPPER_ALIAS: null,
    RSC_ACTION_ENCRYPTION_ALIAS: null,
    RSC_ACTION_PROXY_ALIAS: null,
    RSC_ACTION_VALIDATE_ALIAS: null,
    RSC_CACHE_WRAPPER_ALIAS: null,
    RSC_DYNAMIC_IMPORT_WRAPPER_ALIAS: null,
    RSC_MOD_REF_PROXY_ALIAS: null,
    RSC_SEGMENTS_DIR_SUFFIX: null,
    RSC_SEGMENT_SUFFIX: null,
    RSC_SUFFIX: null,
    SERVER_PROPS_EXPORT_ERROR: null,
    SERVER_PROPS_GET_INIT_PROPS_CONFLICT: null,
    SERVER_PROPS_SSG_CONFLICT: null,
    SERVER_RUNTIME: null,
    SSG_FALLBACK_EXPORT_ERROR: null,
    SSG_GET_INITIAL_PROPS_CONFLICT: null,
    STATIC_STATUS_PAGE_GET_INITIAL_PROPS_ERROR: null,
    TEXT_PLAIN_CONTENT_TYPE_HEADER: null,
    UNSTABLE_REVALIDATE_RENAME_ERROR: null,
    WEBPACK_LAYERS: null,
    WEBPACK_RESOURCE_QUERIES: null,
    WEB_SOCKET_MAX_RECONNECTIONS: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    ACTION_SUFFIX: function() {
        return ACTION_SUFFIX;
    },
    APP_DIR_ALIAS: function() {
        return APP_DIR_ALIAS;
    },
    CACHE_ONE_YEAR: function() {
        return CACHE_ONE_YEAR;
    },
    DOT_NEXT_ALIAS: function() {
        return DOT_NEXT_ALIAS;
    },
    ESLINT_DEFAULT_DIRS: function() {
        return ESLINT_DEFAULT_DIRS;
    },
    GSP_NO_RETURNED_VALUE: function() {
        return GSP_NO_RETURNED_VALUE;
    },
    GSSP_COMPONENT_MEMBER_ERROR: function() {
        return GSSP_COMPONENT_MEMBER_ERROR;
    },
    GSSP_NO_RETURNED_VALUE: function() {
        return GSSP_NO_RETURNED_VALUE;
    },
    HTML_CONTENT_TYPE_HEADER: function() {
        return HTML_CONTENT_TYPE_HEADER;
    },
    INFINITE_CACHE: function() {
        return INFINITE_CACHE;
    },
    INSTRUMENTATION_HOOK_FILENAME: function() {
        return INSTRUMENTATION_HOOK_FILENAME;
    },
    JSON_CONTENT_TYPE_HEADER: function() {
        return JSON_CONTENT_TYPE_HEADER;
    },
    MATCHED_PATH_HEADER: function() {
        return MATCHED_PATH_HEADER;
    },
    MIDDLEWARE_FILENAME: function() {
        return MIDDLEWARE_FILENAME;
    },
    MIDDLEWARE_LOCATION_REGEXP: function() {
        return MIDDLEWARE_LOCATION_REGEXP;
    },
    NEXT_BODY_SUFFIX: function() {
        return NEXT_BODY_SUFFIX;
    },
    NEXT_CACHE_IMPLICIT_TAG_ID: function() {
        return NEXT_CACHE_IMPLICIT_TAG_ID;
    },
    NEXT_CACHE_REVALIDATED_TAGS_HEADER: function() {
        return NEXT_CACHE_REVALIDATED_TAGS_HEADER;
    },
    NEXT_CACHE_REVALIDATE_TAG_TOKEN_HEADER: function() {
        return NEXT_CACHE_REVALIDATE_TAG_TOKEN_HEADER;
    },
    NEXT_CACHE_SOFT_TAG_MAX_LENGTH: function() {
        return NEXT_CACHE_SOFT_TAG_MAX_LENGTH;
    },
    NEXT_CACHE_TAGS_HEADER: function() {
        return NEXT_CACHE_TAGS_HEADER;
    },
    NEXT_CACHE_TAG_MAX_ITEMS: function() {
        return NEXT_CACHE_TAG_MAX_ITEMS;
    },
    NEXT_CACHE_TAG_MAX_LENGTH: function() {
        return NEXT_CACHE_TAG_MAX_LENGTH;
    },
    NEXT_DATA_SUFFIX: function() {
        return NEXT_DATA_SUFFIX;
    },
    NEXT_INTERCEPTION_MARKER_PREFIX: function() {
        return NEXT_INTERCEPTION_MARKER_PREFIX;
    },
    NEXT_META_SUFFIX: function() {
        return NEXT_META_SUFFIX;
    },
    NEXT_QUERY_PARAM_PREFIX: function() {
        return NEXT_QUERY_PARAM_PREFIX;
    },
    NEXT_RESUME_HEADER: function() {
        return NEXT_RESUME_HEADER;
    },
    NON_STANDARD_NODE_ENV: function() {
        return NON_STANDARD_NODE_ENV;
    },
    PAGES_DIR_ALIAS: function() {
        return PAGES_DIR_ALIAS;
    },
    PRERENDER_REVALIDATE_HEADER: function() {
        return PRERENDER_REVALIDATE_HEADER;
    },
    PRERENDER_REVALIDATE_ONLY_GENERATED_HEADER: function() {
        return PRERENDER_REVALIDATE_ONLY_GENERATED_HEADER;
    },
    PROXY_FILENAME: function() {
        return PROXY_FILENAME;
    },
    PROXY_LOCATION_REGEXP: function() {
        return PROXY_LOCATION_REGEXP;
    },
    PUBLIC_DIR_MIDDLEWARE_CONFLICT: function() {
        return PUBLIC_DIR_MIDDLEWARE_CONFLICT;
    },
    ROOT_DIR_ALIAS: function() {
        return ROOT_DIR_ALIAS;
    },
    RSC_ACTION_CLIENT_WRAPPER_ALIAS: function() {
        return RSC_ACTION_CLIENT_WRAPPER_ALIAS;
    },
    RSC_ACTION_ENCRYPTION_ALIAS: function() {
        return RSC_ACTION_ENCRYPTION_ALIAS;
    },
    RSC_ACTION_PROXY_ALIAS: function() {
        return RSC_ACTION_PROXY_ALIAS;
    },
    RSC_ACTION_VALIDATE_ALIAS: function() {
        return RSC_ACTION_VALIDATE_ALIAS;
    },
    RSC_CACHE_WRAPPER_ALIAS: function() {
        return RSC_CACHE_WRAPPER_ALIAS;
    },
    RSC_DYNAMIC_IMPORT_WRAPPER_ALIAS: function() {
        return RSC_DYNAMIC_IMPORT_WRAPPER_ALIAS;
    },
    RSC_MOD_REF_PROXY_ALIAS: function() {
        return RSC_MOD_REF_PROXY_ALIAS;
    },
    RSC_SEGMENTS_DIR_SUFFIX: function() {
        return RSC_SEGMENTS_DIR_SUFFIX;
    },
    RSC_SEGMENT_SUFFIX: function() {
        return RSC_SEGMENT_SUFFIX;
    },
    RSC_SUFFIX: function() {
        return RSC_SUFFIX;
    },
    SERVER_PROPS_EXPORT_ERROR: function() {
        return SERVER_PROPS_EXPORT_ERROR;
    },
    SERVER_PROPS_GET_INIT_PROPS_CONFLICT: function() {
        return SERVER_PROPS_GET_INIT_PROPS_CONFLICT;
    },
    SERVER_PROPS_SSG_CONFLICT: function() {
        return SERVER_PROPS_SSG_CONFLICT;
    },
    SERVER_RUNTIME: function() {
        return SERVER_RUNTIME;
    },
    SSG_FALLBACK_EXPORT_ERROR: function() {
        return SSG_FALLBACK_EXPORT_ERROR;
    },
    SSG_GET_INITIAL_PROPS_CONFLICT: function() {
        return SSG_GET_INITIAL_PROPS_CONFLICT;
    },
    STATIC_STATUS_PAGE_GET_INITIAL_PROPS_ERROR: function() {
        return STATIC_STATUS_PAGE_GET_INITIAL_PROPS_ERROR;
    },
    TEXT_PLAIN_CONTENT_TYPE_HEADER: function() {
        return TEXT_PLAIN_CONTENT_TYPE_HEADER;
    },
    UNSTABLE_REVALIDATE_RENAME_ERROR: function() {
        return UNSTABLE_REVALIDATE_RENAME_ERROR;
    },
    WEBPACK_LAYERS: function() {
        return WEBPACK_LAYERS;
    },
    WEBPACK_RESOURCE_QUERIES: function() {
        return WEBPACK_RESOURCE_QUERIES;
    },
    WEB_SOCKET_MAX_RECONNECTIONS: function() {
        return WEB_SOCKET_MAX_RECONNECTIONS;
    }
});
const TEXT_PLAIN_CONTENT_TYPE_HEADER = 'text/plain';
const HTML_CONTENT_TYPE_HEADER = 'text/html; charset=utf-8';
const JSON_CONTENT_TYPE_HEADER = 'application/json; charset=utf-8';
const NEXT_QUERY_PARAM_PREFIX = 'nxtP';
const NEXT_INTERCEPTION_MARKER_PREFIX = 'nxtI';
const MATCHED_PATH_HEADER = 'x-matched-path';
const PRERENDER_REVALIDATE_HEADER = 'x-prerender-revalidate';
const PRERENDER_REVALIDATE_ONLY_GENERATED_HEADER = 'x-prerender-revalidate-if-generated';
const RSC_SEGMENTS_DIR_SUFFIX = '.segments';
const RSC_SEGMENT_SUFFIX = '.segment.rsc';
const RSC_SUFFIX = '.rsc';
const ACTION_SUFFIX = '.action';
const NEXT_DATA_SUFFIX = '.json';
const NEXT_META_SUFFIX = '.meta';
const NEXT_BODY_SUFFIX = '.body';
const NEXT_CACHE_TAGS_HEADER = 'x-next-cache-tags';
const NEXT_CACHE_REVALIDATED_TAGS_HEADER = 'x-next-revalidated-tags';
const NEXT_CACHE_REVALIDATE_TAG_TOKEN_HEADER = 'x-next-revalidate-tag-token';
const NEXT_RESUME_HEADER = 'next-resume';
const NEXT_CACHE_TAG_MAX_ITEMS = 128;
const NEXT_CACHE_TAG_MAX_LENGTH = 256;
const NEXT_CACHE_SOFT_TAG_MAX_LENGTH = 1024;
const NEXT_CACHE_IMPLICIT_TAG_ID = '_N_T_';
const CACHE_ONE_YEAR = 31536000;
const INFINITE_CACHE = 0xfffffffe;
const MIDDLEWARE_FILENAME = 'middleware';
const MIDDLEWARE_LOCATION_REGEXP = `(?:src/)?${MIDDLEWARE_FILENAME}`;
const PROXY_FILENAME = 'proxy';
const PROXY_LOCATION_REGEXP = `(?:src/)?${PROXY_FILENAME}`;
const INSTRUMENTATION_HOOK_FILENAME = 'instrumentation';
const PAGES_DIR_ALIAS = 'private-next-pages';
const DOT_NEXT_ALIAS = 'private-dot-next';
const ROOT_DIR_ALIAS = 'private-next-root-dir';
const APP_DIR_ALIAS = 'private-next-app-dir';
const RSC_MOD_REF_PROXY_ALIAS = 'private-next-rsc-mod-ref-proxy';
const RSC_ACTION_VALIDATE_ALIAS = 'private-next-rsc-action-validate';
const RSC_ACTION_PROXY_ALIAS = 'private-next-rsc-server-reference';
const RSC_CACHE_WRAPPER_ALIAS = 'private-next-rsc-cache-wrapper';
const RSC_DYNAMIC_IMPORT_WRAPPER_ALIAS = 'private-next-rsc-track-dynamic-import';
const RSC_ACTION_ENCRYPTION_ALIAS = 'private-next-rsc-action-encryption';
const RSC_ACTION_CLIENT_WRAPPER_ALIAS = 'private-next-rsc-action-client-wrapper';
const PUBLIC_DIR_MIDDLEWARE_CONFLICT = `You can not have a '_next' folder inside of your public folder. This conflicts with the internal '/_next' route. https://nextjs.org/docs/messages/public-next-folder-conflict`;
const SSG_GET_INITIAL_PROPS_CONFLICT = `You can not use getInitialProps with getStaticProps. To use SSG, please remove your getInitialProps`;
const SERVER_PROPS_GET_INIT_PROPS_CONFLICT = `You can not use getInitialProps with getServerSideProps. Please remove getInitialProps.`;
const SERVER_PROPS_SSG_CONFLICT = `You can not use getStaticProps or getStaticPaths with getServerSideProps. To use SSG, please remove getServerSideProps`;
const STATIC_STATUS_PAGE_GET_INITIAL_PROPS_ERROR = `can not have getInitialProps/getServerSideProps, https://nextjs.org/docs/messages/404-get-initial-props`;
const SERVER_PROPS_EXPORT_ERROR = `pages with \`getServerSideProps\` can not be exported. See more info here: https://nextjs.org/docs/messages/gssp-export`;
const GSP_NO_RETURNED_VALUE = 'Your `getStaticProps` function did not return an object. Did you forget to add a `return`?';
const GSSP_NO_RETURNED_VALUE = 'Your `getServerSideProps` function did not return an object. Did you forget to add a `return`?';
const UNSTABLE_REVALIDATE_RENAME_ERROR = 'The `unstable_revalidate` property is available for general use.\n' + 'Please use `revalidate` instead.';
const GSSP_COMPONENT_MEMBER_ERROR = `can not be attached to a page's component and must be exported from the page. See more info here: https://nextjs.org/docs/messages/gssp-component-member`;
const NON_STANDARD_NODE_ENV = `You are using a non-standard "NODE_ENV" value in your environment. This creates inconsistencies in the project and is strongly advised against. Read more: https://nextjs.org/docs/messages/non-standard-node-env`;
const SSG_FALLBACK_EXPORT_ERROR = `Pages with \`fallback\` enabled in \`getStaticPaths\` can not be exported. See more info here: https://nextjs.org/docs/messages/ssg-fallback-true-export`;
const ESLINT_DEFAULT_DIRS = [
    'app',
    'pages',
    'components',
    'lib',
    'src'
];
const SERVER_RUNTIME = {
    edge: 'edge',
    experimentalEdge: 'experimental-edge',
    nodejs: 'nodejs'
};
const WEB_SOCKET_MAX_RECONNECTIONS = 12;
/**
 * The names of the webpack layers. These layers are the primitives for the
 * webpack chunks.
 */ const WEBPACK_LAYERS_NAMES = {
    /**
   * The layer for the shared code between the client and server bundles.
   */ shared: 'shared',
    /**
   * The layer for server-only runtime and picking up `react-server` export conditions.
   * Including app router RSC pages and app router custom routes and metadata routes.
   */ reactServerComponents: 'rsc',
    /**
   * Server Side Rendering layer for app (ssr).
   */ serverSideRendering: 'ssr',
    /**
   * The browser client bundle layer for actions.
   */ actionBrowser: 'action-browser',
    /**
   * The Node.js bundle layer for the API routes.
   */ apiNode: 'api-node',
    /**
   * The Edge Lite bundle layer for the API routes.
   */ apiEdge: 'api-edge',
    /**
   * The layer for the middleware code.
   */ middleware: 'middleware',
    /**
   * The layer for the instrumentation hooks.
   */ instrument: 'instrument',
    /**
   * The layer for assets on the edge.
   */ edgeAsset: 'edge-asset',
    /**
   * The browser client bundle layer for App directory.
   */ appPagesBrowser: 'app-pages-browser',
    /**
   * The browser client bundle layer for Pages directory.
   */ pagesDirBrowser: 'pages-dir-browser',
    /**
   * The Edge Lite bundle layer for Pages directory.
   */ pagesDirEdge: 'pages-dir-edge',
    /**
   * The Node.js bundle layer for Pages directory.
   */ pagesDirNode: 'pages-dir-node'
};
const WEBPACK_LAYERS = {
    ...WEBPACK_LAYERS_NAMES,
    GROUP: {
        builtinReact: [
            WEBPACK_LAYERS_NAMES.reactServerComponents,
            WEBPACK_LAYERS_NAMES.actionBrowser
        ],
        serverOnly: [
            WEBPACK_LAYERS_NAMES.reactServerComponents,
            WEBPACK_LAYERS_NAMES.actionBrowser,
            WEBPACK_LAYERS_NAMES.instrument,
            WEBPACK_LAYERS_NAMES.middleware
        ],
        neutralTarget: [
            // pages api
            WEBPACK_LAYERS_NAMES.apiNode,
            WEBPACK_LAYERS_NAMES.apiEdge
        ],
        clientOnly: [
            WEBPACK_LAYERS_NAMES.serverSideRendering,
            WEBPACK_LAYERS_NAMES.appPagesBrowser
        ],
        bundled: [
            WEBPACK_LAYERS_NAMES.reactServerComponents,
            WEBPACK_LAYERS_NAMES.actionBrowser,
            WEBPACK_LAYERS_NAMES.serverSideRendering,
            WEBPACK_LAYERS_NAMES.appPagesBrowser,
            WEBPACK_LAYERS_NAMES.shared,
            WEBPACK_LAYERS_NAMES.instrument,
            WEBPACK_LAYERS_NAMES.middleware
        ],
        appPages: [
            // app router pages and layouts
            WEBPACK_LAYERS_NAMES.reactServerComponents,
            WEBPACK_LAYERS_NAMES.serverSideRendering,
            WEBPACK_LAYERS_NAMES.appPagesBrowser,
            WEBPACK_LAYERS_NAMES.actionBrowser
        ]
    }
};
const WEBPACK_RESOURCE_QUERIES = {
    edgeSSREntry: '__next_edge_ssr_entry__',
    metadata: '__next_metadata__',
    metadataRoute: '__next_metadata_route__',
    metadataImageMeta: '__next_metadata_image_meta__'
}; //# sourceMappingURL=constants.js.map
}),
"[project]/frontend/node_modules/next/dist/next-devtools/userspace/app/errors/stitched-error.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    coerceError: null,
    decorateDevError: null,
    getOwnerStack: null,
    setOwnerStack: null,
    setOwnerStackIfAvailable: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    coerceError: function() {
        return coerceError;
    },
    decorateDevError: function() {
        return decorateDevError;
    },
    getOwnerStack: function() {
        return getOwnerStack;
    },
    setOwnerStack: function() {
        return setOwnerStack;
    },
    setOwnerStackIfAvailable: function() {
        return setOwnerStackIfAvailable;
    }
});
const _interop_require_default = __turbopack_context__.r("[project]/frontend/node_modules/@swc/helpers/cjs/_interop_require_default.cjs [app-client] (ecmascript)");
const _react = /*#__PURE__*/ _interop_require_default._(__turbopack_context__.r("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
const _iserror = /*#__PURE__*/ _interop_require_default._(__turbopack_context__.r("[project]/frontend/node_modules/next/dist/lib/is-error.js [app-client] (ecmascript)"));
const ownerStacks = new WeakMap();
function getOwnerStack(error) {
    return ownerStacks.get(error);
}
function setOwnerStack(error, stack) {
    ownerStacks.set(error, stack);
}
function coerceError(value) {
    return (0, _iserror.default)(value) ? value : Object.defineProperty(new Error('' + value), "__NEXT_ERROR_CODE", {
        value: "E394",
        enumerable: false,
        configurable: true
    });
}
function setOwnerStackIfAvailable(error) {
    // React 18 and prod does not have `captureOwnerStack`
    if ('captureOwnerStack' in _react.default) {
        setOwnerStack(error, _react.default.captureOwnerStack());
    }
}
function decorateDevError(thrownValue) {
    const error = coerceError(thrownValue);
    setOwnerStackIfAvailable(error);
    return error;
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=stitched-error.js.map
}),
"[project]/frontend/node_modules/next/dist/next-devtools/shared/console-error.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// To distinguish from React error.digest, we use a different symbol here to determine if the error is from console.error or unhandled promise rejection.
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    createConsoleError: null,
    isConsoleError: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    createConsoleError: function() {
        return createConsoleError;
    },
    isConsoleError: function() {
        return isConsoleError;
    }
});
const digestSym = Symbol.for('next.console.error.digest');
function createConsoleError(message, environmentName) {
    const error = typeof message === 'string' ? Object.defineProperty(new Error(message), "__NEXT_ERROR_CODE", {
        value: "E394",
        enumerable: false,
        configurable: true
    }) : message;
    error[digestSym] = 'NEXT_CONSOLE_ERROR';
    if (environmentName && !error.environmentName) {
        error.environmentName = environmentName;
    }
    return error;
}
const isConsoleError = (error)=>{
    return error && error[digestSym] === 'NEXT_CONSOLE_ERROR';
};
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=console-error.js.map
}),
"[project]/frontend/node_modules/next/dist/next-devtools/userspace/app/terminal-logging-config.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/frontend/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    getIsTerminalLoggingEnabled: null,
    getTerminalLoggingConfig: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    getIsTerminalLoggingEnabled: function() {
        return getIsTerminalLoggingEnabled;
    },
    getTerminalLoggingConfig: function() {
        return getTerminalLoggingConfig;
    }
});
function getTerminalLoggingConfig() {
    try {
        return JSON.parse(("TURBOPACK compile-time value", "false") || 'false');
    } catch  {
        return false;
    }
}
function getIsTerminalLoggingEnabled() {
    const config = getTerminalLoggingConfig();
    return Boolean(config);
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=terminal-logging-config.js.map
}),
"[project]/frontend/node_modules/next/dist/next-devtools/shared/forward-logs-shared.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    UNDEFINED_MARKER: null,
    patchConsoleMethod: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    UNDEFINED_MARKER: function() {
        return UNDEFINED_MARKER;
    },
    patchConsoleMethod: function() {
        return patchConsoleMethod;
    }
});
const UNDEFINED_MARKER = '__next_tagged_undefined';
function patchConsoleMethod(methodName, wrapper) {
    const descriptor = Object.getOwnPropertyDescriptor(console, methodName);
    if (descriptor && (descriptor.configurable || descriptor.writable) && typeof descriptor.value === 'function') {
        const originalMethod = descriptor.value;
        const originalName = Object.getOwnPropertyDescriptor(originalMethod, 'name');
        const wrapperMethod = function(...args) {
            wrapper(methodName, ...args);
            originalMethod.apply(this, args);
        };
        if (originalName) {
            Object.defineProperty(wrapperMethod, 'name', originalName);
        }
        Object.defineProperty(console, methodName, {
            value: wrapperMethod
        });
        return ()=>{
            Object.defineProperty(console, methodName, {
                value: originalMethod,
                writable: descriptor.writable,
                configurable: descriptor.configurable
            });
        };
    }
    return ()=>{};
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=forward-logs-shared.js.map
}),
"[project]/frontend/node_modules/next/dist/next-devtools/userspace/app/forward-logs-utils.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    logStringify: null,
    preLogSerializationClone: null,
    safeStringifyWithDepth: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    logStringify: function() {
        return logStringify;
    },
    preLogSerializationClone: function() {
        return preLogSerializationClone;
    },
    safeStringifyWithDepth: function() {
        return safeStringifyWithDepth;
    }
});
const _safestablestringify = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/compiled/safe-stable-stringify/index.js [app-client] (ecmascript)");
const _terminalloggingconfig = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/next-devtools/userspace/app/terminal-logging-config.js [app-client] (ecmascript)");
const _forwardlogsshared = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/next-devtools/shared/forward-logs-shared.js [app-client] (ecmascript)");
const terminalLoggingConfig = (0, _terminalloggingconfig.getTerminalLoggingConfig)();
const PROMISE_MARKER = 'Promise {}';
const UNAVAILABLE_MARKER = '[Unable to view]';
const maximumDepth = typeof terminalLoggingConfig === 'object' && terminalLoggingConfig.depthLimit ? terminalLoggingConfig.depthLimit : 5;
const maximumBreadth = typeof terminalLoggingConfig === 'object' && terminalLoggingConfig.edgeLimit ? terminalLoggingConfig.edgeLimit : 100;
const safeStringifyWithDepth = (0, _safestablestringify.configure)({
    maximumDepth,
    maximumBreadth
});
function preLogSerializationClone(value, seen = new WeakMap()) {
    if (value === undefined) return _forwardlogsshared.UNDEFINED_MARKER;
    if (value === null || typeof value !== 'object') return value;
    if (seen.has(value)) return seen.get(value);
    try {
        Object.keys(value);
    } catch  {
        return UNAVAILABLE_MARKER;
    }
    try {
        if (typeof value.then === 'function') return PROMISE_MARKER;
    } catch  {
        return UNAVAILABLE_MARKER;
    }
    if (Array.isArray(value)) {
        const out = [];
        seen.set(value, out);
        for (const item of value){
            try {
                out.push(preLogSerializationClone(item, seen));
            } catch  {
                out.push(UNAVAILABLE_MARKER);
            }
        }
        return out;
    }
    const proto = Object.getPrototypeOf(value);
    if (proto === Object.prototype || proto === null) {
        const out = {};
        seen.set(value, out);
        for (const key of Object.keys(value)){
            try {
                out[key] = preLogSerializationClone(value[key], seen);
            } catch  {
                out[key] = UNAVAILABLE_MARKER;
            }
        }
        return out;
    }
    return Object.prototype.toString.call(value);
}
const logStringify = (data)=>{
    try {
        const result = safeStringifyWithDepth(data);
        return result ?? `"${UNAVAILABLE_MARKER}"`;
    } catch  {
        return `"${UNAVAILABLE_MARKER}"`;
    }
};
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=forward-logs-utils.js.map
}),
"[project]/frontend/node_modules/next/dist/next-devtools/userspace/app/forward-logs.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/frontend/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    forwardErrorLog: null,
    forwardUnhandledError: null,
    initializeDebugLogForwarding: null,
    logQueue: null,
    logUnhandledRejection: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    forwardErrorLog: function() {
        return forwardErrorLog;
    },
    forwardUnhandledError: function() {
        return forwardUnhandledError;
    },
    initializeDebugLogForwarding: function() {
        return initializeDebugLogForwarding;
    },
    logQueue: function() {
        return logQueue;
    },
    logUnhandledRejection: function() {
        return logUnhandledRejection;
    }
});
const _stitchederror = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/next-devtools/userspace/app/errors/stitched-error.js [app-client] (ecmascript)");
const _errorsource = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/shared/lib/error-source.js [app-client] (ecmascript)");
const _terminalloggingconfig = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/next-devtools/userspace/app/terminal-logging-config.js [app-client] (ecmascript)");
const _forwardlogsshared = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/next-devtools/shared/forward-logs-shared.js [app-client] (ecmascript)");
const _forwardlogsutils = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/next-devtools/userspace/app/forward-logs-utils.js [app-client] (ecmascript)");
// Client-side file logger for browser logs
class ClientFileLogger {
    formatTimestamp() {
        const now = new Date();
        const hours = now.getHours().toString().padStart(2, '0');
        const minutes = now.getMinutes().toString().padStart(2, '0');
        const seconds = now.getSeconds().toString().padStart(2, '0');
        const milliseconds = now.getMilliseconds().toString().padStart(3, '0');
        return `${hours}:${minutes}:${seconds}.${milliseconds}`;
    }
    log(level, args) {
        if (isReactServerReplayedLog(args)) {
            return;
        }
        // Format the args into a message string
        const message = args.map((arg)=>{
            if (typeof arg === 'string') return arg;
            if (typeof arg === 'number' || typeof arg === 'boolean') return String(arg);
            if (arg === null) return 'null';
            if (arg === undefined) return 'undefined';
            // Handle DOM nodes - only log the tag name to avoid React proxied elements
            if (arg instanceof Element) {
                return `<${arg.tagName.toLowerCase()}>`;
            }
            return (0, _forwardlogsutils.safeStringifyWithDepth)(arg);
        }).join(' ');
        const logEntry = {
            timestamp: this.formatTimestamp(),
            level: level.toUpperCase(),
            message
        };
        this.logEntries.push(logEntry);
        // Schedule flush when new log is added
        scheduleLogFlush();
    }
    getLogs() {
        return [
            ...this.logEntries
        ];
    }
    clear() {
        this.logEntries = [];
    }
    constructor(){
        this.logEntries = [];
    }
}
const clientFileLogger = new ClientFileLogger();
// Set up flush-based sending of client file logs
let logFlushTimeout = null;
let heartbeatInterval = null;
const scheduleLogFlush = ()=>{
    if (logFlushTimeout) {
        clearTimeout(logFlushTimeout);
    }
    logFlushTimeout = setTimeout(()=>{
        sendClientFileLogs();
        logFlushTimeout = null;
    }, 100) // Send after 100ms (much faster with debouncing)
    ;
};
const cancelLogFlush = ()=>{
    if (logFlushTimeout) {
        clearTimeout(logFlushTimeout);
        logFlushTimeout = null;
    }
};
const startHeartbeat = ()=>{
    if (heartbeatInterval) return;
    heartbeatInterval = setInterval(()=>{
        if (logQueue.socket && logQueue.socket.readyState === WebSocket.OPEN) {
            try {
                // Send a ping to keep the connection alive
                logQueue.socket.send(JSON.stringify({
                    event: 'ping'
                }));
            } catch (error) {
                // Connection might be closed, stop heartbeat
                stopHeartbeat();
            }
        } else {
            stopHeartbeat();
        }
    }, 5000) // Send ping every 5 seconds
    ;
};
const stopHeartbeat = ()=>{
    if (heartbeatInterval) {
        clearInterval(heartbeatInterval);
        heartbeatInterval = null;
    }
};
const isTerminalLoggingEnabled = (0, _terminalloggingconfig.getIsTerminalLoggingEnabled)();
const methods = [
    'log',
    'info',
    'warn',
    'debug',
    'table',
    'assert',
    'dir',
    'dirxml',
    'group',
    'groupCollapsed',
    'groupEnd',
    'trace'
];
const afterThisFrame = (cb)=>{
    let timeout;
    const rafId = requestAnimationFrame(()=>{
        timeout = setTimeout(()=>{
            cb();
        });
    });
    return ()=>{
        cancelAnimationFrame(rafId);
        clearTimeout(timeout);
    };
};
let isPatched = false;
const serializeEntries = (entries)=>entries.map((clientEntry)=>{
        switch(clientEntry.kind){
            case 'any-logged-error':
            case 'console':
                {
                    return {
                        ...clientEntry,
                        args: clientEntry.args.map(stringifyUserArg)
                    };
                }
            case 'formatted-error':
                {
                    return clientEntry;
                }
            default:
                {
                    return null;
                }
        }
    });
// Function to send client file logs to server
const sendClientFileLogs = ()=>{
    if (!logQueue.socket || logQueue.socket.readyState !== WebSocket.OPEN) {
        return;
    }
    const logs = clientFileLogger.getLogs();
    if (logs.length === 0) {
        return;
    }
    try {
        const payload = JSON.stringify({
            event: 'client-file-logs',
            logs: logs
        });
        logQueue.socket.send(payload);
    } catch (error) {
        console.error(error);
    } finally{
        // Clear logs regardless of send success to prevent memory leaks
        clientFileLogger.clear();
    }
};
const logQueue = {
    entries: [],
    flushScheduled: false,
    cancelFlush: null,
    socket: null,
    sourceType: undefined,
    router: null,
    scheduleLogSend: (entry)=>{
        logQueue.entries.push(entry);
        if (logQueue.flushScheduled) {
            return;
        }
        // safe to deref and use in setTimeout closure since we cancel on new socket
        const socket = logQueue.socket;
        if (!socket) {
            return;
        }
        // we probably dont need this
        logQueue.flushScheduled = true;
        // non blocking log flush, runs at most once per frame
        logQueue.cancelFlush = afterThisFrame(()=>{
            logQueue.flushScheduled = false;
            // just incase
            try {
                const payload = JSON.stringify({
                    event: 'browser-logs',
                    entries: serializeEntries(logQueue.entries),
                    router: logQueue.router,
                    // needed for source mapping, we just assign the sourceType from the last error for the whole batch
                    sourceType: logQueue.sourceType
                });
                socket.send(payload);
                logQueue.entries = [];
                logQueue.sourceType = undefined;
                // Also send client file logs
                sendClientFileLogs();
            } catch  {
            // error (make sure u don't infinite loop)
            /* noop */ }
        });
    },
    onSocketReady: (socket)=>{
        // When MCP or terminal logging is enabled, we enable the socket connection,
        // otherwise it will not proceed.
        if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
        ;
        if (socket.readyState !== WebSocket.OPEN) {
            // invariant
            return;
        }
        // incase an existing timeout was going to run with a stale socket
        logQueue.cancelFlush?.();
        logQueue.socket = socket;
        // Add socket event listeners to track connection state
        socket.addEventListener('close', ()=>{
            cancelLogFlush();
            stopHeartbeat();
        });
        // Only send terminal logs if enabled
        if (isTerminalLoggingEnabled) {
            try {
                const payload = JSON.stringify({
                    event: 'browser-logs',
                    entries: serializeEntries(logQueue.entries),
                    router: logQueue.router,
                    sourceType: logQueue.sourceType
                });
                socket.send(payload);
                logQueue.entries = [];
                logQueue.sourceType = undefined;
            } catch  {
            /** noop just incase */ }
        }
        // Always send client file logs when socket is ready
        sendClientFileLogs();
        // Start heartbeat to keep connection alive
        startHeartbeat();
    }
};
const stringifyUserArg = (arg)=>{
    if (arg.kind !== 'arg') {
        return arg;
    }
    return {
        ...arg,
        data: (0, _forwardlogsutils.logStringify)(arg.data)
    };
};
const createErrorArg = (error)=>{
    const stack = stackWithOwners(error);
    return {
        kind: 'formatted-error-arg',
        prefix: error.message ? `${error.name}: ${error.message}` : `${error.name}`,
        stack
    };
};
const createLogEntry = (level, args)=>{
    // Always log to client file logger with args (formatting done inside log method)
    clientFileLogger.log(level, args);
    // Only forward to terminal if enabled
    if (!isTerminalLoggingEnabled) {
        return;
    }
    // do not abstract this, it implicitly relies on which functions call it. forcing the inlined implementation makes you think about callers
    // error capture stack trace maybe
    const stack = stackWithOwners(new Error());
    const stackLines = stack?.split('\n');
    const cleanStack = stackLines?.slice(3).join('\n') // this is probably ignored anyways
    ;
    const entry = {
        kind: 'console',
        consoleMethodStack: cleanStack ?? null,
        method: level,
        args: args.map((arg)=>{
            if (arg instanceof Error) {
                return createErrorArg(arg);
            }
            return {
                kind: 'arg',
                data: (0, _forwardlogsutils.preLogSerializationClone)(arg)
            };
        })
    };
    logQueue.scheduleLogSend(entry);
};
const forwardErrorLog = (args)=>{
    // Always log to client file logger with args (formatting done inside log method)
    clientFileLogger.log('error', args);
    // Only forward to terminal if enabled
    if (!isTerminalLoggingEnabled) {
        return;
    }
    const errorObjects = args.filter((arg)=>arg instanceof Error);
    const first = errorObjects.at(0);
    if (first) {
        const source = (0, _errorsource.getErrorSource)(first);
        if (source) {
            logQueue.sourceType = source;
        }
    }
    /**
   * browser shows stack regardless of type of data passed to console.error, so we should do the same
   *
   * do not abstract this, it implicitly relies on which functions call it. forcing the inlined implementation makes you think about callers
   */ const stack = stackWithOwners(new Error());
    const stackLines = stack?.split('\n');
    const cleanStack = stackLines?.slice(3).join('\n');
    const entry = {
        kind: 'any-logged-error',
        method: 'error',
        consoleErrorStack: cleanStack ?? '',
        args: args.map((arg)=>{
            if (arg instanceof Error) {
                return createErrorArg(arg);
            }
            return {
                kind: 'arg',
                data: (0, _forwardlogsutils.preLogSerializationClone)(arg)
            };
        })
    };
    logQueue.scheduleLogSend(entry);
};
const createUncaughtErrorEntry = (errorName, errorMessage, fullStack)=>{
    const entry = {
        kind: 'formatted-error',
        prefix: `Uncaught ${errorName}: ${errorMessage}`,
        stack: fullStack,
        method: 'error'
    };
    logQueue.scheduleLogSend(entry);
};
const stackWithOwners = (error)=>{
    let ownerStack = '';
    (0, _stitchederror.setOwnerStackIfAvailable)(error);
    ownerStack = (0, _stitchederror.getOwnerStack)(error) || '';
    const stack = (error.stack || '') + ownerStack;
    return stack;
};
function logUnhandledRejection(reason) {
    // Always log to client file logger
    const message = reason instanceof Error ? `${reason.name}: ${reason.message}` : JSON.stringify(reason);
    clientFileLogger.log('error', [
        `unhandledRejection: ${message}`
    ]);
    // Only forward to terminal if enabled
    if (!isTerminalLoggingEnabled) {
        return;
    }
    if (reason instanceof Error) {
        createUnhandledRejectionErrorEntry(reason, stackWithOwners(reason));
        return;
    }
    createUnhandledRejectionNonErrorEntry(reason);
}
const createUnhandledRejectionErrorEntry = (error, fullStack)=>{
    const source = (0, _errorsource.getErrorSource)(error);
    if (source) {
        logQueue.sourceType = source;
    }
    const entry = {
        kind: 'formatted-error',
        prefix: `⨯ unhandledRejection: ${error.name}: ${error.message}`,
        stack: fullStack,
        method: 'error'
    };
    logQueue.scheduleLogSend(entry);
};
const createUnhandledRejectionNonErrorEntry = (reason)=>{
    const entry = {
        kind: 'any-logged-error',
        // we can't access the stack since the event is dispatched async and creating an inline error would be meaningless
        consoleErrorStack: '',
        method: 'error',
        args: [
            {
                kind: 'arg',
                data: `⨯ unhandledRejection:`,
                isRejectionMessage: true
            },
            {
                kind: 'arg',
                data: (0, _forwardlogsutils.preLogSerializationClone)(reason)
            }
        ]
    };
    logQueue.scheduleLogSend(entry);
};
const isHMR = (args)=>{
    const firstArg = args[0];
    if (typeof firstArg !== 'string') {
        return false;
    }
    if (firstArg.startsWith('[Fast Refresh]')) {
        return true;
    }
    if (firstArg.startsWith('[HMR]')) {
        return true;
    }
    return false;
};
/**
 * Matches the format of logs arguments React replayed from the RSC.
 */ const isReactServerReplayedLog = (args)=>{
    if (args.length < 3) {
        return false;
    }
    const [format, styles, label] = args;
    if (typeof format !== 'string' || typeof styles !== 'string' || typeof label !== 'string') {
        return false;
    }
    return format.startsWith('%c%s%c') && styles.includes('background:');
};
function forwardUnhandledError(error) {
    // Always log to client file logger
    clientFileLogger.log('error', [
        `uncaughtError: ${error.name}: ${error.message}`
    ]);
    // Only forward to terminal if enabled
    if (!isTerminalLoggingEnabled) {
        return;
    }
    createUncaughtErrorEntry(error.name, error.message, stackWithOwners(error));
}
const initializeDebugLogForwarding = (router)=>{
    // probably don't need this
    if (isPatched) {
        return;
    }
    // TODO(rob): why does this break rendering on server, important to know incase the same bug appears in browser
    if (typeof window === 'undefined') {
        return;
    }
    // better to be safe than sorry
    try {
        methods.forEach((method)=>(0, _forwardlogsshared.patchConsoleMethod)(method, (_, ...args)=>{
                if (isHMR(args)) {
                    return;
                }
                if (isReactServerReplayedLog(args)) {
                    return;
                }
                createLogEntry(method, args);
            }));
    } catch  {}
    logQueue.router = router;
    isPatched = true;
    // Cleanup on page unload
    window.addEventListener('beforeunload', ()=>{
        cancelLogFlush();
        stopHeartbeat();
        // Send any remaining logs before page unloads
        sendClientFileLogs();
    });
};
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=forward-logs.js.map
}),
"[project]/frontend/node_modules/next/dist/next-devtools/userspace/app/errors/use-error-handler.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    handleClientError: null,
    handleConsoleError: null,
    handleGlobalErrors: null,
    useErrorHandler: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    handleClientError: function() {
        return handleClientError;
    },
    handleConsoleError: function() {
        return handleConsoleError;
    },
    handleGlobalErrors: function() {
        return handleGlobalErrors;
    },
    useErrorHandler: function() {
        return useErrorHandler;
    }
});
const _interop_require_default = __turbopack_context__.r("[project]/frontend/node_modules/@swc/helpers/cjs/_interop_require_default.cjs [app-client] (ecmascript)");
const _react = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
const _isnextroutererror = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/client/components/is-next-router-error.js [app-client] (ecmascript)");
const _console = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/client/lib/console.js [app-client] (ecmascript)");
const _iserror = /*#__PURE__*/ _interop_require_default._(__turbopack_context__.r("[project]/frontend/node_modules/next/dist/lib/is-error.js [app-client] (ecmascript)"));
const _consoleerror = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/next-devtools/shared/console-error.js [app-client] (ecmascript)");
const _stitchederror = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/next-devtools/userspace/app/errors/stitched-error.js [app-client] (ecmascript)");
const _forwardlogs = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/next-devtools/userspace/app/forward-logs.js [app-client] (ecmascript)");
const queueMicroTask = globalThis.queueMicrotask || ((cb)=>Promise.resolve().then(cb));
const errorQueue = [];
const errorHandlers = [];
const rejectionQueue = [];
const rejectionHandlers = [];
function handleConsoleError(originError, consoleErrorArgs) {
    let error;
    const { environmentName } = (0, _console.parseConsoleArgs)(consoleErrorArgs);
    if ((0, _iserror.default)(originError)) {
        error = (0, _consoleerror.createConsoleError)(originError, environmentName);
    } else {
        error = (0, _consoleerror.createConsoleError)((0, _console.formatConsoleArgs)(consoleErrorArgs), environmentName);
    }
    (0, _stitchederror.setOwnerStackIfAvailable)(error);
    errorQueue.push(error);
    for (const handler of errorHandlers){
        // Delayed the error being passed to React Dev Overlay,
        // avoid the state being synchronously updated in the component.
        queueMicroTask(()=>{
            handler(error);
        });
    }
}
function handleClientError(error) {
    errorQueue.push(error);
    for (const handler of errorHandlers){
        // Delayed the error being passed to React Dev Overlay,
        // avoid the state being synchronously updated in the component.
        queueMicroTask(()=>{
            handler(error);
        });
    }
}
function useErrorHandler(handleOnUnhandledError, handleOnUnhandledRejection) {
    (0, _react.useEffect)(()=>{
        // Handle queued errors.
        errorQueue.forEach(handleOnUnhandledError);
        rejectionQueue.forEach(handleOnUnhandledRejection);
        // Listen to new errors.
        errorHandlers.push(handleOnUnhandledError);
        rejectionHandlers.push(handleOnUnhandledRejection);
        return ()=>{
            // Remove listeners.
            errorHandlers.splice(errorHandlers.indexOf(handleOnUnhandledError), 1);
            rejectionHandlers.splice(rejectionHandlers.indexOf(handleOnUnhandledRejection), 1);
            // Reset error queues.
            errorQueue.splice(0, errorQueue.length);
            rejectionQueue.splice(0, rejectionQueue.length);
        };
    }, [
        handleOnUnhandledError,
        handleOnUnhandledRejection
    ]);
}
function onUnhandledError(event) {
    const thrownValue = event.error;
    if ((0, _isnextroutererror.isNextRouterError)(thrownValue)) {
        event.preventDefault();
        return false;
    }
    // When there's an error property present, we log the error to error overlay.
    // Otherwise we don't do anything as it's not logging in the console either.
    if (thrownValue) {
        const error = (0, _stitchederror.coerceError)(thrownValue);
        (0, _stitchederror.setOwnerStackIfAvailable)(error);
        handleClientError(error);
        (0, _forwardlogs.forwardUnhandledError)(error);
    }
}
function onUnhandledRejection(ev) {
    const reason = ev?.reason;
    if ((0, _isnextroutererror.isNextRouterError)(reason)) {
        ev.preventDefault();
        return;
    }
    const error = (0, _stitchederror.coerceError)(reason);
    (0, _stitchederror.setOwnerStackIfAvailable)(error);
    rejectionQueue.push(error);
    for (const handler of rejectionHandlers){
        handler(error);
    }
    (0, _forwardlogs.logUnhandledRejection)(reason);
}
function handleGlobalErrors() {
    if (typeof window !== 'undefined') {
        try {
            // Increase the number of stack frames on the client
            Error.stackTraceLimit = 50;
        } catch  {}
        window.addEventListener('error', onUnhandledError);
        window.addEventListener('unhandledrejection', onUnhandledRejection);
    }
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=use-error-handler.js.map
}),
"[project]/frontend/node_modules/next/dist/next-devtools/userspace/app/errors/intercept-console-error.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/frontend/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    originConsoleError: null,
    patchConsoleError: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    originConsoleError: function() {
        return originConsoleError;
    },
    patchConsoleError: function() {
        return patchConsoleError;
    }
});
const _interop_require_default = __turbopack_context__.r("[project]/frontend/node_modules/@swc/helpers/cjs/_interop_require_default.cjs [app-client] (ecmascript)");
const _iserror = /*#__PURE__*/ _interop_require_default._(__turbopack_context__.r("[project]/frontend/node_modules/next/dist/lib/is-error.js [app-client] (ecmascript)"));
const _isnextroutererror = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/client/components/is-next-router-error.js [app-client] (ecmascript)");
const _useerrorhandler = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/next-devtools/userspace/app/errors/use-error-handler.js [app-client] (ecmascript)");
const _console = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/client/lib/console.js [app-client] (ecmascript)");
const _forwardlogs = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/next-devtools/userspace/app/forward-logs.js [app-client] (ecmascript)");
const originConsoleError = globalThis.console.error;
function patchConsoleError() {
    // Ensure it's only patched once
    if (typeof window === 'undefined') {
        return;
    }
    window.console.error = function error(...args) {
        let maybeError;
        if ("TURBOPACK compile-time truthy", 1) {
            const { error: replayedError } = (0, _console.parseConsoleArgs)(args);
            if (replayedError) {
                maybeError = replayedError;
            } else if ((0, _iserror.default)(args[0])) {
                maybeError = args[0];
            } else {
                // See https://github.com/facebook/react/blob/d50323eb845c5fde0d720cae888bf35dedd05506/packages/react-reconciler/src/ReactFiberErrorLogger.js#L78
                maybeError = args[1];
            }
        } else //TURBOPACK unreachable
        ;
        if (!(0, _isnextroutererror.isNextRouterError)(maybeError)) {
            if ("TURBOPACK compile-time truthy", 1) {
                (0, _useerrorhandler.handleConsoleError)(// but if we pass the error directly, `handleClientError` will ignore it
                maybeError, args);
            }
            (0, _forwardlogs.forwardErrorLog)(args);
            originConsoleError.apply(window.console, args);
        }
    };
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=intercept-console-error.js.map
}),
"[project]/frontend/node_modules/next/dist/next-devtools/userspace/app/app-dev-overlay-setup.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
const _interceptconsoleerror = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/next-devtools/userspace/app/errors/intercept-console-error.js [app-client] (ecmascript)");
const _useerrorhandler = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/next-devtools/userspace/app/errors/use-error-handler.js [app-client] (ecmascript)");
const _forwardlogs = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/next-devtools/userspace/app/forward-logs.js [app-client] (ecmascript)");
(0, _useerrorhandler.handleGlobalErrors)();
(0, _interceptconsoleerror.patchConsoleError)();
(0, _forwardlogs.initializeDebugLogForwarding)('app');
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=app-dev-overlay-setup.js.map
}),
"[project]/frontend/node_modules/next/dist/next-devtools/userspace/app/errors/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    decorateDevError: null,
    handleClientError: null,
    originConsoleError: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    decorateDevError: function() {
        return _stitchederror.decorateDevError;
    },
    handleClientError: function() {
        return _useerrorhandler.handleClientError;
    },
    originConsoleError: function() {
        return _interceptconsoleerror.originConsoleError;
    }
});
const _interceptconsoleerror = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/next-devtools/userspace/app/errors/intercept-console-error.js [app-client] (ecmascript)");
const _useerrorhandler = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/next-devtools/userspace/app/errors/use-error-handler.js [app-client] (ecmascript)");
const _stitchederror = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/next-devtools/userspace/app/errors/stitched-error.js [app-client] (ecmascript)");
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=index.js.map
}),
"[project]/frontend/node_modules/next/dist/next-devtools/userspace/app/segment-explorer-node.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    SEGMENT_EXPLORER_SIMULATED_ERROR_MESSAGE: null,
    SegmentBoundaryTriggerNode: null,
    SegmentStateProvider: null,
    SegmentViewNode: null,
    SegmentViewStateNode: null,
    useSegmentState: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    SEGMENT_EXPLORER_SIMULATED_ERROR_MESSAGE: function() {
        return SEGMENT_EXPLORER_SIMULATED_ERROR_MESSAGE;
    },
    SegmentBoundaryTriggerNode: function() {
        return SegmentBoundaryTriggerNode;
    },
    SegmentStateProvider: function() {
        return SegmentStateProvider;
    },
    SegmentViewNode: function() {
        return SegmentViewNode;
    },
    SegmentViewStateNode: function() {
        return SegmentViewStateNode;
    },
    useSegmentState: function() {
        return useSegmentState;
    }
});
const _jsxruntime = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
const _react = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
const _nextdevtools = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/compiled/next-devtools/index.js (raw)");
const _notfound = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/client/components/not-found.js [app-client] (ecmascript)");
const SEGMENT_EXPLORER_SIMULATED_ERROR_MESSAGE = 'NEXT_DEVTOOLS_SIMULATED_ERROR';
function SegmentTrieNode({ type, pagePath }) {
    const { boundaryType, setBoundaryType } = useSegmentState();
    const nodeState = (0, _react.useMemo)(()=>{
        return {
            type,
            pagePath,
            boundaryType,
            setBoundaryType
        };
    }, [
        type,
        pagePath,
        boundaryType,
        setBoundaryType
    ]);
    // Use `useLayoutEffect` to ensure the state is updated during suspense.
    // `useEffect` won't work as the state is preserved during suspense.
    (0, _react.useLayoutEffect)(()=>{
        _nextdevtools.dispatcher.segmentExplorerNodeAdd(nodeState);
        return ()=>{
            _nextdevtools.dispatcher.segmentExplorerNodeRemove(nodeState);
        };
    }, [
        nodeState
    ]);
    return null;
}
function NotFoundSegmentNode() {
    (0, _notfound.notFound)();
}
function ErrorSegmentNode() {
    throw Object.defineProperty(new Error(SEGMENT_EXPLORER_SIMULATED_ERROR_MESSAGE), "__NEXT_ERROR_CODE", {
        value: "E394",
        enumerable: false,
        configurable: true
    });
}
const forever = new Promise(()=>{});
function LoadingSegmentNode() {
    (0, _react.use)(forever);
    return null;
}
function SegmentViewStateNode({ page }) {
    (0, _react.useLayoutEffect)(()=>{
        _nextdevtools.dispatcher.segmentExplorerUpdateRouteState(page);
        return ()=>{
            _nextdevtools.dispatcher.segmentExplorerUpdateRouteState('');
        };
    }, [
        page
    ]);
    return null;
}
function SegmentBoundaryTriggerNode() {
    const { boundaryType } = useSegmentState();
    let segmentNode = null;
    if (boundaryType === 'loading') {
        segmentNode = /*#__PURE__*/ (0, _jsxruntime.jsx)(LoadingSegmentNode, {});
    } else if (boundaryType === 'not-found') {
        segmentNode = /*#__PURE__*/ (0, _jsxruntime.jsx)(NotFoundSegmentNode, {});
    } else if (boundaryType === 'error') {
        segmentNode = /*#__PURE__*/ (0, _jsxruntime.jsx)(ErrorSegmentNode, {});
    }
    return segmentNode;
}
function SegmentViewNode({ type, pagePath, children }) {
    const segmentNode = /*#__PURE__*/ (0, _jsxruntime.jsx)(SegmentTrieNode, {
        type: type,
        pagePath: pagePath
    }, type);
    return /*#__PURE__*/ (0, _jsxruntime.jsxs)(_jsxruntime.Fragment, {
        children: [
            segmentNode,
            children
        ]
    });
}
const SegmentStateContext = /*#__PURE__*/ (0, _react.createContext)({
    boundaryType: null,
    setBoundaryType: ()=>{}
});
function SegmentStateProvider({ children }) {
    const [boundaryType, setBoundaryType] = (0, _react.useState)(null);
    const [errorBoundaryKey, setErrorBoundaryKey] = (0, _react.useState)(0);
    const reloadBoundary = (0, _react.useCallback)(()=>setErrorBoundaryKey((prev)=>prev + 1), []);
    const setBoundaryTypeAndReload = (0, _react.useCallback)((type)=>{
        if (type === null) {
            reloadBoundary();
        }
        setBoundaryType(type);
    }, [
        reloadBoundary
    ]);
    return /*#__PURE__*/ (0, _jsxruntime.jsx)(SegmentStateContext.Provider, {
        value: {
            boundaryType,
            setBoundaryType: setBoundaryTypeAndReload
        },
        children: children
    }, errorBoundaryKey);
}
function useSegmentState() {
    return (0, _react.useContext)(SegmentStateContext);
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=segment-explorer-node.js.map
}),
"[project]/frontend/node_modules/next/dist/next-devtools/userspace/app/app-dev-overlay-error-boundary.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/frontend/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "AppDevOverlayErrorBoundary", {
    enumerable: true,
    get: function() {
        return AppDevOverlayErrorBoundary;
    }
});
const _interop_require_default = __turbopack_context__.r("[project]/frontend/node_modules/@swc/helpers/cjs/_interop_require_default.cjs [app-client] (ecmascript)");
const _jsxruntime = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
const _react = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
const _nextdevtools = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/compiled/next-devtools/index.js (raw)");
const _runtimeerrorhandler = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/client/dev/runtime-error-handler.js [app-client] (ecmascript)");
const _errorboundary = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/client/components/error-boundary.js [app-client] (ecmascript)");
const _globalerror = /*#__PURE__*/ _interop_require_default._(__turbopack_context__.r("[project]/frontend/node_modules/next/dist/client/components/builtin/global-error.js [app-client] (ecmascript)"));
const _segmentexplorernode = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/next-devtools/userspace/app/segment-explorer-node.js [app-client] (ecmascript)");
function ErroredHtml({ globalError: [GlobalError, globalErrorStyles], error }) {
    if (!error) {
        return /*#__PURE__*/ (0, _jsxruntime.jsxs)("html", {
            children: [
                /*#__PURE__*/ (0, _jsxruntime.jsx)("head", {}),
                /*#__PURE__*/ (0, _jsxruntime.jsx)("body", {})
            ]
        });
    }
    return /*#__PURE__*/ (0, _jsxruntime.jsxs)(_errorboundary.ErrorBoundary, {
        errorComponent: _globalerror.default,
        children: [
            globalErrorStyles,
            /*#__PURE__*/ (0, _jsxruntime.jsx)(GlobalError, {
                error: error
            })
        ]
    });
}
class AppDevOverlayErrorBoundary extends _react.PureComponent {
    static getDerivedStateFromError(error) {
        _runtimeerrorhandler.RuntimeErrorHandler.hadRuntimeError = true;
        return {
            reactError: error
        };
    }
    componentDidCatch(err) {
        if (("TURBOPACK compile-time value", "development") === 'development' && err.message === _segmentexplorernode.SEGMENT_EXPLORER_SIMULATED_ERROR_MESSAGE) {
            return;
        }
        _nextdevtools.dispatcher.openErrorOverlay();
    }
    render() {
        const { children, globalError } = this.props;
        const { reactError } = this.state;
        const fallback = /*#__PURE__*/ (0, _jsxruntime.jsx)(ErroredHtml, {
            globalError: globalError,
            error: reactError
        });
        return reactError !== null ? fallback : children;
    }
    constructor(...args){
        super(...args), this.state = {
            reactError: null
        };
    }
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=app-dev-overlay-error-boundary.js.map
}),
"[project]/frontend/node_modules/next/dist/next-devtools/userspace/use-app-dev-rendering-indicator.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "useAppDevRenderingIndicator", {
    enumerable: true,
    get: function() {
        return useAppDevRenderingIndicator;
    }
});
const _react = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
const _nextdevtools = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/compiled/next-devtools/index.js (raw)");
const useAppDevRenderingIndicator = ()=>{
    const [isPending, startTransition] = (0, _react.useTransition)();
    (0, _react.useEffect)(()=>{
        if (isPending) {
            _nextdevtools.dispatcher.renderingIndicatorShow();
        } else {
            _nextdevtools.dispatcher.renderingIndicatorHide();
        }
    }, [
        isPending
    ]);
    return startTransition;
};
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=use-app-dev-rendering-indicator.js.map
}),
"[project]/frontend/node_modules/next/dist/next-devtools/userspace/app/errors/replay-ssr-only-errors.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/frontend/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "ReplaySsrOnlyErrors", {
    enumerable: true,
    get: function() {
        return ReplaySsrOnlyErrors;
    }
});
const _react = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
const _useerrorhandler = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/next-devtools/userspace/app/errors/use-error-handler.js [app-client] (ecmascript)");
const _isnextroutererror = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/client/components/is-next-router-error.js [app-client] (ecmascript)");
const _constants = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/shared/lib/errors/constants.js [app-client] (ecmascript)");
function readSsrError() {
    if (typeof document === 'undefined') {
        return null;
    }
    const ssrErrorTemplateTag = document.querySelector('template[data-next-error-message]');
    if (ssrErrorTemplateTag) {
        const message = ssrErrorTemplateTag.getAttribute('data-next-error-message');
        const stack = ssrErrorTemplateTag.getAttribute('data-next-error-stack');
        const digest = ssrErrorTemplateTag.getAttribute('data-next-error-digest');
        const error = Object.defineProperty(new Error(message), "__NEXT_ERROR_CODE", {
            value: "E394",
            enumerable: false,
            configurable: true
        });
        if (digest) {
            ;
            error.digest = digest;
        }
        // Skip Next.js SSR'd internal errors that which will be handled by the error boundaries.
        if ((0, _isnextroutererror.isNextRouterError)(error)) {
            return null;
        }
        error.stack = stack || '';
        return error;
    }
    return null;
}
function ReplaySsrOnlyErrors({ onBlockingError }) {
    if ("TURBOPACK compile-time truthy", 1) {
        // Need to read during render. The attributes will be gone after commit.
        const ssrError = readSsrError();
        // eslint-disable-next-line react-hooks/rules-of-hooks
        (0, _react.useEffect)(()=>{
            if (ssrError !== null) {
                // TODO(veil): Include original Owner Stack (NDX-905)
                // TODO(veil): Mark as recoverable error
                // TODO(veil): console.error
                (0, _useerrorhandler.handleClientError)(ssrError);
                // If it's missing root tags, we can't recover, make it blocking.
                if (ssrError.digest === _constants.MISSING_ROOT_TAGS_ERROR) {
                    onBlockingError();
                }
            }
        }, [
            ssrError,
            onBlockingError
        ]);
    }
    return null;
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=replay-ssr-only-errors.js.map
}),
"[project]/frontend/node_modules/next/dist/next-devtools/userspace/app/client-entry.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "RootLevelDevOverlayElement", {
    enumerable: true,
    get: function() {
        return RootLevelDevOverlayElement;
    }
});
const _interop_require_default = __turbopack_context__.r("[project]/frontend/node_modules/@swc/helpers/cjs/_interop_require_default.cjs [app-client] (ecmascript)");
const _jsxruntime = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
const _react = /*#__PURE__*/ _interop_require_default._(__turbopack_context__.r("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
const _globalerror = /*#__PURE__*/ _interop_require_default._(__turbopack_context__.r("[project]/frontend/node_modules/next/dist/client/components/builtin/global-error.js [app-client] (ecmascript)"));
const _appdevoverlayerrorboundary = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/next-devtools/userspace/app/app-dev-overlay-error-boundary.js [app-client] (ecmascript)");
function RootLevelDevOverlayElement({ children }) {
    return /*#__PURE__*/ (0, _jsxruntime.jsx)(_appdevoverlayerrorboundary.AppDevOverlayErrorBoundary, {
        globalError: [
            _globalerror.default,
            null
        ],
        children: children
    });
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=client-entry.js.map
}),
"[project]/frontend/node_modules/next/dist/server/app-render/async-local-storage.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    bindSnapshot: null,
    createAsyncLocalStorage: null,
    createSnapshot: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    bindSnapshot: function() {
        return bindSnapshot;
    },
    createAsyncLocalStorage: function() {
        return createAsyncLocalStorage;
    },
    createSnapshot: function() {
        return createSnapshot;
    }
});
const sharedAsyncLocalStorageNotAvailableError = Object.defineProperty(new Error('Invariant: AsyncLocalStorage accessed in runtime where it is not available'), "__NEXT_ERROR_CODE", {
    value: "E504",
    enumerable: false,
    configurable: true
});
class FakeAsyncLocalStorage {
    disable() {
        throw sharedAsyncLocalStorageNotAvailableError;
    }
    getStore() {
        // This fake implementation of AsyncLocalStorage always returns `undefined`.
        return undefined;
    }
    run() {
        throw sharedAsyncLocalStorageNotAvailableError;
    }
    exit() {
        throw sharedAsyncLocalStorageNotAvailableError;
    }
    enterWith() {
        throw sharedAsyncLocalStorageNotAvailableError;
    }
    static bind(fn) {
        return fn;
    }
}
const maybeGlobalAsyncLocalStorage = typeof globalThis !== 'undefined' && globalThis.AsyncLocalStorage;
function createAsyncLocalStorage() {
    if (maybeGlobalAsyncLocalStorage) {
        return new maybeGlobalAsyncLocalStorage();
    }
    return new FakeAsyncLocalStorage();
}
function bindSnapshot(fn) {
    if (maybeGlobalAsyncLocalStorage) {
        return maybeGlobalAsyncLocalStorage.bind(fn);
    }
    return FakeAsyncLocalStorage.bind(fn);
}
function createSnapshot() {
    if (maybeGlobalAsyncLocalStorage) {
        return maybeGlobalAsyncLocalStorage.snapshot();
    }
    return function(fn, ...args) {
        return fn(...args);
    };
} //# sourceMappingURL=async-local-storage.js.map
}),
"[project]/frontend/node_modules/next/dist/server/app-render/work-unit-async-storage-instance.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "workUnitAsyncStorageInstance", {
    enumerable: true,
    get: function() {
        return workUnitAsyncStorageInstance;
    }
});
const _asynclocalstorage = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/server/app-render/async-local-storage.js [app-client] (ecmascript)");
const workUnitAsyncStorageInstance = (0, _asynclocalstorage.createAsyncLocalStorage)(); //# sourceMappingURL=work-unit-async-storage-instance.js.map
}),
"[project]/frontend/node_modules/next/dist/server/app-render/work-unit-async-storage.external.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    getCacheSignal: null,
    getDraftModeProviderForCacheScope: null,
    getHmrRefreshHash: null,
    getPrerenderResumeDataCache: null,
    getRenderResumeDataCache: null,
    getRuntimeStagePromise: null,
    getServerComponentsHmrCache: null,
    isHmrRefresh: null,
    throwForMissingRequestStore: null,
    throwInvariantForMissingStore: null,
    workUnitAsyncStorage: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    getCacheSignal: function() {
        return getCacheSignal;
    },
    getDraftModeProviderForCacheScope: function() {
        return getDraftModeProviderForCacheScope;
    },
    getHmrRefreshHash: function() {
        return getHmrRefreshHash;
    },
    getPrerenderResumeDataCache: function() {
        return getPrerenderResumeDataCache;
    },
    getRenderResumeDataCache: function() {
        return getRenderResumeDataCache;
    },
    getRuntimeStagePromise: function() {
        return getRuntimeStagePromise;
    },
    getServerComponentsHmrCache: function() {
        return getServerComponentsHmrCache;
    },
    isHmrRefresh: function() {
        return isHmrRefresh;
    },
    throwForMissingRequestStore: function() {
        return throwForMissingRequestStore;
    },
    throwInvariantForMissingStore: function() {
        return throwInvariantForMissingStore;
    },
    workUnitAsyncStorage: function() {
        return _workunitasyncstorageinstance.workUnitAsyncStorageInstance;
    }
});
const _workunitasyncstorageinstance = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/server/app-render/work-unit-async-storage-instance.js [app-client] (ecmascript)");
const _approuterheaders = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/client/components/app-router-headers.js [app-client] (ecmascript)");
const _invarianterror = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/shared/lib/invariant-error.js [app-client] (ecmascript)");
function throwForMissingRequestStore(callingExpression) {
    throw Object.defineProperty(new Error(`\`${callingExpression}\` was called outside a request scope. Read more: https://nextjs.org/docs/messages/next-dynamic-api-wrong-context`), "__NEXT_ERROR_CODE", {
        value: "E251",
        enumerable: false,
        configurable: true
    });
}
function throwInvariantForMissingStore() {
    throw Object.defineProperty(new _invarianterror.InvariantError('Expected workUnitAsyncStorage to have a store.'), "__NEXT_ERROR_CODE", {
        value: "E696",
        enumerable: false,
        configurable: true
    });
}
function getPrerenderResumeDataCache(workUnitStore) {
    switch(workUnitStore.type){
        case 'prerender':
        case 'prerender-runtime':
        case 'prerender-ppr':
            return workUnitStore.prerenderResumeDataCache;
        case 'prerender-client':
            // TODO eliminate fetch caching in client scope and stop exposing this data
            // cache during SSR.
            return workUnitStore.prerenderResumeDataCache;
        case 'request':
            {
                // In dev, we might fill caches even during a dynamic request.
                if (workUnitStore.prerenderResumeDataCache) {
                    return workUnitStore.prerenderResumeDataCache;
                }
            // fallthrough
            }
        case 'prerender-legacy':
        case 'cache':
        case 'private-cache':
        case 'unstable-cache':
            return null;
        default:
            return workUnitStore;
    }
}
function getRenderResumeDataCache(workUnitStore) {
    switch(workUnitStore.type){
        case 'request':
        case 'prerender':
        case 'prerender-runtime':
        case 'prerender-client':
            if (workUnitStore.renderResumeDataCache) {
                // If we are in a prerender, we might have a render resume data cache
                // that is used to read from prefilled caches.
                return workUnitStore.renderResumeDataCache;
            }
        // fallthrough
        case 'prerender-ppr':
            // Otherwise we return the mutable resume data cache here as an immutable
            // version of the cache as it can also be used for reading.
            return workUnitStore.prerenderResumeDataCache ?? null;
        case 'cache':
        case 'private-cache':
        case 'unstable-cache':
        case 'prerender-legacy':
            return null;
        default:
            return workUnitStore;
    }
}
function getHmrRefreshHash(workStore, workUnitStore) {
    if (workStore.dev) {
        switch(workUnitStore.type){
            case 'cache':
            case 'private-cache':
            case 'prerender':
            case 'prerender-runtime':
                return workUnitStore.hmrRefreshHash;
            case 'request':
                var _workUnitStore_cookies_get;
                return (_workUnitStore_cookies_get = workUnitStore.cookies.get(_approuterheaders.NEXT_HMR_REFRESH_HASH_COOKIE)) == null ? void 0 : _workUnitStore_cookies_get.value;
            case 'prerender-client':
            case 'prerender-ppr':
            case 'prerender-legacy':
            case 'unstable-cache':
                break;
            default:
                workUnitStore;
        }
    }
    return undefined;
}
function isHmrRefresh(workStore, workUnitStore) {
    if (workStore.dev) {
        switch(workUnitStore.type){
            case 'cache':
            case 'private-cache':
            case 'request':
                return workUnitStore.isHmrRefresh ?? false;
            case 'prerender':
            case 'prerender-client':
            case 'prerender-runtime':
            case 'prerender-ppr':
            case 'prerender-legacy':
            case 'unstable-cache':
                break;
            default:
                workUnitStore;
        }
    }
    return false;
}
function getServerComponentsHmrCache(workStore, workUnitStore) {
    if (workStore.dev) {
        switch(workUnitStore.type){
            case 'cache':
            case 'private-cache':
            case 'request':
                return workUnitStore.serverComponentsHmrCache;
            case 'prerender':
            case 'prerender-client':
            case 'prerender-runtime':
            case 'prerender-ppr':
            case 'prerender-legacy':
            case 'unstable-cache':
                break;
            default:
                workUnitStore;
        }
    }
    return undefined;
}
function getDraftModeProviderForCacheScope(workStore, workUnitStore) {
    if (workStore.isDraftMode) {
        switch(workUnitStore.type){
            case 'cache':
            case 'private-cache':
            case 'unstable-cache':
            case 'prerender-runtime':
            case 'request':
                return workUnitStore.draftMode;
            case 'prerender':
            case 'prerender-client':
            case 'prerender-ppr':
            case 'prerender-legacy':
                break;
            default:
                workUnitStore;
        }
    }
    return undefined;
}
function getCacheSignal(workUnitStore) {
    switch(workUnitStore.type){
        case 'prerender':
        case 'prerender-client':
        case 'prerender-runtime':
            return workUnitStore.cacheSignal;
        case 'request':
            {
                // In dev, we might fill caches even during a dynamic request.
                if (workUnitStore.cacheSignal) {
                    return workUnitStore.cacheSignal;
                }
            // fallthrough
            }
        case 'prerender-ppr':
        case 'prerender-legacy':
        case 'cache':
        case 'private-cache':
        case 'unstable-cache':
            return null;
        default:
            return workUnitStore;
    }
}
function getRuntimeStagePromise(workUnitStore) {
    switch(workUnitStore.type){
        case 'prerender-runtime':
        case 'private-cache':
            return workUnitStore.runtimeStagePromise;
        case 'prerender':
        case 'prerender-client':
        case 'prerender-ppr':
        case 'prerender-legacy':
        case 'request':
        case 'cache':
        case 'unstable-cache':
            return null;
        default:
            return workUnitStore;
    }
} //# sourceMappingURL=work-unit-async-storage.external.js.map
}),
"[project]/frontend/node_modules/next/dist/server/app-render/work-async-storage-instance.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "workAsyncStorageInstance", {
    enumerable: true,
    get: function() {
        return workAsyncStorageInstance;
    }
});
const _asynclocalstorage = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/server/app-render/async-local-storage.js [app-client] (ecmascript)");
const workAsyncStorageInstance = (0, _asynclocalstorage.createAsyncLocalStorage)(); //# sourceMappingURL=work-async-storage-instance.js.map
}),
"[project]/frontend/node_modules/next/dist/server/app-render/work-async-storage.external.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "workAsyncStorage", {
    enumerable: true,
    get: function() {
        return _workasyncstorageinstance.workAsyncStorageInstance;
    }
});
const _workasyncstorageinstance = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/server/app-render/work-async-storage-instance.js [app-client] (ecmascript)"); //# sourceMappingURL=work-async-storage.external.js.map
}),
"[project]/frontend/node_modules/next/dist/server/app-render/action-async-storage-instance.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "actionAsyncStorageInstance", {
    enumerable: true,
    get: function() {
        return actionAsyncStorageInstance;
    }
});
const _asynclocalstorage = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/server/app-render/async-local-storage.js [app-client] (ecmascript)");
const actionAsyncStorageInstance = (0, _asynclocalstorage.createAsyncLocalStorage)(); //# sourceMappingURL=action-async-storage-instance.js.map
}),
"[project]/frontend/node_modules/next/dist/server/app-render/action-async-storage.external.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "actionAsyncStorage", {
    enumerable: true,
    get: function() {
        return _actionasyncstorageinstance.actionAsyncStorageInstance;
    }
});
const _actionasyncstorageinstance = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/server/app-render/action-async-storage-instance.js [app-client] (ecmascript)"); //# sourceMappingURL=action-async-storage.external.js.map
}),
"[project]/frontend/node_modules/next/dist/server/dynamic-rendering-utils.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    isHangingPromiseRejectionError: null,
    makeDevtoolsIOAwarePromise: null,
    makeHangingPromise: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    isHangingPromiseRejectionError: function() {
        return isHangingPromiseRejectionError;
    },
    makeDevtoolsIOAwarePromise: function() {
        return makeDevtoolsIOAwarePromise;
    },
    makeHangingPromise: function() {
        return makeHangingPromise;
    }
});
function isHangingPromiseRejectionError(err) {
    if (typeof err !== 'object' || err === null || !('digest' in err)) {
        return false;
    }
    return err.digest === HANGING_PROMISE_REJECTION;
}
const HANGING_PROMISE_REJECTION = 'HANGING_PROMISE_REJECTION';
class HangingPromiseRejectionError extends Error {
    constructor(route, expression){
        super(`During prerendering, ${expression} rejects when the prerender is complete. Typically these errors are handled by React but if you move ${expression} to a different context by using \`setTimeout\`, \`after\`, or similar functions you may observe this error and you should handle it in that context. This occurred at route "${route}".`), this.route = route, this.expression = expression, this.digest = HANGING_PROMISE_REJECTION;
    }
}
const abortListenersBySignal = new WeakMap();
function makeHangingPromise(signal, route, expression) {
    if (signal.aborted) {
        return Promise.reject(new HangingPromiseRejectionError(route, expression));
    } else {
        const hangingPromise = new Promise((_, reject)=>{
            const boundRejection = reject.bind(null, new HangingPromiseRejectionError(route, expression));
            let currentListeners = abortListenersBySignal.get(signal);
            if (currentListeners) {
                currentListeners.push(boundRejection);
            } else {
                const listeners = [
                    boundRejection
                ];
                abortListenersBySignal.set(signal, listeners);
                signal.addEventListener('abort', ()=>{
                    for(let i = 0; i < listeners.length; i++){
                        listeners[i]();
                    }
                }, {
                    once: true
                });
            }
        });
        // We are fine if no one actually awaits this promise. We shouldn't consider this an unhandled rejection so
        // we attach a noop catch handler here to suppress this warning. If you actually await somewhere or construct
        // your own promise out of it you'll need to ensure you handle the error when it rejects.
        hangingPromise.catch(ignoreReject);
        return hangingPromise;
    }
}
function ignoreReject() {}
function makeDevtoolsIOAwarePromise(underlying, requestStore, stage) {
    if (requestStore.stagedRendering) {
        // We resolve each stage in a timeout, so React DevTools will pick this up as IO.
        return requestStore.stagedRendering.delayUntilStage(stage, undefined, underlying);
    }
    // in React DevTools if we resolve in a setTimeout we will observe
    // the promise resolution as something that can suspend a boundary or root.
    return new Promise((resolve)=>{
        // Must use setTimeout to be considered IO React DevTools. setImmediate will not work.
        setTimeout(()=>{
            resolve(underlying);
        }, 0);
    });
} //# sourceMappingURL=dynamic-rendering-utils.js.map
}),
"[project]/frontend/node_modules/next/dist/server/lib/router-utils/is-postpone.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "isPostpone", {
    enumerable: true,
    get: function() {
        return isPostpone;
    }
});
const REACT_POSTPONE_TYPE = Symbol.for('react.postpone');
function isPostpone(error) {
    return typeof error === 'object' && error !== null && error.$$typeof === REACT_POSTPONE_TYPE;
} //# sourceMappingURL=is-postpone.js.map
}),
"[project]/frontend/node_modules/next/dist/server/app-render/dynamic-rendering.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/frontend/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
/**
 * The functions provided by this module are used to communicate certain properties
 * about the currently running code so that Next.js can make decisions on how to handle
 * the current execution in different rendering modes such as pre-rendering, resuming, and SSR.
 *
 * Today Next.js treats all code as potentially static. Certain APIs may only make sense when dynamically rendering.
 * Traditionally this meant deopting the entire render to dynamic however with PPR we can now deopt parts
 * of a React tree as dynamic while still keeping other parts static. There are really two different kinds of
 * Dynamic indications.
 *
 * The first is simply an intention to be dynamic. unstable_noStore is an example of this where
 * the currently executing code simply declares that the current scope is dynamic but if you use it
 * inside unstable_cache it can still be cached. This type of indication can be removed if we ever
 * make the default dynamic to begin with because the only way you would ever be static is inside
 * a cache scope which this indication does not affect.
 *
 * The second is an indication that a dynamic data source was read. This is a stronger form of dynamic
 * because it means that it is inappropriate to cache this at all. using a dynamic data source inside
 * unstable_cache should error. If you want to use some dynamic data inside unstable_cache you should
 * read that data outside the cache and pass it in as an argument to the cached function.
 */ "use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    Postpone: null,
    PreludeState: null,
    abortAndThrowOnSynchronousRequestDataAccess: null,
    abortOnSynchronousPlatformIOAccess: null,
    accessedDynamicData: null,
    annotateDynamicAccess: null,
    consumeDynamicAccess: null,
    createDynamicTrackingState: null,
    createDynamicValidationState: null,
    createHangingInputAbortSignal: null,
    createRenderInBrowserAbortSignal: null,
    delayUntilRuntimeStage: null,
    formatDynamicAPIAccesses: null,
    getFirstDynamicReason: null,
    getStaticShellDisallowedDynamicReasons: null,
    isDynamicPostpone: null,
    isPrerenderInterruptedError: null,
    logDisallowedDynamicError: null,
    markCurrentScopeAsDynamic: null,
    postponeWithTracking: null,
    throwIfDisallowedDynamic: null,
    throwToInterruptStaticGeneration: null,
    trackAllowedDynamicAccess: null,
    trackDynamicDataInDynamicRender: null,
    trackDynamicHoleInRuntimeShell: null,
    trackDynamicHoleInStaticShell: null,
    useDynamicRouteParams: null,
    useDynamicSearchParams: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    Postpone: function() {
        return Postpone;
    },
    PreludeState: function() {
        return PreludeState;
    },
    abortAndThrowOnSynchronousRequestDataAccess: function() {
        return abortAndThrowOnSynchronousRequestDataAccess;
    },
    abortOnSynchronousPlatformIOAccess: function() {
        return abortOnSynchronousPlatformIOAccess;
    },
    accessedDynamicData: function() {
        return accessedDynamicData;
    },
    annotateDynamicAccess: function() {
        return annotateDynamicAccess;
    },
    consumeDynamicAccess: function() {
        return consumeDynamicAccess;
    },
    createDynamicTrackingState: function() {
        return createDynamicTrackingState;
    },
    createDynamicValidationState: function() {
        return createDynamicValidationState;
    },
    createHangingInputAbortSignal: function() {
        return createHangingInputAbortSignal;
    },
    createRenderInBrowserAbortSignal: function() {
        return createRenderInBrowserAbortSignal;
    },
    delayUntilRuntimeStage: function() {
        return delayUntilRuntimeStage;
    },
    formatDynamicAPIAccesses: function() {
        return formatDynamicAPIAccesses;
    },
    getFirstDynamicReason: function() {
        return getFirstDynamicReason;
    },
    getStaticShellDisallowedDynamicReasons: function() {
        return getStaticShellDisallowedDynamicReasons;
    },
    isDynamicPostpone: function() {
        return isDynamicPostpone;
    },
    isPrerenderInterruptedError: function() {
        return isPrerenderInterruptedError;
    },
    logDisallowedDynamicError: function() {
        return logDisallowedDynamicError;
    },
    markCurrentScopeAsDynamic: function() {
        return markCurrentScopeAsDynamic;
    },
    postponeWithTracking: function() {
        return postponeWithTracking;
    },
    throwIfDisallowedDynamic: function() {
        return throwIfDisallowedDynamic;
    },
    throwToInterruptStaticGeneration: function() {
        return throwToInterruptStaticGeneration;
    },
    trackAllowedDynamicAccess: function() {
        return trackAllowedDynamicAccess;
    },
    trackDynamicDataInDynamicRender: function() {
        return trackDynamicDataInDynamicRender;
    },
    trackDynamicHoleInRuntimeShell: function() {
        return trackDynamicHoleInRuntimeShell;
    },
    trackDynamicHoleInStaticShell: function() {
        return trackDynamicHoleInStaticShell;
    },
    useDynamicRouteParams: function() {
        return useDynamicRouteParams;
    },
    useDynamicSearchParams: function() {
        return useDynamicSearchParams;
    }
});
const _react = /*#__PURE__*/ _interop_require_default(__turbopack_context__.r("[project]/frontend/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"));
const _hooksservercontext = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/client/components/hooks-server-context.js [app-client] (ecmascript)");
const _staticgenerationbailout = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/client/components/static-generation-bailout.js [app-client] (ecmascript)");
const _workunitasyncstorageexternal = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/server/app-render/work-unit-async-storage.external.js [app-client] (ecmascript)");
const _workasyncstorageexternal = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/server/app-render/work-async-storage.external.js [app-client] (ecmascript)");
const _dynamicrenderingutils = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/server/dynamic-rendering-utils.js [app-client] (ecmascript)");
const _boundaryconstants = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/lib/framework/boundary-constants.js [app-client] (ecmascript)");
const _scheduler = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/lib/scheduler.js [app-client] (ecmascript)");
const _bailouttocsr = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/shared/lib/lazy-dynamic/bailout-to-csr.js [app-client] (ecmascript)");
const _invarianterror = __turbopack_context__.r("[project]/frontend/node_modules/next/dist/shared/lib/invariant-error.js [app-client] (ecmascript)");
function _interop_require_default(obj) {
    return obj && obj.__esModule ? obj : {
        default: obj
    };
}
const hasPostpone = typeof _react.default.unstable_postpone === 'function';
function createDynamicTrackingState(isDebugDynamicAccesses) {
    return {
        isDebugDynamicAccesses,
        dynamicAccesses: [],
        syncDynamicErrorWithStack: null
    };
}
function createDynamicValidationState() {
    return {
        hasSuspenseAboveBody: false,
        hasDynamicMetadata: false,
        dynamicMetadata: null,
        hasDynamicViewport: false,
        hasAllowedDynamic: false,
        dynamicErrors: []
    };
}
function getFirstDynamicReason(trackingState) {
    var _trackingState_dynamicAccesses_;
    return (_trackingState_dynamicAccesses_ = trackingState.dynamicAccesses[0]) == null ? void 0 : _trackingState_dynamicAccesses_.expression;
}
function markCurrentScopeAsDynamic(store, workUnitStore, expression) {
    if (workUnitStore) {
        switch(workUnitStore.type){
            case 'cache':
            case 'unstable-cache':
                // Inside cache scopes, marking a scope as dynamic has no effect,
                // because the outer cache scope creates a cache boundary. This is
                // subtly different from reading a dynamic data source, which is
                // forbidden inside a cache scope.
                return;
            case 'private-cache':
                // A private cache scope is already dynamic by definition.
                return;
            case 'prerender-legacy':
            case 'prerender-ppr':
            case 'request':
                break;
            default:
                workUnitStore;
        }
    }
    // If we're forcing dynamic rendering or we're forcing static rendering, we
    // don't need to do anything here because the entire page is already dynamic
    // or it's static and it should not throw or postpone here.
    if (store.forceDynamic || store.forceStatic) return;
    if (store.dynamicShouldError) {
        throw Object.defineProperty(new _staticgenerationbailout.StaticGenBailoutError(`Route ${store.route} with \`dynamic = "error"\` couldn't be rendered statically because it used \`${expression}\`. See more info here: https://nextjs.org/docs/app/building-your-application/rendering/static-and-dynamic#dynamic-rendering`), "__NEXT_ERROR_CODE", {
            value: "E553",
            enumerable: false,
            configurable: true
        });
    }
    if (workUnitStore) {
        switch(workUnitStore.type){
            case 'prerender-ppr':
                return postponeWithTracking(store.route, expression, workUnitStore.dynamicTracking);
            case 'prerender-legacy':
                workUnitStore.revalidate = 0;
                // We aren't prerendering, but we are generating a static page. We need
                // to bail out of static generation.
                const err = Object.defineProperty(new _hooksservercontext.DynamicServerError(`Route ${store.route} couldn't be rendered statically because it used ${expression}. See more info here: https://nextjs.org/docs/messages/dynamic-server-error`), "__NEXT_ERROR_CODE", {
                    value: "E550",
                    enumerable: false,
                    configurable: true
                });
                store.dynamicUsageDescription = expression;
                store.dynamicUsageStack = err.stack;
                throw err;
            case 'request':
                if ("TURBOPACK compile-time truthy", 1) {
                    workUnitStore.usedDynamic = true;
                }
                break;
            default:
                workUnitStore;
        }
    }
}
function throwToInterruptStaticGeneration(expression, store, prerenderStore) {
    // We aren't prerendering but we are generating a static page. We need to bail out of static generation
    const err = Object.defineProperty(new _hooksservercontext.DynamicServerError(`Route ${store.route} couldn't be rendered statically because it used \`${expression}\`. See more info here: https://nextjs.org/docs/messages/dynamic-server-error`), "__NEXT_ERROR_CODE", {
        value: "E558",
        enumerable: false,
        configurable: true
    });
    prerenderStore.revalidate = 0;
    store.dynamicUsageDescription = expression;
    store.dynamicUsageStack = err.stack;
    throw err;
}
function trackDynamicDataInDynamicRender(workUnitStore) {
    switch(workUnitStore.type){
        case 'cache':
        case 'unstable-cache':
            // Inside cache scopes, marking a scope as dynamic has no effect,
            // because the outer cache scope creates a cache boundary. This is
            // subtly different from reading a dynamic data source, which is
            // forbidden inside a cache scope.
            return;
        case 'private-cache':
            // A private cache scope is already dynamic by definition.
            return;
        case 'prerender':
        case 'prerender-runtime':
        case 'prerender-legacy':
        case 'prerender-ppr':
        case 'prerender-client':
            break;
        case 'request':
            if ("TURBOPACK compile-time truthy", 1) {
                workUnitStore.usedDynamic = true;
            }
            break;
        default:
            workUnitStore;
    }
}
function abortOnSynchronousDynamicDataAccess(route, expression, prerenderStore) {
    const reason = `Route ${route} needs to bail out of prerendering at this point because it used ${expression}.`;
    const error = createPrerenderInterruptedError(reason);
    prerenderStore.controller.abort(error);
    const dynamicTracking = prerenderStore.dynamicTracking;
    if (dynamicTracking) {
        dynamicTracking.dynamicAccesses.push({
            // When we aren't debugging, we don't need to create another error for the
            // stack trace.
            stack: dynamicTracking.isDebugDynamicAccesses ? new Error().stack : undefined,
            expression
        });
    }
}
function abortOnSynchronousPlatformIOAccess(route, expression, errorWithStack, prerenderStore) {
    const dynamicTracking = prerenderStore.dynamicTracking;
    abortOnSynchronousDynamicDataAccess(route, expression, prerenderStore);
    // It is important that we set this tracking value after aborting. Aborts are executed
    // synchronously except for the case where you abort during render itself. By setting this
    // value late we can use it to determine if any of the aborted tasks are the task that
    // called the sync IO expression in the first place.
    if (dynamicTracking) {
        if (dynamicTracking.syncDynamicErrorWithStack === null) {
            dynamicTracking.syncDynamicErrorWithStack = errorWithStack;
        }
    }
}
function abortAndThrowOnSynchronousRequestDataAccess(route, expression, errorWithStack, prerenderStore) {
    const prerenderSignal = prerenderStore.controller.signal;
    if (prerenderSignal.aborted === false) {
        // TODO it would be better to move this aborted check into the callsite so we can avoid making
        // the error object when it isn't relevant to the aborting of the prerender however
        // since we need the throw semantics regardless of whether we abort it is easier to land
        // this way. See how this was handled with `abortOnSynchronousPlatformIOAccess` for a closer
        // to ideal implementation
        abortOnSynchronousDynamicDataAccess(route, expression, prerenderStore);
        // It is important that we set this tracking value after aborting. Aborts are executed
        // synchronously except for the case where you abort during render itself. By setting this
        // value late we can use it to determine if any of the aborted tasks are the task that
        // called the sync IO expression in the first place.
        const dynamicTracking = prerenderStore.dynamicTracking;
        if (dynamicTracking) {
            if (dynamicTracking.syncDynamicErrorWithStack === null) {
                dynamicTracking.syncDynamicErrorWithStack = errorWithStack;
            }
        }
    }
    throw createPrerenderInterruptedError(`Route ${route} needs to bail out of prerendering at this point because it used ${expression}.`);
}
function Postpone({ reason, route }) {
    const prerenderStore = _workunitasyncstorageexternal.workUnitAsyncStorage.getStore();
    const dynamicTracking = prerenderStore && prerenderStore.type === 'prerender-ppr' ? prerenderStore.dynamicTracking : null;
    postponeWithTracking(route, reason, dynamicTracking);
}
function postponeWithTracking(route, expression, dynamicTracking) {
    assertPostpone();
    if (dynamicTracking) {
        dynamicTracking.dynamicAccesses.push({
            // When we aren't debugging, we don't need to create another error for the
            // stack trace.
            stack: dynamicTracking.isDebugDynamicAccesses ? new Error().stack : undefined,
            expression
        });
    }
    _react.default.unstable_postpone(createPostponeReason(route, expression));
}
function createPostponeReason(route, expression) {
    return `Route ${route} needs to bail out of prerendering at this point because it used ${expression}. ` + `React throws this special object to indicate where. It should not be caught by ` + `your own try/catch. Learn more: https://nextjs.org/docs/messages/ppr-caught-error`;
}
function isDynamicPostpone(err) {
    if (typeof err === 'object' && err !== null && typeof err.message === 'string') {
        return isDynamicPostponeReason(err.message);
    }
    return false;
}
function isDynamicPostponeReason(reason) {
    return reason.includes('needs to bail out of prerendering at this point because it used') && reason.includes('Learn more: https://nextjs.org/docs/messages/ppr-caught-error');
}
if (isDynamicPostponeReason(createPostponeReason('%%%', '^^^')) === false) {
    throw Object.defineProperty(new Error('Invariant: isDynamicPostpone misidentified a postpone reason. This is a bug in Next.js'), "__NEXT_ERROR_CODE", {
        value: "E296",
        enumerable: false,
        configurable: true
    });
}
const NEXT_PRERENDER_INTERRUPTED = 'NEXT_PRERENDER_INTERRUPTED';
function createPrerenderInterruptedError(message) {
    const error = Object.defineProperty(new Error(message), "__NEXT_ERROR_CODE", {
        value: "E394",
        enumerable: false,
        configurable: true
    });
    error.digest = NEXT_PRERENDER_INTERRUPTED;
    return error;
}
function isPrerenderInterruptedError(error) {
    return typeof error === 'object' && error !== null && error.digest === NEXT_PRERENDER_INTERRUPTED && 'name' in error && 'message' in error && error instanceof Error;
}
function accessedDynamicData(dynamicAccesses) {
    return dynamicAccesses.length > 0;
}
function consumeDynamicAccess(serverDynamic, clientDynamic) {
    // We mutate because we only call this once we are no longer writing
    // to the dynamicTrackingState and it's more efficient than creating a new
    // array.
    serverDynamic.dynamicAccesses.push(...clientDynamic.dynamicAccesses);
    return serverDynamic.dynamicAccesses;
}
function formatDynamicAPIAccesses(dynamicAccesses) {
    return dynamicAccesses.filter((access)=>typeof access.stack === 'string' && access.stack.length > 0).map(({ expression, stack })=>{
        stack = stack.split('\n') // Remove the "Error: " prefix from the first line of the stack trace as
        // well as the first 4 lines of the stack trace which is the distance
        // from the user code and the `new Error().stack` call.
        .slice(4).filter((line)=>{
            // Exclude Next.js internals from the stack trace.
            if (line.includes('node_modules/next/')) {
                return false;
            }
            // Exclude anonymous functions from the stack trace.
            if (line.includes(' (<anonymous>)')) {
                return false;
            }
            // Exclude Node.js internals from the stack trace.
            if (line.includes(' (node:')) {
                return false;
            }
            return true;
        }).join('\n');
        return `Dynamic API Usage Debug - ${expression}:\n${stack}`;
    });
}
function assertPostpone() {
    if (!hasPostpone) {
        throw Object.defineProperty(new Error(`Invariant: React.unstable_postpone is not defined. This suggests the wrong version of React was loaded. This is a bug in Next.js`), "__NEXT_ERROR_CODE", {
            value: "E224",
            enumerable: false,
            configurable: true
        });
    }
}
function createRenderInBrowserAbortSignal() {
    const controller = new AbortController();
    controller.abort(Object.defineProperty(new _bailouttocsr.BailoutToCSRError('Render in Browser'), "__NEXT_ERROR_CODE", {
        value: "E721",
        enumerable: false,
        configurable: true
    }));
    return controller.signal;
}
function createHangingInputAbortSignal(workUnitStore) {
    switch(workUnitStore.type){
        case 'prerender':
        case 'prerender-runtime':
            const controller = new AbortController();
            if (workUnitStore.cacheSignal) {
                // If we have a cacheSignal it means we're in a prospective render. If
                // the input we're waiting on is coming from another cache, we do want
                // to wait for it so that we can resolve this cache entry too.
                workUnitStore.cacheSignal.inputReady().then(()=>{
                    controller.abort();
                });
            } else {
                // Otherwise we're in the final render and we should already have all
                // our caches filled.
                // If the prerender uses stages, we have wait until the runtime stage,
                // at which point all runtime inputs will be resolved.
                // (otherwise, a runtime prerender might consider `cookies()` hanging
                //  even though they'd resolve in the next task.)
                //
                // We might still be waiting on some microtasks so we
                // wait one tick before giving up. When we give up, we still want to
                // render the content of this cache as deeply as we can so that we can
                // suspend as deeply as possible in the tree or not at all if we don't
                // end up waiting for the input.
                const runtimeStagePromise = (0, _workunitasyncstorageexternal.getRuntimeStagePromise)(workUnitStore);
                if (runtimeStagePromise) {
                    runtimeStagePromise.then(()=>(0, _scheduler.scheduleOnNextTick)(()=>controller.abort()));
                } else {
                    (0, _scheduler.scheduleOnNextTick)(()=>controller.abort());
                }
            }
            return controller.signal;
        case 'prerender-client':
        case 'prerender-ppr':
        case 'prerender-legacy':
        case 'request':
        case 'cache':
        case 'private-cache':
        case 'unstable-cache':
            return undefined;
        default:
            workUnitStore;
    }
}
function annotateDynamicAccess(expression, prerenderStore) {
    const dynamicTracking = prerenderStore.dynamicTracking;
    if (dynamicTracking) {
        dynamicTracking.dynamicAccesses.push({
            stack: dynamicTracking.isDebugDynamicAccesses ? new Error().stack : undefined,
            expression
        });
    }
}
function useDynamicRouteParams(expression) {
    const workStore = _workasyncstorageexternal.workAsyncStorage.getStore();
    const workUnitStore = _workunitasyncstorageexternal.workUnitAsyncStorage.getStore();
    if (workStore && workUnitStore) {
        switch(workUnitStore.type){
            case 'prerender-client':
            case 'prerender':
                {
                    const fallbackParams = workUnitStore.fallbackRouteParams;
                    if (fallbackParams && fallbackParams.size > 0) {
                        // We are in a prerender with cacheComponents semantics. We are going to
                        // hang here and never resolve. This will cause the currently
                        // rendering component to effectively be a dynamic hole.
                        _react.default.use((0, _dynamicrenderingutils.makeHangingPromise)(workUnitStore.renderSignal, workStore.route, expression));
                    }
                    break;
                }
            case 'prerender-ppr':
                {
                    const fallbackParams = workUnitStore.fallbackRouteParams;
                    if (fallbackParams && fallbackParams.size > 0) {
                        return postponeWithTracking(workStore.route, expression, workUnitStore.dynamicTracking);
                    }
                    break;
                }
            case 'prerender-runtime':
                throw Object.defineProperty(new _invarianterror.InvariantError(`\`${expression}\` was called during a runtime prerender. Next.js should be preventing ${expression} from being included in server components statically, but did not in this case.`), "__NEXT_ERROR_CODE", {
                    value: "E771",
                    enumerable: false,
                    configurable: true
                });
            case 'cache':
            case 'private-cache':
                throw Object.defineProperty(new _invarianterror.InvariantError(`\`${expression}\` was called inside a cache scope. Next.js should be preventing ${expression} from being included in server components statically, but did not in this case.`), "__NEXT_ERROR_CODE", {
                    value: "E745",
                    enumerable: false,
                    configurable: true
                });
            case 'prerender-legacy':
            case 'request':
            case 'unstable-cache':
                break;
            default:
                workUnitStore;
        }
    }
}
function useDynamicSearchParams(expression) {
    const workStore = _workasyncstorageexternal.workAsyncStorage.getStore();
    const workUnitStore = _workunitasyncstorageexternal.workUnitAsyncStorage.getStore();
    if (!workStore) {
        // We assume pages router context and just return
        return;
    }
    if (!workUnitStore) {
        (0, _workunitasyncstorageexternal.throwForMissingRequestStore)(expression);
    }
    switch(workUnitStore.type){
        case 'prerender-client':
            {
                _react.default.use((0, _dynamicrenderingutils.makeHangingPromise)(workUnitStore.renderSignal, workStore.route, expression));
                break;
            }
        case 'prerender-legacy':
        case 'prerender-ppr':
            {
                if (workStore.forceStatic) {
                    return;
                }
                throw Object.defineProperty(new _bailouttocsr.BailoutToCSRError(expression), "__NEXT_ERROR_CODE", {
                    value: "E394",
                    enumerable: false,
                    configurable: true
                });
            }
        case 'prerender':
        case 'prerender-runtime':
            throw Object.defineProperty(new _invarianterror.InvariantError(`\`${expression}\` was called from a Server Component. Next.js should be preventing ${expression} from being included in server components statically, but did not in this case.`), "__NEXT_ERROR_CODE", {
                value: "E795",
                enumerable: false,
                configurable: true
            });
        case 'cache':
        case 'unstable-cache':
        case 'private-cache':
            throw Object.defineProperty(new _invarianterror.InvariantError(`\`${expression}\` was called inside a cache scope. Next.js should be preventing ${expression} from being included in server components statically, but did not in this case.`), "__NEXT_ERROR_CODE", {
                value: "E745",
                enumerable: false,
                configurable: true
            });
        case 'request':
            return;
        default:
            workUnitStore;
    }
}
const hasSuspenseRegex = /\n\s+at Suspense \(<anonymous>\)/;
// Common implicit body tags that React will treat as body when placed directly in html
const bodyAndImplicitTags = 'body|div|main|section|article|aside|header|footer|nav|form|p|span|h1|h2|h3|h4|h5|h6';
// Detects when RootLayoutBoundary (our framework marker component) appears
// after Suspense in the component stack, indicating the root layout is wrapped
// within a Suspense boundary. Ensures no body/html/implicit-body components are in between.
//
// Example matches:
//   at Suspense (<anonymous>)
//   at __next_root_layout_boundary__ (<anonymous>)
//
// Or with other components in between (but not body/html/implicit-body):
//   at Suspense (<anonymous>)
//   at SomeComponent (<anonymous>)
//   at __next_root_layout_boundary__ (<anonymous>)
const hasSuspenseBeforeRootLayoutWithoutBodyOrImplicitBodyRegex = new RegExp(`\\n\\s+at Suspense \\(<anonymous>\\)(?:(?!\\n\\s+at (?:${bodyAndImplicitTags}) \\(<anonymous>\\))[\\s\\S])*?\\n\\s+at ${_boundaryconstants.ROOT_LAYOUT_BOUNDARY_NAME} \\([^\\n]*\\)`);
const hasMetadataRegex = new RegExp(`\\n\\s+at ${_boundaryconstants.METADATA_BOUNDARY_NAME}[\\n\\s]`);
const hasViewportRegex = new RegExp(`\\n\\s+at ${_boundaryconstants.VIEWPORT_BOUNDARY_NAME}[\\n\\s]`);
const hasOutletRegex = new RegExp(`\\n\\s+at ${_boundaryconstants.OUTLET_BOUNDARY_NAME}[\\n\\s]`);
function trackAllowedDynamicAccess(workStore, componentStack, dynamicValidation, clientDynamic) {
    if (hasOutletRegex.test(componentStack)) {
        // We don't need to track that this is dynamic. It is only so when something else is also dynamic.
        return;
    } else if (hasMetadataRegex.test(componentStack)) {
        dynamicValidation.hasDynamicMetadata = true;
        return;
    } else if (hasViewportRegex.test(componentStack)) {
        dynamicValidation.hasDynamicViewport = true;
        return;
    } else if (hasSuspenseBeforeRootLayoutWithoutBodyOrImplicitBodyRegex.test(componentStack)) {
        // For Suspense within body, the prelude wouldn't be empty so it wouldn't violate the empty static shells rule.
        // But if you have Suspense above body, the prelude is empty but we allow that because having Suspense
        // is an explicit signal from the user that they acknowledge the empty shell and want dynamic rendering.
        dynamicValidation.hasAllowedDynamic = true;
        dynamicValidation.hasSuspenseAboveBody = true;
        return;
    } else if (hasSuspenseRegex.test(componentStack)) {
        // this error had a Suspense boundary above it so we don't need to report it as a source
        // of disallowed
        dynamicValidation.hasAllowedDynamic = true;
        return;
    } else if (clientDynamic.syncDynamicErrorWithStack) {
        // This task was the task that called the sync error.
        dynamicValidation.dynamicErrors.push(clientDynamic.syncDynamicErrorWithStack);
        return;
    } else {
        const message = `Route "${workStore.route}": Uncached data was accessed outside of ` + '<Suspense>. This delays the entire page from rendering, resulting in a ' + 'slow user experience. Learn more: ' + 'https://nextjs.org/docs/messages/blocking-route';
        const error = createErrorWithComponentOrOwnerStack(message, componentStack);
        dynamicValidation.dynamicErrors.push(error);
        return;
    }
}
function trackDynamicHoleInRuntimeShell(workStore, componentStack, dynamicValidation, clientDynamic) {
    if (hasOutletRegex.test(componentStack)) {
        // We don't need to track that this is dynamic. It is only so when something else is also dynamic.
        return;
    } else if (hasMetadataRegex.test(componentStack)) {
        const message = `Route "${workStore.route}": Uncached data or \`connection()\` was accessed inside \`generateMetadata\`. Except for this instance, the page would have been entirely prerenderable which may have been the intended behavior. See more info here: https://nextjs.org/docs/messages/next-prerender-dynamic-metadata`;
        const error = createErrorWithComponentOrOwnerStack(message, componentStack);
        dynamicValidation.dynamicMetadata = error;
        return;
    } else if (hasViewportRegex.test(componentStack)) {
        const message = `Route "${workStore.route}": Uncached data or \`connection()\` was accessed inside \`generateViewport\`. This delays the entire page from rendering, resulting in a slow user experience. Learn more: https://nextjs.org/docs/messages/next-prerender-dynamic-viewport`;
        const error = createErrorWithComponentOrOwnerStack(message, componentStack);
        dynamicValidation.dynamicErrors.push(error);
        return;
    } else if (hasSuspenseBeforeRootLayoutWithoutBodyOrImplicitBodyRegex.test(componentStack)) {
        // For Suspense within body, the prelude wouldn't be empty so it wouldn't violate the empty static shells rule.
        // But if you have Suspense above body, the prelude is empty but we allow that because having Suspense
        // is an explicit signal from the user that they acknowledge the empty shell and want dynamic rendering.
        dynamicValidation.hasAllowedDynamic = true;
        dynamicValidation.hasSuspenseAboveBody = true;
        return;
    } else if (hasSuspenseRegex.test(componentStack)) {
        // this error had a Suspense boundary above it so we don't need to report it as a source
        // of disallowed
        dynamicValidation.hasAllowedDynamic = true;
        return;
    } else if (clientDynamic.syncDynamicErrorWithStack) {
        // This task was the task that called the sync error.
        dynamicValidation.dynamicErrors.push(clientDynamic.syncDynamicErrorWithStack);
        return;
    } else {
        const message = `Route "${workStore.route}": Uncached data or \`connection()\` was accessed outside of \`<Suspense>\`. This delays the entire page from rendering, resulting in a slow user experience. Learn more: https://nextjs.org/docs/messages/blocking-route`;
        const error = createErrorWithComponentOrOwnerStack(message, componentStack);
        dynamicValidation.dynamicErrors.push(error);
        return;
    }
}
function trackDynamicHoleInStaticShell(workStore, componentStack, dynamicValidation, clientDynamic) {
    if (hasOutletRegex.test(componentStack)) {
        // We don't need to track that this is dynamic. It is only so when something else is also dynamic.
        return;
    } else if (hasMetadataRegex.test(componentStack)) {
        const message = `Route "${workStore.route}": Runtime data such as \`cookies()\`, \`headers()\`, \`params\`, or \`searchParams\` was accessed inside \`generateMetadata\` or you have file-based metadata such as icons that depend on dynamic params segments. Except for this instance, the page would have been entirely prerenderable which may have been the intended behavior. See more info here: https://nextjs.org/docs/messages/next-prerender-dynamic-metadata`;
        const error = createErrorWithComponentOrOwnerStack(message, componentStack);
        dynamicValidation.dynamicMetadata = error;
        return;
    } else if (hasViewportRegex.test(componentStack)) {
        const message = `Route "${workStore.route}": Runtime data such as \`cookies()\`, \`headers()\`, \`params\`, or \`searchParams\` was accessed inside \`generateViewport\`. This delays the entire page from rendering, resulting in a slow user experience. Learn more: https://nextjs.org/docs/messages/next-prerender-dynamic-viewport`;
        const error = createErrorWithComponentOrOwnerStack(message, componentStack);
        dynamicValidation.dynamicErrors.push(error);
        return;
    } else if (hasSuspenseBeforeRootLayoutWithoutBodyOrImplicitBodyRegex.test(componentStack)) {
        // For Suspense within body, the prelude wouldn't be empty so it wouldn't violate the empty static shells rule.
        // But if you have Suspense above body, the prelude is empty but we allow that because having Suspense
        // is an explicit signal from the user that they acknowledge the empty shell and want dynamic rendering.
        dynamicValidation.hasAllowedDynamic = true;
        dynamicValidation.hasSuspenseAboveBody = true;
        return;
    } else if (hasSuspenseRegex.test(componentStack)) {
        // this error had a Suspense boundary above it so we don't need to report it as a source
        // of disallowed
        dynamicValidation.hasAllowedDynamic = true;
        return;
    } else if (clientDynamic.syncDynamicErrorWithStack) {
        // This task was the task that called the sync error.
        dynamicValidation.dynamicErrors.push(clientDynamic.syncDynamicErrorWithStack);
        return;
    } else {
        const message = `Route "${workStore.route}": Runtime data such as \`cookies()\`, \`headers()\`, \`params\`, or \`searchParams\` was accessed outside of \`<Suspense>\`. This delays the entire page from rendering, resulting in a slow user experience. Learn more: https://nextjs.org/docs/messages/blocking-route`;
        const error = createErrorWithComponentOrOwnerStack(message, componentStack);
        dynamicValidation.dynamicErrors.push(error);
        return;
    }
}
/**
 * In dev mode, we prefer using the owner stack, otherwise the provided
 * component stack is used.
 */ function createErrorWithComponentOrOwnerStack(message, componentStack) {
    const ownerStack = ("TURBOPACK compile-time value", "development") !== 'production' && _react.default.captureOwnerStack ? _react.default.captureOwnerStack() : null;
    const error = Object.defineProperty(new Error(message), "__NEXT_ERROR_CODE", {
        value: "E394",
        enumerable: false,
        configurable: true
    });
    // TODO go back to owner stack here if available. This is temporarily using componentStack to get the right
    //
    error.stack = error.name + ': ' + message + (ownerStack || componentStack);
    return error;
}
var PreludeState = /*#__PURE__*/ function(PreludeState) {
    PreludeState[PreludeState["Full"] = 0] = "Full";
    PreludeState[PreludeState["Empty"] = 1] = "Empty";
    PreludeState[PreludeState["Errored"] = 2] = "Errored";
    return PreludeState;
}({});
function logDisallowedDynamicError(workStore, error) {
    console.error(error);
    if (!workStore.dev) {
        if (workStore.hasReadableErrorStacks) {
            console.error(`To get a more detailed stack trace and pinpoint the issue, start the app in development mode by running \`next dev\`, then open "${workStore.route}" in your browser to investigate the error.`);
        } else {
            console.error(`To get a more detailed stack trace and pinpoint the issue, try one of the following:
  - Start the app in development mode by running \`next dev\`, then open "${workStore.route}" in your browser to investigate the error.
  - Rerun the production build with \`next build --debug-prerender\` to generate better stack traces.`);
        }
    }
}
function throwIfDisallowedDynamic(workStore, prelude, dynamicValidation, serverDynamic) {
    if (serverDynamic.syncDynamicErrorWithStack) {
        logDisallowedDynamicError(workStore, serverDynamic.syncDynamicErrorWithStack);
        throw new _staticgenerationbailout.StaticGenBailoutError();
    }
    if (prelude !== 0) {
        if (dynamicValidation.hasSuspenseAboveBody) {
            // This route has opted into allowing fully dynamic rendering
            // by including a Suspense boundary above the body. In this case
            // a lack of a shell is not considered disallowed so we simply return
            return;
        }
        // We didn't have any sync bailouts but there may be user code which
        // blocked the root. We would have captured these during the prerender
        // and can log them here and then terminate the build/validating render
        const dynamicErrors = dynamicValidation.dynamicErrors;
        if (dynamicErrors.length > 0) {
            for(let i = 0; i < dynamicErrors.length; i++){
                logDisallowedDynamicError(workStore, dynamicErrors[i]);
            }
            throw new _staticgenerationbailout.StaticGenBailoutError();
        }
        // If we got this far then the only other thing that could be blocking
        // the root is dynamic Viewport. If this is dynamic then
        // you need to opt into that by adding a Suspense boundary above the body
        // to indicate your are ok with fully dynamic rendering.
        if (dynamicValidation.hasDynamicViewport) {
            console.error(`Route "${workStore.route}" has a \`generateViewport\` that depends on Request data (\`cookies()\`, etc...) or uncached external data (\`fetch(...)\`, etc...) without explicitly allowing fully dynamic rendering. See more info here: https://nextjs.org/docs/messages/next-prerender-dynamic-viewport`);
            throw new _staticgenerationbailout.StaticGenBailoutError();
        }
        if (prelude === 1) {
            // If we ever get this far then we messed up the tracking of invalid dynamic.
            // We still adhere to the constraint that you must produce a shell but invite the
            // user to report this as a bug in Next.js.
            console.error(`Route "${workStore.route}" did not produce a static shell and Next.js was unable to determine a reason. This is a bug in Next.js.`);
            throw new _staticgenerationbailout.StaticGenBailoutError();
        }
    } else {
        if (dynamicValidation.hasAllowedDynamic === false && dynamicValidation.hasDynamicMetadata) {
            console.error(`Route "${workStore.route}" has a \`generateMetadata\` that depends on Request data (\`cookies()\`, etc...) or uncached external data (\`fetch(...)\`, etc...) when the rest of the route does not. See more info here: https://nextjs.org/docs/messages/next-prerender-dynamic-metadata`);
            throw new _staticgenerationbailout.StaticGenBailoutError();
        }
    }
}
function getStaticShellDisallowedDynamicReasons(workStore, prelude, dynamicValidation) {
    if (dynamicValidation.hasSuspenseAboveBody) {
        // This route has opted into allowing fully dynamic rendering
        // by including a Suspense boundary above the body. In this case
        // a lack of a shell is not considered disallowed so we simply return
        return [];
    }
    if (prelude !== 0) {
        // We didn't have any sync bailouts but there may be user code which
        // blocked the root. We would have captured these during the prerender
        // and can log them here and then terminate the build/validating render
        const dynamicErrors = dynamicValidation.dynamicErrors;
        if (dynamicErrors.length > 0) {
            return dynamicErrors;
        }
        if (prelude === 1) {
            // If we ever get this far then we messed up the tracking of invalid dynamic.
            // We still adhere to the constraint that you must produce a shell but invite the
            // user to report this as a bug in Next.js.
            return [
                Object.defineProperty(new _invarianterror.InvariantError(`Route "${workStore.route}" did not produce a static shell and Next.js was unable to determine a reason.`), "__NEXT_ERROR_CODE", {
                    value: "E936",
                    enumerable: false,
                    configurable: true
                })
            ];
        }
    } else {
        // We have a prelude but we might still have dynamic metadata without any other dynamic access
        if (dynamicValidation.hasAllowedDynamic === false && dynamicValidation.dynamicErrors.length === 0 && dynamicValidation.dynamicMetadata) {
            return [
                dynamicValidation.dynamicMetadata
            ];
        }
    }
    // We had a non-empty prelude and there are no dynamic holes
    return [];
}
function delayUntilRuntimeStage(prerenderStore, result) {
    if (prerenderStore.runtimeStagePromise) {
        return prerenderStore.runtimeStagePromise.then(()=>result);
    }
    return result;
} //# sourceMappingURL=dynamic-rendering.js.map
}),
"[project]/frontend/node_modules/next/dist/server/dev/hot-reloader-types.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    HMR_MESSAGE_SENT_TO_BROWSER: null,
    HMR_MESSAGE_SENT_TO_SERVER: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    HMR_MESSAGE_SENT_TO_BROWSER: function() {
        return HMR_MESSAGE_SENT_TO_BROWSER;
    },
    HMR_MESSAGE_SENT_TO_SERVER: function() {
        return HMR_MESSAGE_SENT_TO_SERVER;
    }
});
var HMR_MESSAGE_SENT_TO_BROWSER = /*#__PURE__*/ function(HMR_MESSAGE_SENT_TO_BROWSER) {
    // JSON messages:
    HMR_MESSAGE_SENT_TO_BROWSER["ADDED_PAGE"] = "addedPage";
    HMR_MESSAGE_SENT_TO_BROWSER["REMOVED_PAGE"] = "removedPage";
    HMR_MESSAGE_SENT_TO_BROWSER["RELOAD_PAGE"] = "reloadPage";
    HMR_MESSAGE_SENT_TO_BROWSER["SERVER_COMPONENT_CHANGES"] = "serverComponentChanges";
    HMR_MESSAGE_SENT_TO_BROWSER["MIDDLEWARE_CHANGES"] = "middlewareChanges";
    HMR_MESSAGE_SENT_TO_BROWSER["CLIENT_CHANGES"] = "clientChanges";
    HMR_MESSAGE_SENT_TO_BROWSER["SERVER_ONLY_CHANGES"] = "serverOnlyChanges";
    HMR_MESSAGE_SENT_TO_BROWSER["SYNC"] = "sync";
    HMR_MESSAGE_SENT_TO_BROWSER["BUILT"] = "built";
    HMR_MESSAGE_SENT_TO_BROWSER["BUILDING"] = "building";
    HMR_MESSAGE_SENT_TO_BROWSER["DEV_PAGES_MANIFEST_UPDATE"] = "devPagesManifestUpdate";
    HMR_MESSAGE_SENT_TO_BROWSER["TURBOPACK_MESSAGE"] = "turbopack-message";
    HMR_MESSAGE_SENT_TO_BROWSER["SERVER_ERROR"] = "serverError";
    HMR_MESSAGE_SENT_TO_BROWSER["TURBOPACK_CONNECTED"] = "turbopack-connected";
    HMR_MESSAGE_SENT_TO_BROWSER["ISR_MANIFEST"] = "isrManifest";
    HMR_MESSAGE_SENT_TO_BROWSER["CACHE_INDICATOR"] = "cacheIndicator";
    HMR_MESSAGE_SENT_TO_BROWSER["DEV_INDICATOR"] = "devIndicator";
    HMR_MESSAGE_SENT_TO_BROWSER["DEVTOOLS_CONFIG"] = "devtoolsConfig";
    HMR_MESSAGE_SENT_TO_BROWSER["REQUEST_CURRENT_ERROR_STATE"] = "requestCurrentErrorState";
    HMR_MESSAGE_SENT_TO_BROWSER["REQUEST_PAGE_METADATA"] = "requestPageMetadata";
    // Binary messages:
    HMR_MESSAGE_SENT_TO_BROWSER[HMR_MESSAGE_SENT_TO_BROWSER["REACT_DEBUG_CHUNK"] = 0] = "REACT_DEBUG_CHUNK";
    HMR_MESSAGE_SENT_TO_BROWSER[HMR_MESSAGE_SENT_TO_BROWSER["ERRORS_TO_SHOW_IN_BROWSER"] = 1] = "ERRORS_TO_SHOW_IN_BROWSER";
    return HMR_MESSAGE_SENT_TO_BROWSER;
}({});
var HMR_MESSAGE_SENT_TO_SERVER = /*#__PURE__*/ function(HMR_MESSAGE_SENT_TO_SERVER) {
    // JSON messages:
    HMR_MESSAGE_SENT_TO_SERVER["MCP_ERROR_STATE_RESPONSE"] = "mcp-error-state-response";
    HMR_MESSAGE_SENT_TO_SERVER["MCP_PAGE_METADATA_RESPONSE"] = "mcp-page-metadata-response";
    HMR_MESSAGE_SENT_TO_SERVER["PING"] = "ping";
    return HMR_MESSAGE_SENT_TO_SERVER;
}({}); //# sourceMappingURL=hot-reloader-types.js.map
}),
]);

//# sourceMappingURL=9e883_next_dist_e24ad472._.js.map